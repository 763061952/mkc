BEGIN {
  while ((getline line < prev) > 0) {
    n = split(line, a, " ");
    if (n >= 2) P[a[1]] = a[2] + 0;
  }
  close(prev);
  out = "";
  cnt = 0;
}
{
  pid = $1 + 0; comm = $2; gsub(/[()]/, "", comm);
  total = ($14 + 0) + ($15 + 0);
  rss = ($24 + 0) * 4;
  pv = (pid in P) ? P[pid] : 0;
  cpu = (pv > 0 && total >= pv) ? (total - pv) * 100 / (tk * dt) : 0;
  if (cpu < 0) cpu = 0;
  printf "%.0f", cpu > "/tmp/_no";   # 保持语法：忽略
  cnt++;
  CPUS[cnt] = cpu; PIDS[cnt] = pid; COMS[cnt] = comm; RSSS[cnt] = rss;
  print pid " " total > newf;
}
END {
  close(newf);
  # 简单选择排序取前 20
  for (i = 1; i <= cnt; i++) {
    best = i;
    for (j = i + 1; j <= cnt; j++) if (CPUS[j] > CPUS[best]) best = j;
    if (best != i) {
      t = CPUS[i]; CPUS[i] = CPUS[best]; CPUS[best] = t;
      t = PIDS[i]; PIDS[i] = PIDS[best]; PIDS[best] = t;
      t = COMS[i]; COMS[i] = COMS[best]; COMS[best] = t;
      t = RSSS[i]; RSSS[i] = RSSS[best]; RSSS[best] = t;
    }
    if (i <= 20) printf "%d|%s|%d|%d\n", PIDS[i], COMS[i], CPUS[i], RSSS[i] > outp;
  }
  close(outp);
}
