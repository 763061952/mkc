#!/system/bin/sh
# 二合一 v3.0.1 模块按钮   作者：酷安@happier2
#   ★ 管理器里直接点「执行」（不带参数）= 自检 + 自动修复 ★
#   on/off/rescue/selfcheck/repair/status/diag/log/mask on|off/fast on|off
MODDIR=${0%/*}
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"
PIDF=/data/local/tmp/temp_chg_all.pid
LCK=/data/local/tmp/temp_selfcheck.lock
LCK2=/data/local/tmp/temp_chg_selfcheck.lock
DIAG=${DIAG:-/data/local/tmp/temp_mask_all_diag.txt}
MASKLOG=${MASKLOG:-/data/local/tmp/temp_mask_all.log}
CHGLOG=${CHGLOG:-/data/local/tmp/chg_fast.log}
STATUS=${STATUS:-/data/local/tmp/temp_chg_status.txt}
SNAP=/data/local/tmp/chg_stock_gear
FAKE=/sys/devices/platform/strategy-fg/fake_temp
B=/sys/class/power_supply/battery
RM=/sys/class/xm_power/charger/charger_thermal/wired_thermal_remove
LV=/sys/class/xm_power/charger/charger_thermal/wired_ctrl_limit

chgline(){
  printf "  充电: status=%s 电流=%suA 电压=%suV 电量=%s%% 电池温=%s(0.1C)\n" \
    "$(cat $B/status 2>/dev/null)" "$(cat $B/current_now 2>/dev/null)" \
    "$(cat $B/voltage_now 2>/dev/null)" "$(cat $B/capacity 2>/dev/null)" "$(cat $B/temp 2>/dev/null)"
}
unmask(){ for z in /sys/class/thermal/thermal_zone*; do [ -w "$z/emul_temp" ] && echo 0 > "$z/emul_temp" 2>/dev/null; done; echo -999 > "$FAKE" 2>/dev/null; }
stock_gear(){ s=$(grep -o 'gear=[0-9]*' "$SNAP" 2>/dev/null | cut -d= -f2); case "$s" in ''|*[!0-9]*|0) s=${STOCK_GEAR:-12};; esac; [ "$s" = "0" ] && s=12; echo "$s"; }
official(){
  [ -e "$RM" ] && { echo 0 > "$RM" 2>/dev/null; echo "$(stock_gear)" > "$LV" 2>/dev/null; }
  c=$(grep -o 'cur=[0-9]*' "$SNAP" 2>/dev/null | cut -d= -f2)
  u=$(grep -o 'usb=[0-9]*' "$SNAP" 2>/dev/null | cut -d= -f2)
  case "$c" in ''|*[!0-9]*|0) ;; *) echo "$c" > /sys/class/power_supply/battery/constant_charge_current_max 2>/dev/null;; esac
  case "$u" in ''|*[!0-9]*|0) ;; *) echo "$u" > /sys/class/power_supply/usb/current_max 2>/dev/null;; esac
}
plugged(){
  for f in /sys/class/power_supply/usb/online /sys/class/power_supply/usb/present \
           /sys/class/power_supply/main/present /sys/class/power_supply/charger/online \
           /sys/class/power_supply/pc_port/online /sys/class/power_supply/typec/present; do
    [ -r "$f" ] || continue
    [ "$(cat "$f" 2>/dev/null)" = "1" ] && { echo 1; return; }
  done
  echo 0
}
killd(){
  for d in /proc/[0-9]*; do
    p=${d#/proc/}
    a1=$(tr '\0' '\n' < "$d/cmdline" 2>/dev/null | grep -x "/data/adb/modules/temp_mask_all/service.sh")
    case "$a1" in */temp_mask_all/service.sh) kill "$p" 2>/dev/null;; esac
  done
  rm -f "$PIDF"
}
startd(){
  rm -f "$PIDF"
  if command -v setsid >/dev/null 2>&1; then setsid sh "$MODDIR/service.sh" >/dev/null 2>&1 &
  else nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 & fi
  sleep 4
}

repair(){
  echo "===== 自动修复 ====="
  fixed=0
  # 1) 残留自检锁
  for L in "$LCK" "$LCK2"; do
    [ -f "$L" ] || continue
    lp=$(cat "$L" 2>/dev/null)
    case "$lp" in ''|*[!0-9]*) rm -f "$L"; fixed=1; echo "· 清掉格式不对的自检锁 $L" ;;
      *) [ -d "/proc/$lp" ] || { rm -f "$L"; fixed=1; echo "· 清掉残留自检锁（占用进程已退出）$L"; } ;;
    esac
  done
  # 2) 模块被禁用
  if [ -f "$MODDIR/disable" ]; then rm -f "$MODDIR/disable"; echo "· 模块之前处于禁用状态 → 已启用（想保持关闭请用 off）"; fixed=1; fi
  # 3) 守护进程
  P=$(cat "$PIDF" 2>/dev/null)
  if [ -z "$P" ] || [ ! -d "/proc/$P" ]; then
    startd
    P=$(cat "$PIDF" 2>/dev/null)
    if [ -n "$P" ] && [ -d "/proc/$P" ]; then echo "· 守护没在跑 → 已拉起 (pid=$P)"; else echo "· 守护拉起失败，看 $MASKLOG"; fi
    fixed=1
  else
    echo "· 守护正常 (pid=$P)"
  fi
  # 4) 充电状态
  st=$(cat "$B/status" 2>/dev/null)
  case "$st" in
    Charging|Full)
      echo "· 充电正常：status=$st 电流=$(cat $B/current_now 2>/dev/null)uA"
      if [ -f "$MODDIR/mask_off" ] || [ -f "$MODDIR/fast_off" ]; then
        rm -f "$MODDIR/mask_off" "$MODDIR/fast_off"
        echo "· 之前 rescue 关掉了伪装/快充，现在充电正常 → 已恢复"
        fixed=1
      fi
      ;;
    *)
      if [ "$(plugged)" = "1" ]; then
        echo "· 插着充电器却没在充电 → 交回官方策略（remove=0 + 档位回官方）"
        unmask; official
        echo "  ▶ 请拔插一次充电器；仍不行就是线材/充电头/尾插/电池"
        fixed=1
      else
        echo "· 没插充电器（跳过充电检查）"
      fi
      ;;
  esac
  # 5) 伪装是否真的写进去
  hit=0; samp=""
  for z in /sys/class/thermal/thermal_zone*; do
    [ -w "$z/emul_temp" ] || continue
    e=$(cat "$z/emul_temp" 2>/dev/null); t=$(cat "$z/temp" 2>/dev/null)
    [ -n "$samp" ] || samp="$(cat $z/type 2>/dev/null): temp=$t emul=$e"
    [ -n "$e" ] && [ "$e" != "0" ] && [ "$e" = "$t" ] && hit=$((hit+1))
  done
  if [ "$hit" -gt 0 ]; then echo "· 温度伪装在生效（抽查 $hit 个热区 = 伪装值：$samp）"
  else echo "· 温度伪装没生效（$samp）→ 再等 5 秒或重启；仍有问题把上面这段发给作者"; fi
  echo "===== 修复结束（改动 $fixed 处）====="
}

case "${1:-auto}" in
  auto|"")
    _v=$(grep "^version=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
    echo "亮屏快充+全面温度伪装 二合一 ${_v:-v3.0.2} —— 执行 = 自检 + 自动修复"
    echo "设备：$(getprop ro.product.brand) $(getprop ro.product.model)  $(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name) Android$(getprop ro.build.version.release)"
    echo
    if [ -f "$MODDIR/selfcheck.sh" ]; then 
      echo "########## 自检 ##########"
      sh "$MODDIR/selfcheck.sh"
      echo
    fi
    repair
    echo
    echo "########## 现在状态 ##########"
    sh "$MODDIR/action.sh" status
    ;;
  on|apply)
    rm -f "$MODDIR/disable" "$MODDIR/mask_off" "$MODDIR/fast_off"
    sh "$MODDIR/action.sh" fast on >/dev/null 2>&1
    P=$(cat "$PIDF" 2>/dev/null)
    [ -n "$P" ] && [ -d "/proc/$P" ] || startd
    sleep 2; sh "$MODDIR/action.sh" status;;
  off|restore)
    touch "$MODDIR/disable"; killd; unmask; official
    echo "已关闭：伪装撤掉、充电策略交回官方（充电器拔插一次即可）"; chgline;;
  selfcheck|check)
    sh "$MODDIR/selfcheck.sh";;
  repair|fix)
    repair;;
  mask)
    case "$2" in
      off) touch "$MODDIR/mask_off"; unmask; echo "温度伪装：已关闭";;
      on)  rm -f "$MODDIR/mask_off"; echo "温度伪装：已开启";;
      *)   printf "温度伪装="; [ -f "$MODDIR/mask_off" ] && echo off || echo on;;
    esac;;
  fast)
    case "$2" in
      off) touch "$MODDIR/fast_off"; official; echo "亮屏快充：已关闭（交回官方）";;
      on)  rm -f "$MODDIR/fast_off"; echo "亮屏快充：已开启";;
      *)   printf "亮屏快充="; [ -f "$MODDIR/fast_off" ] && echo off || echo on;;
    esac;;
  rescue)
    touch "$MODDIR/mask_off" "$MODDIR/fast_off"; killd; unmask; official
    sync; echo "rescue 完成：伪装已撤 + 充电策略已交回官方（拔插一次充电器即可）"; chgline;;
  status)
    printf "守护="; if [ -f "$PIDF" ] && kill -0 "$(cat $PIDF 2>/dev/null)" 2>/dev/null; then echo "running($(cat $PIDF))"; else echo "not running"; fi
    printf "  伪装="; [ -f "$MODDIR/mask_off" ] && echo off || echo on
    printf "  快充="; [ -f "$MODDIR/fast_off" ] && echo off || echo on
    if [ -f "$STATUS" ]; then grep -E '^(strategy|power_w|current_a|voltage_v|capacity|status|battery_temp|real_temp|gear|stock_gear|passthru)=' "$STATUS" 2>/dev/null | sed 's/^/  /'; else echo "  （没有状态文件，守护没跑）"; chgline; fi;;
  diag) [ -f "$DIAG" ] && cat "$DIAG" || echo "暂无诊断";;
  log)  echo "--- 伪装 ---"; tail -15 "$MASKLOG" 2>/dev/null; echo "--- 快充 ---"; tail -15 "$CHGLOG" 2>/dev/null;;
  *) echo "用法："; echo "  执行(不带参数) = 自检 + 自动修复"; echo "  on | off | rescue | selfcheck | repair | status | diag | log | mask on|off | fast on|off";;
esac
