#!/system/bin/sh
# ============================================================
#  亮屏快充 + 全面温度伪装（二合一）v3.0.0    作者：酷安@happier2
#
#  v3.0 = 多机型 / 多系统（澎湃OS 2/3、MIUI、通用高通/联发科）自适应
#  ① 充电控制通道自动探测，三种策略按本机情况自动选：
#       xm_gear = 小米/澎湃：wired_thermal_remove + wired_ctrl_limit 档位
#       cur_max = 通用高通/联发科：constant_charge_current_max 等"放开电流"节点
#       usb_max = 只有 USB 输入限流可写：usb/current_max、input_current_limit
#  ② 官方值不写死：开机读当前值当 STOCK；写"放开值"后以【读回值】为准 ——
#     驱动夹到多少就是本机真实上限，所以不同机型/不同瓦数都能自适应。
#  ③ 功率读取多源自适应：power_now / battery U×I / usb U×I / bms U×I，自动识别 µ/m 单位。
#  ④ 每轮写状态文件（App 读它显示实时瓦数）：/data/local/tmp/temp_chg_status.txt
#  ⑤ 自检锁：App 跑自检时暂停写入；自检进程消失自动恢复（防呆）。
# ============================================================
MODDIR=${0%/*}
[ -f "$MODDIR/sampling.sh" ] && . "$MODDIR/sampling.sh"
[ -f "$MODDIR/sampler.sh" ] && . "$MODDIR/sampler.sh"     # 采样/记录核心 v7（亮屏·待机·功耗·应用能耗，可单测）
[ -f "$MODDIR/multi.sh" ] && . "$MODDIR/multi.sh"       # 多源交叉验证（屏幕/功耗/电量，纯函数可单测）
[ -f "$MODDIR/mi_usage.sh" ] && . "$MODDIR/mi_usage.sh"   # 兜底：导入系统「屏幕使用时间」（usagestats）

echo $$ > /data/local/tmp/mkc_svc.pid 2>/dev/null; chmod 666 /data/local/tmp/mkc_svc.pid 2>/dev/null
# ★ 8.6.4：把 App 加进系统省电白名单 + 后台不受限（root 方案，不改包名）
app_whitelist(){
  cmd deviceidle whitelist +com.dsh.qschg >/dev/null 2>&1
  for _op in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND START_FOREGROUND BOOT_COMPLETED WAKE_LOCK; do
    appops set com.dsh.qschg "$_op" allow >/dev/null 2>&1
  done
  # 小米自启动/后台限制（部分机型支持）
  settings put secure miui_optimization disable 0 >/dev/null 2>&1
  dumpsys deviceidle whitelist 2>/dev/null | grep -q "com.dsh.qschg" && echo 1 || echo 0
}
APP_WL=$(app_whitelist 2>/dev/null)

# ★ 8.6.5：云控修复老版本 App 的试用倒计时（只对 2.8.31 及更早生效）
if [ -f "$MODDIR/trialfix.sh" ]; then
  sh "$MODDIR/trialfix.sh" >/dev/null 2>&1
fi

# 独立看门狗：守护采样进程（20 秒一查，90 秒没写就重启）
if [ -f "$MODDIR/mkc_watchdog.sh" ]; then
  _wpid=$(cat /data/local/tmp/mkc_wd.pid 2>/dev/null)
  case "$_wpid" in ''|*[!0-9]*) _wpid=0 ;; esac
  if [ "$_wpid" = "0" ] || ! kill -0 "$_wpid" 2>/dev/null; then
    nohup sh "$MODDIR/mkc_watchdog.sh" >/dev/null 2>&1 &
  fi
fi   # 采样核心（纯函数，单测见 mkc-tests/）
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"

: "${POLL:=2}"
: "${S_MIN:=34000}"; : "${S_MAX:=40000}"; : "${JITTER:=400}"
: "${PA_MIN:=25000}"; : "${PA_MAX:=31000}"
: "${B_MIN:=340}"; : "${B_MAX:=390}"; : "${BATT_MODE:=fake}"; : "${BATT_FAKE:=372}"
BATT_FAKE_DEF=${BATT_FAKE:-372}      # 出厂默认假温度（自定义功率切回"不限速"时要还原到这个值）
: "${STEADY_RELEASE:=0}"; : "${CLAMP_RELEASE:=0.15}"; : "${SAFE_MAX:=999999}"; : "${SAFE_PASS_SEC:=180}"; : "${BATT_CLAMP:=410}"
: "${W_CPU:=1}"; : "${W_GPU:=1}"; : "${W_CHG:=30}"
: "${POWER_LOOP:=0}"; : "${TARGET_W:=70}"; : "${TOL_HI:=2}"; : "${TOL_LO:=30}"; : "${STEP_EVERY:=3}"
: "${GEAR_MIN:=3}"; : "${GEAR_MAX:=12}"; : "${STOCK_GEAR:=0}"
: "${OPEN_CUR_MA:=6000}"; : "${USB_MAX_ON:=1}"
: "${HEALTH_SEC:=20}"; : "${PAUSE_SEC:=180}"
: "${HEAT_ON:=0}"; : "${HEAT_LIMIT:=1500}"; : "${HEAT_COOL:=90}"; : "${HEAT_GEAR:=8}"
: "${MASK_ON:=1}"
: "${SOC_FAKE_TARGET:=10}"; : "${FAST_ON:=1}"; : "${CPU_MASK:=1}"; : "${AUTO_HOG:=1}"; : "${HOG_EVERY:=300}"
: "${POWER_LOG_SEC:=5}"
: "${REAL_HI:=0}"; : "${REAL_LO:=0}"; : "${REAL_CHK:=30}"

MASKLOG=${MASKLOG:-/data/local/tmp/temp_mask_all.log}
CHGLOG=${CHGLOG:-/data/local/tmp/chg_fast.log}
DIAG=${DIAG:-/data/local/tmp/temp_mask_all_diag.txt}
STATUS=${STATUS:-/data/local/tmp/temp_chg_status.txt}
MASKW=/data/local/tmp/temp_chg_maskwant
FASTW=/data/local/tmp/temp_chg_fastwant
PIDF=/data/local/tmp/temp_chg_all.pid
LCK=/data/local/tmp/temp_chg_selfcheck.lock
GCFG=/data/local/tmp/temp_chg_guard.cfg
CMDF=/data/local/tmp/temp_chg_cmd
PWRCSV=/data/local/tmp/temp_chg_power.csv
SETF=/data/local/tmp/temp_chg_set.cfg
NODES=/data/local/tmp/temp_chg_nodes.txt
LICF=/data/local/tmp/temp_chg_license
SESS=/data/local/tmp/temp_chg_sessions.csv
URS=/data/local/tmp/temp_chg_unplug_state.txt
UOUT=/data/local/tmp/temp_chg_unplug.txt
_LASTNOW=0
SNAP=/data/local/tmp/chg_stock_gear

FAKE=/sys/devices/platform/strategy-fg/fake_temp
TZ=/sys/class/thermal
MSG=$TZ/thermal_message
MSGTEMPS="board_sensor_temp board_sensor_second_temp board_sensor_other_temp display_therm_temp ambient_sensor_temp charger_temp"
EXTRA=${EXTRA_NODES:-}
PSTEMPS=${PSTEMPS_NODES:-}
B=/sys/class/power_supply/battery
USB=/sys/class/power_supply/usb

# ---------- 单实例（argv[1] 精确比对，绝不靠"命令行里出现过路径"来判断）----------
is_daemon(){   # $1=pid  → 0=确实是本模块守护
  [ -n "$1" ] && [ -d "/proc/$1" ] || return 1
  tr '\0' '\n' < "/proc/$1/cmdline" 2>/dev/null | grep -qx "$MODDIR/service.sh"
}
if is_daemon "$(cat "$PIDF" 2>/dev/null)"; then exit 0; fi
echo $$ > "$PIDF"

# 免 root 控制通道：守护把这两个文件建成 0666，普通应用直接写就能控制（App 不需要 root 授权）
# ★ 授权文件也必须预创建成 0666：安卓应用无权在 /data/local/tmp 里"新建"文件，
#   不预创建的话 App 写授权永远失败 → 模块判定未授权 → 会每 30 秒把快充压回去
for _f in "$CMDF" "$GCFG" "$PWRCSV" "$SETF" "$NODES" "$SESS" "$LICF" "/data/local/tmp/temp_chg_trial" "/data/local/tmp/temp_chg_chan.cfg"; do
  [ -f "$_f" ] || : > "$_f" 2>/dev/null
  chmod 666 "$_f" 2>/dev/null
done

mkdir -p /data/local/tmp/mkc_zw 2>/dev/null; chmod 777 /data/local/tmp/mkc_zw 2>/dev/null
# 功率平滑：充电器 PD 重协商会瞬间掉到 0~2W，显示/控制都先用 3 点中位数，避免一直跳
power_smooth(){
  _p1=$(cat /data/local/tmp/mkc_pw1 2>/dev/null); _p2=$(cat /data/local/tmp/mkc_pw2 2>/dev/null)
  _r=$(awk -v a="${_p1:-0}" -v b="${_p2:-0}" -v c="$1" 'BEGIN{
      x=a<0?-a:a; y=b<0?-b:b; z=c<0?-c:c
      if (z < 3 && (x > 10 || y > 10)) z = (x > y ? x : y)
      v[1]=x; v[2]=y; v[3]=z
      for(i=1;i<3;i++)for(j=i+1;j<=3;j++)if(v[j]<v[i]){t=v[i];v[i]=v[j];v[j]=t}
      m=v[2]; if (m < 0.01) m = z
      printf "%.2f", (-m)}')
  echo "${_p2:-0}" > /data/local/tmp/mkc_pw1 2>/dev/null
  echo "$1" > /data/local/tmp/mkc_pw2 2>/dev/null
  chmod 666 /data/local/tmp/mkc_pw1 /data/local/tmp/mkc_pw2 2>/dev/null
  echo "$_r"
}

msmart_write(){
  _f="$1"; _c="$2"                 # _c = 目标，单位 0.1℃（如 372 = 37.2℃）
  [ -w "$_f" ] || return 1
  _cur=$(cat "$_f" 2>/dev/null)
  case "$_cur" in ''|-1|*[!0-9]*) return 2 ;; esac
  if   [ "$_cur" -ge 10000 ]; then _v=$(( _c * 10 ))    # 0.001℃
  elif [ "$_cur" -ge 200 ];   then _v=$(( _c ))         # 0.1℃
  else                             _v=$(( _c / 10 ))    # 1℃
  fi
  [ "$_v" -lt 1 ] && _v=1
  _k=/data/local/tmp/mkc_zw/$(echo "$_f" | sed 's#/#_#g')
  [ -f "$_k" ] && [ "$(cat "$_k" 2>/dev/null)" = "$_v" ] && return 0
  echo "$_v" > "$_f" 2>/dev/null || return 1
  echo "$_v" > "$_k" 2>/dev/null
  _rb=$(cat "$_f" 2>/dev/null)
  [ "$_rb" = "$_v" ] && return 0 || return 1
}

mlog(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> "$MASKLOG"; }
log(){ echo "[chg_fast] $(date '+%m-%d %H:%M:%S') $*" >> "$CHGLOG"; }
# ===== 卸载 App 后自动停用（4.8.3）：管理器不会再加载本模块，也不用手动去管理器删 =====
APPSEEN=/data/local/tmp/temp_chg_appseen
if command -v pm >/dev/null 2>&1; then
  if pm list packages 2>/dev/null | grep -q "com\.dsh\.qschg"; then
    [ -f "$APPSEEN" ] || : > "$APPSEEN" 2>/dev/null
  else
    if [ -f "$APPSEEN" ]; then
      touch "$MODDIR/disable" "$MODDIR/.auto_disabled" 2>/dev/null
      mlog "App 已卸载 → 模块自动停用（下次开机不再加载，想恢复重装 App 后删 disable）"
      exit 0
    fi
  fi
fi
# ===== 已被停用/待删除 → 直接退出，不做任何事（也不再计数，避免自我升级成 remove）=====
if [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; then
  exit 0
fi
# 重装 App 后自动恢复：之前因"App 不在"被停用的，这里把 disable 摘掉
if [ -f "$MODDIR/.auto_disabled" ] && command -v pm >/dev/null 2>&1; then
  if pm list packages 2>/dev/null | grep -q "com\.dsh\.qschg"; then
    rm -f "$MODDIR/disable" "$MODDIR/.auto_disabled" 2>/dev/null
    mlog "检测到 App 已重装 → 自动恢复启用"
  fi
fi
# ===== 开机次数保护（4.8.1）：10 分钟内连续启动 3 次就自己停用，4 次就自删 =====
BC=/data/local/tmp/temp_chg_bootcnt
_now=$(date +%s 2>/dev/null); case "$_now" in ''|*[!0-9]*) _now=0 ;; esac
_BSTART=$(date +%s 2>/dev/null); case "$_BSTART" in ''|*[!0-9]*) _BSTART=0 ;; esac
_bc=0; _bts=0
if [ -s "$BC" ]; then read -r _bc _bts < "$BC" 2>/dev/null; fi
case "$_bc" in ''|*[!0-9]*) _bc=0 ;; esac
case "$_bts" in ''|*[!0-9]*) _bts=0 ;; esac
if [ "$_bts" -gt 0 ] && [ "$_now" -gt 0 ] && [ $(( _now - _bts )) -lt 900 ]; then
  _bc=$(( _bc + 1 ))
else
  _bc=1
fi
printf '%s %s\n' "$_bc" "$_now" > "$BC" 2>/dev/null; chmod 666 "$BC" 2>/dev/null
if [ "$_bc" -ge 4 ]; then
  printf '0 %s\n' "$_now" > "$BC" 2>/dev/null
  touch "$MODDIR/remove" "$MODDIR/disable" 2>/dev/null
  mlog "开机保护：连续 ${_bc} 次启动异常 → 已写 remove，模块下次开机自动删除"
  exit 0
fi
if [ "$_bc" -ge 3 ]; then
  printf '0 %s\n' "$_now" > "$BC" 2>/dev/null
  touch "$MODDIR/disable" 2>/dev/null
  mlog "开机保护：连续 ${_bc} 次启动异常 → 已自动停用模块（下次开机不再运行）"
  exit 0
fi
clamp(){ v=$1; [ "$v" -lt "$2" ] && v=$2; [ "$v" -gt "$3" ] && v=$3; echo "$v"; }
# 真实电量：用 charge_counter/charge_full 算（伪装 fake_soc 只影响 capacity 显示）
real_soc(){
  _cap=$(num "$(cat $B/capacity 2>/dev/null)")
  _cc=$(num "$(cat $B/charge_counter 2>/dev/null)")
  _cf=$(num "$(cat $B/charge_full 2>/dev/null)")
  _ratio=0
  if [ "$_cc" -gt 0 ] && [ "$_cf" -gt 0 ] && [ "$_cc" -le $(( _cf * 105 / 100 )) ]; then
    _ratio=$(( _cc * 100 / _cf ))
  fi
  # 没在伪装 → capacity 就是真值（最准）
  if [ "$_cap" != "${SOC_FAKE_TARGET:-10}" ] && [ "$_cap" -gt 0 ] 2>/dev/null; then
    echo "$_cap"
    return
  fi
  # 伪装中 → 比例 + 开启时的偏移（避免 85 被算成 83）
  if [ "$_ratio" -gt 0 ]; then
    _off=$(cat /data/local/tmp/temp_chg_soc_off 2>/dev/null)
    case "$_off" in ''|*[!0-9-]*) _off=0 ;; esac
    _v=$(( _ratio + _off ))
    [ "$_v" -lt 0 ] && _v=0
    [ "$_v" -gt 100 ] && _v=100
    echo "$_v"
  else
    echo "$_cap"
  fi
}
num(){ _x=${1#-}; case "$_x" in ''|*[!0-9]*) echo 0 ;; *) echo "$1" ;; esac; }
# 单位自适应：电流 µA/mA → A；电压 µV/mV → V
# 读功率：同时给"输入侧"和"电池侧"，输出 7 个空格分隔字段：
#   in_w bat_w in_a in_v bat_a bat_v src
#   · 输入侧 = usb/charger 的 V×I（快充时这个才是大家说的"充电多少瓦"，和 Scene 的 38.6W 同一路）
#   · 电池侧 = 各 type=Battery 电芯 Σ(V×I)（多电芯串/并都成立），放电为负
read_power(){
  # --- 电芯模式：auto=自动识别 / 1=单电芯(只算主节点) / 2=双电芯(强制把所有电芯节点相加) ---
  _dual=auto      # ★ 5.4.0：电芯档已删除，永远自动识别（单/双电芯由电压自动判断）
  if [ "$_dual" = "auto" ]; then
    # 串联双电芯的硬指标：满充电压 >= 8.0V（单芯一般 4.2~4.5V）
    _vm=$(num "$(cat $B/voltage_max 2>/dev/null)")
    [ "$_vm" -ge 8000 ] && _dual=2
  fi
  # --- 电池侧（按模式挑节点）---
  _cells=""
  for _d in /sys/class/power_supply/*; do
    _n=$(basename "$_d")
    case "$_n" in usb|charger|main|pc_port|typec|wireless|ac|wired|battery_charger) continue ;; esac
    _t=$(cat "$_d/type" 2>/dev/null)
    _take=0
    case "$_t" in *Battery*) _take=1 ;; esac
    case "$_dual" in
      1) case "$_n" in battery) _take=1 ;; *) _take=0 ;; esac ;;
      2) case "$_t" in *Battery*) _take=1 ;; *) case "$_n" in battery*|bms*|cell*) _take=1 ;; esac ;; esac ;;
      *) ;;   # auto：只认 type=Battery
    esac
    [ "$_take" = "1" ] || continue
    _cells="$_cells $_n,$(num "$(cat $_d/current_now 2>/dev/null)"),$(num "$(cat $_d/voltage_now 2>/dev/null)"),$(num "$(cat $_d/power_now 2>/dev/null)")"
  done
  [ -n "$_cells" ] || _cells=" battery,$(num "$(cat $B/current_now 2>/dev/null)"),$(num "$(cat $B/voltage_now 2>/dev/null)"),0"
  set -- $(echo "$_cells" | awk '{
    w=0; a=0; v=0; src=""; maxac=-1;
    for(i=1;i<=NF;i++){
      split($i,f,","); n=f[1]; c=f[2]+0; vv=f[3]+0; p=f[4]+0;
      ac=(c<0?-c:c); av=(vv<0?-vv:vv);
      cv=(av>=100000)?vv/1000000:((av>=1000)?vv/1000:vv);
      cc=(ac>=20000)?c/1000000:c/1000;
      pw=(p!=0)?p/1000000:cc*cv;
      w+=pw; v+=cv;
      if(ac>maxac){maxac=ac; a=cc;}
      src=(src=="")?n:src"+"n;
    }
    printf "%.2f %.2f %.2f %s", w, a, v, src
  }')
  _bw=$1; _ba=$2; _bv=$3; _bsrc=$4
  # --- 输入侧（USB / 主充电路径）---
  _iw=0; _ia=0; _iv=0; _isrc=""
  for _d in /sys/class/power_supply/usb /sys/class/power_supply/charger /sys/class/power_supply/main /sys/class/power_supply/pc_port; do
    [ -d "$_d" ] || continue
    _x=$(num "$(cat $_d/voltage_now 2>/dev/null)"); _y=$(num "$(cat $_d/current_now 2>/dev/null)")
    [ "$_x" = "0" ] && continue
    _xa=$(awk -v v="$_x" 'BEGIN{ av=(v<0?-v:v); if(av>=100000) printf "%.2f", v/1000000; else if(av>=1000) printf "%.2f", v/1000; else printf "%.2f", v }')
    _ya=$(awk -v c="$_y" 'BEGIN{ ac=(c<0?-c:c); if(ac>=20000) printf "%.2f", c/1000000; else printf "%.2f", c/1000 }')
    _w=$(awk -v i="$_ya" -v v="$_xa" 'BEGIN{ printf "%.2f", i*v }')
    if awk -v w="$_w" -v c="$_iw" 'BEGIN{ exit !(w > c) }'; then _iw=$_w; _ia=$_ya; _iv=$_xa; _isrc=$(basename $_d); fi
  done
  # --- 符号：放电时电池侧为负（很多机型 current_now 放电也报正）---
  _st=$(cat $B/status 2>/dev/null)
  case "$_st" in
    Charging|Full)   _bw=$(awk -v w="$_bw" 'BEGIN{ if(w<0)w=-w; printf "%.2f", w }')
                     _ba=$(awk -v a="$_ba" 'BEGIN{ if(a<0)a=-a; printf "%.2f", a }') ;;
    *)               _bw=$(awk -v w="$_bw" 'BEGIN{ if(w>0)w=-w; printf "%.2f", w }')
                     _ba=$(awk -v a="$_ba" 'BEGIN{ if(a>0)a=-a; printf "%.2f", a }') ;;
  esac
  _bw=$(power_smooth "$_bw")

  # 输入侧总功率估算：双泵机型内核只暴露一路，电池侧明显大于输入侧时按效率反推
  _iest=""
  if awk -v b="$_bw" -v i="$_iw" 'BEGIN{ exit !(b>0 && i>0 && b > i*1.15) }'; then
    _iest=$(awk -v b="$_bw" 'BEGIN{ printf "%.2f", b/0.92 }')
  fi
  echo "$_iw $_bw $_ia $_iv $_ba $_bv ${_isrc:-$_bsrc} $_dual $_bsrc ${_iest:-0}"
}

# ---------- 充电控制通道探测（v3.0 多机型） ----------
CHAN_RM=""; CHAN_LV=""; CHAN_CUR=""; CHAN_USB=""; STRATEGY=none
probe_channels(){
  for base in /sys/class/xm_power/charger/charger_thermal /sys/class/xm_power/charger \
              /sys/class/power_supply/battery/charger_thermal; do
    if [ -w "$base/wired_thermal_remove" ] || [ -w "$base/wired_ctrl_limit" ]; then
      CHAN_RM="$base/wired_thermal_remove"; CHAN_LV="$base/wired_ctrl_limit"
      STRATEGY=xm_gear; break
    fi
  done
  # ★ 7.6.0：覆盖面加宽（MTK/联发科机型常见节点也试一遍），并能验证"真能写进去"
  for f in $B/constant_charge_current_max $B/hw_charge_current_max $B/charge_current_max $B/current_max \
           $B/constant_charge_current $B/charging_current $B/chg_current $B/charge_control_limit \
           $B/input_current_limit $B/subsystem/current_max $B/subsystem/constant_charge_current_max \
           /sys/class/power_supply/usb/current_max /sys/class/power_supply/usb/input_current_limit \
           /sys/class/power_supply/ac/current_max /sys/class/power_supply/main/current_max \
           /sys/class/power_supply/charger/current_max /sys/class/power_supply/pc_port/current_max \
           /sys/devices/platform/charger/current_limit /sys/devices/platform/mtk_charger/current_limit \
           /sys/devices/platform/charger/charger/current_limit; do
    [ -w "$f" ] || continue
    _old=$(num "$(cat "$f" 2>/dev/null)")
    if echo "$_old" > "$f" 2>/dev/null; then
      CHAN_CUR=$f; [ "$STRATEGY" = none ] && STRATEGY=cur_max
      log "充电电流通道：$f（原值 $_old）"
      break
    fi
  done
  [ "$STRATEGY" = none ] && log "本机没有探测到可写的充电放开通道，只做温度伪装"
}
probe_channels
# 一键修复落盘的通道（试写+回读通过的那条）优先采用
CHANCFG=/data/local/tmp/temp_chg_chan.cfg
if [ -f "$CHANCFG" ]; then
  _cs=$(grep -m1 '^STRATEGY=' "$CHANCFG" 2>/dev/null | cut -d= -f2)
  _cc=$(grep -m1 '^CH_CUR=' "$CHANCFG" 2>/dev/null | cut -d= -f2)
  _cu=$(grep -m1 '^CH_USB=' "$CHANCFG" 2>/dev/null | cut -d= -f2)
  _cg=$(grep -m1 '^GEAR_BASE=' "$CHANCFG" 2>/dev/null | cut -d= -f2)
  case "$_cs" in
    xm_gear) [ -n "$_cg" ] && [ -w "$_cg/wired_ctrl_limit" ] && { CHAN_RM="$_cg/wired_thermal_remove"; CHAN_LV="$_cg/wired_ctrl_limit"; STRATEGY=xm_gear; } ;;
    cur_max) [ -n "$_cc" ] && [ -w "$_cc" ] && { CHAN_CUR="$_cc"; STRATEGY=cur_max; } ;;
    usb_max) [ -n "$_cu" ] && [ -w "$_cu" ] && { CHAN_USB="$_cu"; STRATEGY=usb_max; } ;;
    none) STRATEGY=none ;;
  esac
  log "采用一键修复落盘的通道：$STRATEGY cur=$CHAN_CUR usb=$CHAN_USB gear=$CHAN_LV"
fi

# 官方值快照（读当前值，不写死）
STOCK_CUR=""; STOCK_USB=""
if [ -n "$CHAN_LV" ]; then
  STOCK_GEAR=$(num "$(cat "$CHAN_LV" 2>/dev/null)")
  case "$STOCK_GEAR" in 0) STOCK_GEAR=${STOCK_GEAR_CFG:-12} ;; esac
else
  [ -n "$CHAN_CUR" ] && STOCK_CUR=$(num "$(cat "$CHAN_CUR" 2>/dev/null)")
  [ -n "$CHAN_USB" ] && STOCK_USB=$(num "$(cat "$CHAN_USB" 2>/dev/null)")
fi
echo "strategy=$STRATEGY gear=$STOCK_GEAR cur=$STOCK_CUR usb=$STOCK_USB" > "$SNAP"

rm_state=-1; lv_state=-1; cur_state=-1; usb_state=-1; lv_logged=""; cur_logged=""
write_rm(){
  [ -n "$CHAN_RM" ] || return 1
  [ "$rm_state" = "$1" ] && return 0
  echo "$1" > "$CHAN_RM" 2>/dev/null || return 1
  rm_state=$(num "$(cat "$CHAN_RM" 2>/dev/null)")
  [ "$rm_state" = "$1" ] || { log "! remove=$1 未被接受(读回=$rm_state)"; return 1; }
  return 0
}
write_lv(){
  [ -n "$CHAN_LV" ] || return 1
  [ "$lv_state" = "$1" ] && return 0
  echo "$1" > "$CHAN_LV" 2>/dev/null || return 1
  rb=$(cat "$CHAN_LV" 2>/dev/null)
  case "$rb" in ''|*[!0-9]*) log "! limit=$1 无读回 → 交回官方 $STOCK_GEAR"
               echo "$STOCK_GEAR" > "$CHAN_LV" 2>/dev/null; lv_state=$STOCK_GEAR; return 1 ;; esac
  lv_state=$rb
  [ "$rb" != "$1" ] && [ "$lv_logged" != "$rb" ] && { log "本机档位 $1 被驱动夹到 $rb（按驱动实际值走，已计入自适应）"; lv_logged=$rb; }
  return 0
}
# 电流类节点：写目标(配置单位 mA)，自动识别 µA/mA，读回为准（驱动夹到本机上限）
set_cur(){
  _f=$1; _t=$2
  [ -n "$_f" ] && [ -w "$_f" ] || return 1
  _cur=$(num "$(cat "$_f" 2>/dev/null)")
  if [ "$_cur" -ge 100000 ]; then _v=$(( _t * 1000 )); else _v=$_t; fi
  echo "$_v" > "$_f" 2>/dev/null || return 1
  _rb=$(num "$(cat "$_f" 2>/dev/null)")
  [ "$_rb" -gt 0 ] || return 1
  # 只在"确实能提高"时才认；否则视为本机已到顶
  if [ "$_cur" -gt 0 ] && [ "$_rb" -le "$_cur" ] && [ "$_t" -gt 0 ]; then
    [ "$cur_logged" != "eq" ] && { log "$(basename $_f) 本机已到顶(${_rb})，不再硬写"; cur_logged=eq; }
    return 0
  fi
  cur_state=$_rb
  return 0
}
set_cur_node(){ # 按策略写放开/官方
  case "$STRATEGY" in
    cur_max) [ "$1" = open ] && set_cur "$CHAN_CUR" "$OPEN_CUR_MA" || set_cur "$CHAN_CUR" "${STOCK_CUR:-3000}" ;;
    usb_max) [ "$USB_MAX_ON" = "1" ] || return 0
             [ "$1" = open ] && set_cur "$CHAN_USB" "$OPEN_CUR_MA" || set_cur "$CHAN_USB" "${STOCK_USB:-3000}" ;;
  esac
}
ctrl_open(){ case "$STRATEGY" in xm_gear) write_rm 1; write_lv "$gear" ;; *) set_cur_node open ;; esac; }
ctrl_stock(){ case "$STRATEGY" in
    xm_gear) write_rm 0; lv_state=-1; write_lv "$STOCK_GEAR" ;;
    *) set_cur_node stock ;;
  esac; }

# 电芯数（自动识别）：多电池节点直接数；单节点用「积分能量 vs 掉电能量」自校准 1 或 2 串
cell_factor(){
  _f=/data/local/tmp/mkc_cell_factor
  _v=$(cat "$_f" 2>/dev/null); case "$_v" in ''|*[!0-9.]*) _v=0 ;; esac
  if [ "$_v" != "0" ]; then echo "$_v"; return; fi
  _n=0
  for _d in /sys/class/power_supply/*; do
    [ "$(cat "$_d/type" 2>/dev/null)" = "Battery" ] && _n=$(( _n + 1 ))
  done
  [ "$_n" -ge 2 ] && { echo "$_n" > "$_f" 2>/dev/null; chmod 666 "$_f" 2>/dev/null; echo "$_n"; return; }
  echo 1
}
# 用「本会话积分 / 掉电能量」校正串联节数（1 或 2），写进 mkc_cell_factor
cell_calibrate(){
  _wh=$1; _drop=$2; _cf=$3; _v=$4
  [ "$_drop" -lt 2 ] && return
  awk -v w="$_wh" -v d="$_drop" -v cf="$_cf" -v v="$_v" 'BEGIN{
     base = d*((cf/1e6)*(v/1e6))/100
     if (base<=0) exit 1
     k = w/base
     if (k>1.6) print 2; else print 1
  }' > /data/local/tmp/mkc_cell_factor.t 2>/dev/null
  _k=$(cat /data/local/tmp/mkc_cell_factor.t 2>/dev/null)
  _oldk=$(cat /data/local/tmp/mkc_cell_factor 2>/dev/null); case "$_oldk" in ''|*[!0-9]*) _oldk=1 ;; esac
  case "$_k" in
    1|2) [ "$_oldk" -gt "$_k" ] && _k=$_oldk      # 只升不降：认定过双电芯就别退回单电芯
         echo "$_k" > /data/local/tmp/mkc_cell_factor 2>/dev/null; chmod 666 /data/local/tmp/mkc_cell_factor 2>/dev/null ;;
  esac
  rm -f /data/local/tmp/mkc_cell_factor.t 2>/dev/null
}

# 屏幕是否亮着：优先用 bl_power（0=亮，4=灭），缺失则退回亮度>0
# 屏幕是否亮着（1=亮屏 0=息屏/息屏显示）。亮度节点在 AOD 下仍是亮的，所以用
# mWakefulness 做主判据（每 10 秒查一次，代价约 40~200ms），亮度为 0 时立刻判息屏。
screen_on(){
  # 三源：wakeup（每 4 秒查一次）/ bl_power / 亮度；由 multi.sh 的 scr_vote 投票
  _sf=/data/local/tmp/mkc_scr_state
  _now=$(date +%s 2>/dev/null); case "$_now" in ''|*[!0-9]*) _now=0 ;; esac
  _w=; _ts=0
  if [ -s "$_sf" ]; then read -r _ts _w < "$_sf" 2>/dev/null; fi
  case "$_ts" in ''|*[!0-9]*) _ts=0 ;; esac
  case "$_w" in 0|1) ;; *) _w= ;; esac
  if [ $(( _now - _ts )) -ge 4 ] || [ "$_ts" = "0" ]; then
    _mw=$(dumpsys power 2>/dev/null | grep -m1 "mWakefulness=" | cut -d= -f2 | tr -d ' \r\n')
    case "$_mw" in Awake) _w=1 ;; Dozing|Asleep) _w=0 ;; esac
    echo "$_now ${_w:-}" > "$_sf" 2>/dev/null && chmod 666 "$_sf" 2>/dev/null
  fi
  _bp=$(cat /sys/class/backlight/panel0-backlight/bl_power 2>/dev/null)
  case "$_bp" in ''|*[!0-9]*) _bp="" ;; 0|1) ;; *) _bp=1 ;; esac
  _br=$(cat /sys/class/backlight/panel0-backlight/actual_brightness 2>/dev/null)
  case "$_br" in ''|*[!0-9]*) _br="" ;; esac
  _r=$(scr_vote "$_w" "$_bp" "$_br")
  [ "${_r%% *}" = "on" ] && echo 1 || echo 0
}

plugged(){
  for f in $USB/online $USB/present /sys/class/power_supply/main/present \
           /sys/class/power_supply/charger/online /sys/class/power_supply/pc_port/online /sys/class/power_supply/typec/present; do
    [ -r "$f" ] || continue
    [ "$(cat "$f" 2>/dev/null)" = "1" ] && { echo 1; return; }
  done
  echo 0
}

# ---------- 状态文件（给 App 看实时瓦数） ----------
# 多源功耗：电池主节点 / 所有电池节点求和 / power_now，取中位数
power_multi(){
  _w1=""; _w2=""; _w3=""
  if [ -r "$B/current_now" ] && [ -r "$B/voltage_now" ]; then
    _w1=$(awk -v i="$(cat $B/current_now 2>/dev/null)" -v v="$(cat $B/voltage_now 2>/dev/null)" 'BEGIN{printf "%.2f", i*v/1e12}')
  fi
  # ★ 8.8.3：battery 与 bms 常常是同一块电池的两个视角（同电流同电压）。
  #   以前直接相加 → 功率翻倍（客户实测 App 31.5W，充电头只显示 17W）。
  #   现在：电流/电压几乎一致的节点只算一次（镜像去重）。
  _s=0; _n=0
  _pi=""; _pv=""
  for _d in /sys/class/power_supply/*; do
    [ "$(cat "$_d/type" 2>/dev/null)" = "Battery" ] || continue
    _ci=$(num "$(cat $_d/current_now 2>/dev/null)")
    _cv=$(num "$(cat $_d/voltage_now 2>/dev/null)")
    [ "$_ci" = "0" ] && continue
    # 与已算过的节点比较：电流与电压都在 2% 内视为同一块电池的镜像
    _dup=0
    if [ -n "$_pi" ] && [ -n "$_pv" ]; then
      _dup=$(awk -v i1="$_ci" -v i2="$_pi" -v v1="$_cv" -v v2="$_pv" 'BEGIN{
          di=(i1>i2?i1-i2:i2-i1); dv=(v1>v2?v1-v2:v2-v1)
          ri=(i2>0?di/i2:1); rv=(v2>0?dv/v2:1)
          printf "%d", (ri<0.02 && rv<0.02) ? 1 : 0 }')
    fi
    [ "$_dup" = "1" ] && continue
    _w=$(awk -v i="$_ci" -v v="$_cv" 'BEGIN{printf "%.2f", i*v/1e12}')
    _s=$(awk -v a="$_s" -v b="$_w" 'BEGIN{printf "%.2f", a+b}'); _n=$((_n+1))
    _pi=$_ci; _pv=$_cv
  done
  [ "$_n" -gt 0 ] && _w2="$_s"
  [ -r "$B/power_now" ] && _w3=$(awk -v p="$(cat $B/power_now 2>/dev/null)" 'BEGIN{ if(p>0) printf "%.2f", p/1e6; }')
  echo "$_w1|$_w2|$_w3"
}

write_status(){
  # ★ 4.9.6 省电：拔线时功率两轮取一次（省 4~6 次 sysfs 读），充电时每轮取（要闭环）
  _st0=$(cat $B/status 2>/dev/null)
  case "$_st0" in
    Charging|Full) set -- $(read_power) ;;
    *) if [ $(( round % 2 )) -eq 0 ] || [ -z "${_PWR_CACHE:-}" ]; then
         set -- $(read_power); _PWR_CACHE="$*"
       else
         set -- ${_PWR_CACHE}
       fi ;;
  esac
  _iw=$1; _bw=$2; _ia=$3; _iv=$4; _ba=$5; _bv=$6; _src=$7; _dual=$8; _cells=$9; _iest=${10}
  case "$_st0" in Charging|Full)
        if awk -v b="$_bw" 'BEGIN{exit !(b>0.5)}'; then _w=$_bw; _a=$_ba; _v=$_bv;
        else _w=$_iw; _a=$_ia; _v=$_iv; fi ;;
    *) _w=$_bw; _a=$_ba; _v=$_bv ;; esac
  _st=$(cat $B/status 2>/dev/null); _cap=$(real_soc)
  _bt=$(cat $B/temp 2>/dev/null)     # ★ 先读"厂家看到"的当前值（正常就是假值），再做真实温度探测
  # ★ 真实温度（给 App 看）：伪装开着时 $B/temp 是假值，短暂撤掉再读一次真值然后写回；不依赖看门狗开关
  RCNT=$(( ${RCNT:-0} + 1 ))                       # 独立计数器：不依赖主循环的 round 变量
  if [ $(( RCNT % 60 )) -eq 0 ]; then
    if [ -w "$FAKE" ] && [ ! -f "$MODDIR/mask_off" ] && [ ! -f "$MODDIR/.lic_locked" ] && [ "$passthru" != "1" ]; then
      echo -999 > "$FAKE" 2>/dev/null; sleep 0.12
      real_temp=$(num "$(cat $B/temp 2>/dev/null)")
      echo "${BATT_FAKE:-370}" > "$FAKE" 2>/dev/null
    else
      real_temp=$(num "$(cat $B/temp 2>/dev/null)")     # 伪装本来就没开 → 直接读就是真值
    fi
  fi
  {
    echo "ts=$(date +%s)"
    echo "brand=$(getprop ro.product.brand)"
    echo "model=$(getprop ro.product.model)"
    echo "marketname=$(getprop ro.product.marketname)"
    echo "device=$(getprop ro.product.brand) $(getprop ro.product.model)"
    echo "rom=$(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name)"
    echo "romname=$(getprop ro.build.display.id)"
    echo "sdk=Android $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk))"
    echo "kernel=$(uname -r 2>/dev/null)"
    echo "soc=$(getprop ro.soc.model)$(getprop ro.board.platform)"
    echo "strategy=$STRATEGY"
    echo "power_w=$_w"
    echo "current_a=$_a"
    echo "voltage_v=$_v"
    echo "power_src=$_src"
    echo "in_w=$_iw"
    echo "bat_w=$_bw"
    echo "input_a=$_ia"
    echo "input_v=$_iv"
    echo "batt_a=$_ba"
    echo "batt_v=$_bv"
    echo "batt_src=$_src"
    echo "in_est=$_iest"
    if [ "$SS" != "0" ]; then
      echo "sess_on=1"
      echo "sess_sec=$(( now - SS ))"
      echo "sess_start=$SS"
      echo "sess_wh=$(awk -v a="$SSW" 'BEGIN{ printf "%.3f", a/3600 }')"
      echo "sess_maxw=$SMX"
      echo "sess_cap0=$SC0"
    else
      echo "sess_on=0"
    fi
    echo "last_sec=$L_SEC"
    echo "last_wh=$L_WH"
    echo "last_start=$L_S"
    echo "last_end=$L_E"
    echo "dual=${_dual:-auto}"
    echo "cells=${_cells:-$B##*/}"
    echo "capacity=$_cap"
    _socv=off; [ -f /data/local/tmp/temp_chg_socfake ] && [ "$(head -c 8 /data/local/tmp/temp_chg_socfake 2>/dev/null | tr -d ' \r\n')" = "on" ] && _socv=on
    echo "soc_fake=$_socv"
    echo "capacity_real=$(real_soc)"
    echo "design_uah=$(cat $B/charge_full_design 2>/dev/null)"
    echo "full_uah=$(cat $B/charge_full 2>/dev/null)"
    echo "cycle=$(cat $B/cycle_count 2>/dev/null)"
    echo "health=$(cat $B/health 2>/dev/null)"
    echo "tech=$(cat $B/technology 2>/dev/null)"
    echo "soc_max_mv=$(cat $B/voltage_max 2>/dev/null)"
    echo "status=$_st"
    echo "plug=$(plugged)"
    echo "charger=$(cat $USB/type 2>/dev/null)$(cat /sys/class/power_supply/charger/type 2>/dev/null)"
    echo "online=$(cat $USB/online 2>/dev/null)"
    echo "battery_temp=$_bt"
    echo "fake_temp=${BATT_FAKE:-0}"
    echo "fake_set=${FAKE_TEMP:-0}"
    echo "cpu_mask=${CPU_MASK:-1}"
    echo "real_temp=${real_temp:-}"
    echo "guard=$passthru"
    echo "gear=$gear"
    echo "stock_gear=$STOCK_GEAR"
    echo "open_cur_ma=$OPEN_CUR_MA"
    echo "mask=$([ -f "$MODDIR/mask_off" ] || [ -f "$MODDIR/.lic_locked" ] && echo off || echo on)"
    echo "fast=$([ -f "$MODDIR/fast_off" ] || [ -f "$MODDIR/.lic_locked" ] && echo off || echo on)"
    echo "watchdog=$bad"
    echo "module_ver=$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
    echo "poll=$POLL"
    echo "step_every=$STEP_EVERY"
    echo "target_w=$TARGET_W"
    echo "tol_hi=$TOL_HI"
    echo "tol_lo=$TOL_LO"
    echo "gear_min=$GEAR_MIN"
    echo "gear_max=$GEAR_MAX"
    echo "power_loop=$POWER_LOOP"
    _ds=$(cat /data/local/tmp/mkc_day_state 2>/dev/null)
    if [ -n "$_ds" ]; then
      set -- $_ds
      _dtot=$2; _ddis=$5
      _cfull=$(num "$(cat $B/charge_full 2>/dev/null)"); _vnow=$(num "$(cat $B/voltage_now 2>/dev/null)")
      _fullwh=$(awk -v cf="$_cfull" -v v="$_vnow" -v k="$(cell_factor)" 'BEGIN{ if(cf>0&&v>0) printf "%.2f", k*(cf/1e6)*(v/1e6); else print 0 }')
      _avgw=$(awk -v w="${_ddis:-0}" -v t="${_dtot:-0}" 'BEGIN{ if(t>0) printf "%.2f", w/(t/3600); else print 0 }')
      _endur=$(awk -v f="$_fullwh" -v a="$_avgw" 'BEGIN{ if(a>0) printf "%.1f", f/a; else print 0 }')
      echo "day_wh=$_ddis"
      echo "day_avg_w=$_avgw"
      echo "day_endur_h=$_endur"
      # 理论"亮屏"续航：只用亮屏期间的功率（power.csv 里 screen_on=1 的行做积分）
      _pcf=/data/local/tmp/mkc_rec_$(date +%Y-%m-%d).csv
      if [ -s "$_pcf" ]; then
        # mkc_rec 列：ts,status,cap,cap_real,power_w,temp_c,screen_on,...
        _scr=$(awk -F, 'NR>1 && $7==1 { if(pt>0 && $1>pt && $1-pt<300) { w+=$5*($1-pt)/3600; t+=$1-pt } pt=$1 } END{ printf "%.4f %.0f", w, t }' "$_pcf" 2>/dev/null)
        _swh=$(echo $_scr | cut -d' ' -f1); _ssec=$(echo $_scr | cut -d' ' -f2)
        _sw=$(awk -v w="${_swh:-0}" -v t="${_ssec:-0}" 'BEGIN{ if(t>0) printf "%.2f", w/(t/3600); else print 0 }')
        _se=$(awk -v f="$_fullwh" -v a="$_sw" 'BEGIN{ if(a>0) printf "%.1f", f/a; else print 0 }')
        echo "day_scr_w=$_sw"
        echo "day_endur_scr_h=$_se"
      fi
    fi
    echo "mi_screen_sec=$(cat /data/local/tmp/mkc_mi_screen.txt 2>/dev/null)"
    echo "trial_lock=${TRIAL_LOCK:-0}"
    echo "notice=$(cat /data/local/tmp/mkc_notice_text 2>/dev/null)"
    echo "app_wl=${APP_WL:-0}"
    echo "trial_fix=$(head -1 /data/local/tmp/mkc_trial_fix.log 2>/dev/null)"
    echo "wd_pid=$(cat /data/local/tmp/mkc_wd.pid 2>/dev/null)"
    echo "wd_last=$(tail -1 /data/local/tmp/temp_chg_watchdog.log 2>/dev/null | cut -d' ' -f1-2)"
    echo "app_samples=$(wc -l < /data/local/tmp/mkc_app_sample.csv 2>/dev/null || echo 0)"
    echo "mod_samples=$(wc -l < /data/local/tmp/mkc_rec_$(date +%Y-%m-%d).csv 2>/dev/null || echo 0)"
    echo "pow_src=${POW_SRC:-none}"
    echo "soc_src=${SOC_SRC:-none}"
    echo "scr_src=$(scr_vote "$(cut -d' ' -f2 /data/local/tmp/mkc_scr_state 2>/dev/null)" "" "" | cut -d' ' -f2)"
    echo "chan_cur=${CHAN_CUR:-none}"
    echo "chan_usb=${CHAN_USB:-none}"
    echo "cell_factor=$(cell_factor)"
    echo "sample_acc=${SAMPLE_ACC:--1}"
    echo "rec_total_sec=${REC_TOT:--1}"
    echo "rec_screen_sec=${REC_SCR:--1}"
    echo "rec_dis_wh=${REC_DIS:--1}"
    echo "rec_chg_wh=${REC_CHG:--1}"
    echo "sample_gap=${SAMPLE_GAP_MAX:--1}"
    echo "power_log_sec=$POWER_LOG_SEC"
    echo "guard_en=$_en"
    echo "guard_hi=$_hi"
    echo "guard_lo=$_lo"
    echo "boot_ts=$_BOOT_TS"
    echo "pause_left=$(( pause_until > now ? pause_until - now : 0 ))"
    echo "heat_cool=$cool_left"
    echo "passthru=$passthru"
    [ -n "$1" ] && echo "note=$1"
  } > "$STATUS.tmp" 2>/dev/null
  mv -f "$STATUS.tmp" "$STATUS" 2>/dev/null
  chmod 666 "$STATUS" 2>/dev/null
}

# ---------- 温度伪装：热区收集 ----------
ZONES=""; PAZONES=""; BZONES=""; SKIPPED=""
for z in $TZ/thermal_zone*; do
  if [ ! -w "$z/emul_temp" ]; then
    [ -w "$z/mode" ] && { echo enabled > "$z/mode" 2>/dev/null; sleep 0.05; }
  fi
  if [ ! -w "$z/emul_temp" ]; then SKIPPED="$SKIPPED $(cat $z/type 2>/dev/null)"; continue; fi
  p=$(cat "$z/policy" 2>/dev/null)
  bz=$(cat "$z/type" 2>/dev/null)
  case "$bz" in battery|batt_temp|charger_therm|subpmic_therm|wireless*) BZONES="$BZONES $z"; continue;; esac
  if [ "$p" = "power_allocator" ]; then PAZONES="$PAZONES $z"; else ZONES="$ZONES $z"; fi
done

heat_pct(){
  _s=0; _n=0
  for _p in /sys/devices/system/cpu/cpufreq/policy*; do
    _c=$(cat $_p/scaling_cur_freq 2>/dev/null); _h=$(cat $_p/cpuinfo_max_freq 2>/dev/null)
    case "$_c" in ''|*[!0-9]*) _c=0;; esac; case "$_h" in ''|*[!0-9]*) _h=0;; esac
    [ "$_h" -gt 0 ] && { _s=$(( _s + _c * 100 / _h * W_CPU )); _n=$(( _n + W_CPU )); }
  done
  _c=$(cat /sys/class/devfreq/gpufreq_core/cur_freq 2>/dev/null); _h=$(cat /sys/class/devfreq/gpufreq_core/max_freq 2>/dev/null)
  case "$_c" in ''|*[!0-9]*) _c=0;; esac; case "$_h" in ''|*[!0-9]*) _h=0;; esac
  [ "$_h" -gt 0 ] && { _s=$(( _s + _c * 100 / _h * W_GPU )); _n=$(( _n + W_GPU )); }
  _st=$(cat $B/status 2>/dev/null)
  case "$_st" in Charging|Full) _s=$(( _s + W_CHG * 100 )); _n=$(( _n + W_CHG ));; esac
  [ "$_n" -gt 0 ] || { echo 50; return; }
  echo $(( _s / _n ))
}

scan_gear(){
  # 逐档试写并读回，找出本机真正接受的档位范围；测完把原值还原，并把结果写进 SETF
  if [ -z "$CHAN_LV" ]; then
    { echo "min="; echo "max="; echo "error=本机没有 wired_ctrl_limit 档位通道(非小米/澎湃)"; } > /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null
    chmod 666 /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null; mlog "档位识别：无档位通道"; return
  fi
  case "$(cat $B/status 2>/dev/null)" in
    Charging|Full)
      { echo "min="; echo "max="; echo "error=正在充电：驱动会不停改写这个值，读回不准。拔掉充电器再点一次"; } > /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null
      chmod 666 /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null; mlog "档位识别跳过：充电中"; return ;;
  esac
  _orig=$(num "$(cat "$CHAN_LV" 2>/dev/null)")
  _min=""; _max=""; _ok=""
  for g in 1 2 3 4 5 6 7 8 9 10 11 12 15 20 30; do
    echo "$g" > "$CHAN_LV" 2>/dev/null
    sleep 0.15
    rb=$(cat "$CHAN_LV" 2>/dev/null)
    if [ "$rb" = "$g" ]; then [ -z "$_min" ] && _min=$g; _max=$g; _ok="$_ok $g"; fi
  done
  echo "$_orig" > "$CHAN_LV" 2>/dev/null
  if [ -n "$_min" ]; then
    grep -v '^GEAR_MIN=' "$SETF" 2>/dev/null | grep -v '^GEAR_MAX=' > "$SETF.t" 2>/dev/null
    { cat "$SETF.t" 2>/dev/null; echo "GEAR_MIN=$_min"; echo "GEAR_MAX=$_max"; } > "$SETF" 2>/dev/null
    chmod 666 "$SETF" 2>/dev/null
    GEAR_MIN=$_min; GEAR_MAX=$_max
  fi
  { echo "min=$_min"; echo "max=$_max"; echo "accepted=$_ok"; echo "original=$_orig"; echo "time=$(date '+%m-%d %H:%M:%S')"; } > /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null
  chmod 666 /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null
  mlog "档位自动识别：接受[${_ok:- 无}] → GEAR_MIN=${_min:-?} GEAR_MAX=${_max:-?}（原值 $_orig 已还原）"
}

lic_check(){   # 授权文件：存在 + key 长度像样 + 未过期（tmp 优先，读不到就看 App 私有目录）
  _lf="$LICF"
  [ -s "$_lf" ] || _lf=/sdcard/Android/data/com.dsh.qschg/files/license.txt
  [ -s "$_lf" ] || _lf=/data/user/0/com.dsh.qschg/files/license.txt
  [ -s "$_lf" ] || return 1
  _e=$(grep -m1 '^exp=' "$_lf" 2>/dev/null | cut -d= -f2)
  _k=$(grep -m1 '^key=' "$_lf" 2>/dev/null | cut -d= -f2)
  case "$_e" in ''|*[!0-9]*) return 1 ;; esac
  case "$_k" in ''|*[!0-9A-Za-z-]*) return 1 ;; esac
  [ "${#_k}" -ge 30 ] || return 1
  [ "$_e" -gt "$(date +%s)" ] || return 1
  return 0
}

# 进程启动时刻（/proc/<pid>/stat 第 22 字段），用来只杀"比自己老"的守护 →
# 避免"杀旧起新"竞态：新守护刚起来，旧守护退出前又把它当旧进程杀了（曾导致守护静默死掉）
proc_start(){
  _s=$(cat "/proc/$1/stat" 2>/dev/null)
  _s=${_s#*) }
  set -- $_s
  echo "${20:-0}"
}
# ===== 高耗电/高占用检测（两次采样求差，看"当前"而不是开机累计）=====
hog_scan(){
  _o=/data/local/tmp/temp_chg_hogs.txt
  ps -A -o UID,TIME 2>/dev/null | awk 'NR>1{u=$1;t=$2;n=split(t,p,":");
    if(n==3)s=p[1]*3600+p[2]*60+p[3];else if(n==2)s=p[1]*60+p[2];else s=t+0; a[u]=s}
    END{for(k in a) printf "%s %.2f\n",k,a[k]}' | sort -k1,1 > /data/local/tmp/.hog1 2>/dev/null
  sleep 6
  ps -A -o UID,TIME 2>/dev/null | awk 'NR>1{u=$1;t=$2;n=split(t,p,":");
    if(n==3)s=p[1]*3600+p[2]*60+p[3];else if(n==2)s=p[1]*60+p[2];else s=t+0; a[u]=s}
    END{for(k in a) printf "%s %.2f\n",k,a[k]}' | sort -k1,1 > /data/local/tmp/.hog2 2>/dev/null
  {
    echo "# 6 秒内 CPU 占用排行（>0.6s 即算高占用，共 6 秒）  $(date '+%m-%d %H:%M')"
    join /data/local/tmp/.hog1 /data/local/tmp/.hog2 2>/dev/null | awk '{d=$3-$2; if(d>0.6) printf "%s %.1f\n",$1,d}' | sort -k2 -nr | head -10 |
    while read -r _uid _d; do
      _pkg=$(awk -v u="$_uid" '$2==u {print $1; exit}' /data/system/packages.list 2>/dev/null)
      [ -n "$_pkg" ] || continue                       # 无包名的系统 uid 直接跳过
      _pct=$(awk -v d="$_d" 'BEGIN{printf "%.0f", d/6*100/8}')   # 8 核归一化
      echo "$_pkg $_d $_pct"
    done
  } > "$_o" 2>/dev/null
  rm -f /data/local/tmp/.hog1 /data/local/tmp/.hog2 2>/dev/null
  chmod 666 "$_o" 2>/dev/null
  _n=$(grep -vc '^#' "$_o" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
  mlog "高占用检测完成：$_n 个应用超标"
}

# 后台自动检测：每 AUTO_HOG_EVERY 轮查一次，有超标就通知（带冷却，避免刷屏）
hog_auto(){
  [ "${AUTO_HOG:-1}" = "1" ] || return 0
  _now=$(date +%s)
  [ $(( _now - ${HOG_LAST:-0} )) -lt 1800 ] && return 0        # 半小时最多提醒一次
  hog_scan
  _top=$(grep -v '^#' /data/local/tmp/temp_chg_hogs.txt 2>/dev/null | head -1)
  if [ -n "$_top" ]; then
    set -- $_top; _p=$1; _pct=$3
    HOG_LAST=$_now
    mlog "自动检测：${_p} 占用 ${_pct}% → 通知用户"
    cmd notification post -S bigtext -t "米快充 · 耗电提醒" rmv_hog \
        "$(date '+%H:%M') 检测到 ${_p} CPU 占用约 ${_pct}%（可能发热耗电），可在米快充→诊断里一键清理" >/dev/null 2>&1
  fi
}

# 杀掉检测到的占用高的应用（用户点按钮才执行）
hog_kill(){
  _o=/data/local/tmp/temp_chg_hogs.txt
  _k=0
  [ -s "$_o" ] || return 0
  grep -v '^#' "$_o" | head -8 | while read -r _pkg _d _pct; do
    [ -n "$_pkg" ] || continue
    case "$_pkg" in com.dsh.qschg|com.dsharnessmobile.shell|com.android.systemui|android) continue ;; esac
    am force-stop "$_pkg" >/dev/null 2>&1 && mlog "已清理高占用应用：$_pkg（${_pct}%）"
  done
  _k=1
  echo "# 已清理 $(date '+%m-%d %H:%M')" >> "$_o" 2>/dev/null
  cmd notification post -S bigtext -t "米快充 · 清理完成" rmv_hog2 "已停止检测到的高占用应用" >/dev/null 2>&1
}

# ===== 应用耗电排行：按"开机以来 CPU 时间"统计（root 可读全量 /proc，不挑 ROM）=====
appuse_snap_legacy(){
  _o=/data/local/tmp/temp_chg_appuse.txt
  {
    echo "# 开机以来 CPU 时间排行（秒）  $(date '+%m-%d %H:%M')"
    ps -A -o UID,TIME 2>/dev/null | awk '
      NR>1 {
        u=$1; t=$2; n=split(t,p,":");
        if (n==3) s=p[1]*3600+p[2]*60+p[3]; else if (n==2) s=p[1]*60+p[2]; else s=t+0;
        a[u]+=s;
      }
      END { for (k in a) printf "%s %d\n", k, a[k] }' \
    | sort -k2 -nr | head -25 | while read -r _uid _sec; do
        _pkg=$(awk -v u="$_uid" '$2==u {print $1; exit}' /data/system/packages.list 2>/dev/null)
        [ -n "$_pkg" ] || _pkg="uid$_uid"
        echo "$_pkg $_sec"
      done
  } > "$_o" 2>/dev/null
  chmod 666 "$_o" 2>/dev/null
  mlog "应用耗电排行已更新（$(wc -l < "$_o" 2>/dev/null) 行）"
}
# ===== 日常瓦数记录：按天汇总充/放 Wh、峰值、时长 =====
daily_add(){   # $1=功率W(电池侧, 充电为正/放电为负)  $2=间隔秒
  _f=/data/local/tmp/temp_chg_daily.csv
  _d=$(date +%Y-%m-%d)
  [ -f "$_f" ] || echo "date,chg_wh,dis_wh,max_w,avg_w,chg_min,dis_min,scr_min,last_ts" > "$_f"
  _last=$(grep -m1 "^$_d," "$_f" 2>/dev/null)
  if [ -n "$_last" ]; then
    _c=$(echo "$_last" | cut -d, -f2); _x=$(echo "$_last" | cut -d, -f3)
    _m=$(echo "$_last" | cut -d, -f4); _a=$(echo "$_last" | cut -d, -f5)
    _cm=$(echo "$_last" | cut -d, -f6); _dm=$(echo "$_last" | cut -d, -f7); _sm=$(echo "$_last" | cut -d, -f8)
  else _c=0; _x=0; _m=0; _a=0; _cm=0; _dm=0; _sm=0; fi
  case "$_sm" in ''|*[!0-9.]*) _sm=0 ;; esac
  _w=$1
  _wh=$(awk -v w="$_w" -v s="${2:-5}" 'BEGIN{printf "%.4f", (w<0?-w:w)*s/3600}')
  if awk -v w="$_w" 'BEGIN{exit !(w>0.3)}'; then
    _c=$(awk -v a="$_c" -v b="$_wh" 'BEGIN{printf "%.3f", a+b}')
    _cm=$(awk -v a="$_cm" -v s="${2:-5}" 'BEGIN{printf "%.2f", a+s/60}')
  elif awk -v w="$_w" 'BEGIN{exit !(w<-0.3)}'; then
    _x=$(awk -v a="$_x" -v b="$_wh" 'BEGIN{printf "%.3f", a+b}')
    _dm=$(awk -v a="$_dm" -v s="${2:-5}" 'BEGIN{printf "%.2f", a+s/60}')
  fi
  _aw=$(awk -v w="$_w" 'BEGIN{printf "%.2f", (w<0?-w:w)}')
  _m=$(awk -v a="$_m" -v b="$_aw" 'BEGIN{print (b>a)?b:a}')
  _a=$(awk -v a="$_a" -v b="$_aw" 'BEGIN{printf "%.2f", (a<=0)?b:(a*0.9+b*0.1)}')
  grep -v "^$_d," "$_f" 2>/dev/null > "$_f.t"; mv -f "$_f.t" "$_f" 2>/dev/null
  # ★ 屏幕使用时间：背光亮度>0 就算亮屏，按采样间隔累加
  _br=$(cat /sys/class/backlight/panel0-backlight/actual_brightness 2>/dev/null)
  case "$_br" in ''|*[!0-9]*) _br=$(cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null) ;; esac
  case "$_br" in ''|*[!0-9]*) _br=0 ;; esac
  [ "$_br" -gt 0 ] 2>/dev/null && _sm=$(awk -v a="$_sm" -v s="${2:-5}" 'BEGIN{printf "%.2f", a+s/60}')
  echo "$_d,$_c,$_x,$_m,$_a,$_cm,$_dm,$_sm,$(date +%s)" >> "$_f"
  # 只保留最近 60 天
  _n=$(wc -l < "$_f" 2>/dev/null); [ "${_n:-0}" -gt 61 ] && { head -1 "$_f" > "$_f.t"; tail -60 "$_f" >> "$_f.t"; mv -f "$_f.t" "$_f"; }
  chmod 666 "$_f" 2>/dev/null
}

# 功率闭环自检：实测"放开档 ↔ 收紧档"的功率差，判断本机档位到底能不能控功率
#   → 无效就自动关掉闭环（否则会一路收到最大档还控不住，用户看到的就是"没控制住"）
# 伪装写入（后台执行：某些热区写 mode/emul_temp 会阻塞，放主循环里会把守护整个卡死）
# ★ 8.7.0：试用到期硬锁（模块侧执行，App 多老都拦得住）
# 依据：试用起点(trial) + 2 天；已激活（dsh.key 存在）不锁
trial_locked(){
  [ -s /data/data/com.dsh.qschg/files/dsh.key ] && { echo 0; return; }
  _s=$(cat /data/local/tmp/temp_chg_trial 2>/dev/null)
  case "$_s" in ''|*[!0-9]*) echo 0; return ;; esac
  _n=$(date +%s)
  echo "$(date '+%H:%M:%S') s=$_s n=$_n diff=$(( _n - _s ))" >> /data/local/tmp/mkc_trial_lock.log
  chmod 666 /data/local/tmp/mkc_trial_lock.log 2>/dev/null
  [ $(( _n - _s )) -ge 172800 ] && echo 1 || echo 0
}
TRIAL_LOCK=$(trial_locked)

# ★ 8.7.4：老版本 App（<=2.8.69）收不到发布正文，用系统通知把"必更"消息直接推给他
notify_update(){
  _v=$(dumpsys package com.dsh.qschg 2>/dev/null | grep -m1 versionName | cut -d= -f2 | tr -d ' ')
  [ -z "$_v" ] && return 0
  case "$_v" in 2.8.7[0-9]|2.9.*|3.*) return 0 ;; esac     # 已是最新就不打扰
  _nf=/data/local/tmp/mkc_notice_ts
  _last=$(cat "$_nf" 2>/dev/null); case "$_last" in ''|*[!0-9]*) _last=0 ;; esac
  _now=$(date +%s)
  [ $(( _now - _last )) -lt 43200 ] && return 0            # 12 小时最多提醒一次
  echo "$_now" > "$_nf" 2>/dev/null; chmod 666 "$_nf" 2>/dev/null
  echo "⚠️必更 v8.8.1：修充电功率忽高忽低、修 CPU 空转发烫掉电。App 2.8.70＋模块一起更新，老用户不用重新激活" > /data/local/tmp/mkc_notice_text 2>/dev/null
  chmod 666 /data/local/tmp/mkc_notice_text 2>/dev/null
  cmd notification post -S bigtext -t "米快充 必更提醒" mkc_update \
    "⚠️重大BUG修复：CPU空转导致发烫、掉电快。请更新模块 v8.8.1＋App 2.8.70（两个都要更，老用户不用重新激活）" >/dev/null 2>&1
  mlog "已推送必更提醒（当前 App $_v）"
}
notify_update

mask_once(){
  [ "${TRIAL_LOCK:-0}" = "1" ] && return 0   # 温度伪装写入（后台执行，主循环不再被 60+ 节点拖慢）
  h=$(heat_pct)
  tgt=$(( S_MIN + h * (S_MAX - S_MIN) / 100 ))
  [ -n "$SMOOTH" ] && tgt=$(( (tgt + SMOOTH) / 2 )); SMOOTH=$tgt
  i=0
  _tg=$tgt
  if [ "${CPU_MASK:-1}" = "1" ]; then
    _tg=$(clamp "$(( tgt - 4000 ))" "$(( S_MIN - 4000 ))" "$S_MIN")   # CPU 伪装：cpu/gpu 热区目标再低 4℃
  fi
  for z in $ZONES; do
    _ty=$(cat "$z/type" 2>/dev/null)
    _use=$tgt
    case "$_ty" in *cpu*|*gpu*|*kgsl*|*mali*|*cme*|*soc*) _use=$_tg ;; esac
    off=$(( (i % 7 - 3) * JITTER / 3 )); off=$(( off + (i % 5) * 37 ))
    echo "$(clamp "$(( _use + off ))" "$S_MIN" "$S_MAX")" > "$z/emul_temp" 2>/dev/null
    i=$((i+1))
  done
  pt=$(( PA_MIN + h * (PA_MAX - PA_MIN) / 100 ))
  for z in $PAZONES; do echo "$pt" > "$z/emul_temp" 2>/dev/null; done
  # ★ v1.3.0 核心：厂商 thermal_message 温度通道（安全中心 / joyose 读的就是这些）
  j=0
  for m in $MSGTEMPS; do
    f="$MSG/$m"; [ -w "$f" ] || { j=$((j+1)); continue; }
    if [ "$m" = "charger_temp" ]; then
      cur=$(cat "$f" 2>/dev/null)
      case "$cur" in -1|"") j=$((j+1)); continue;; esac   # -1=未充电，保持原语义
    fi
    off=$(( (j % 5 - 2) * 90 ))
    echo "$(clamp "$(( tgt + off ))" "$S_MIN" "$S_MAX")" > "$f" 2>/dev/null
    j=$((j+1))
  done
  # ★ v1.3.1：power_supply 的 temp（0.1C）
  psv=$(clamp "${rb:-${b:-370}}" "$B_MIN" "$B_MAX")
  for f in $PSTEMPS; do [ -w "$f" ] && echo "$psv" > "$f" 2>/dev/null; done
  # ★ v1.3.1：厂商其余温度通道（自动识别 0.1C / 0.001C 量纲）
  for f in $EXTRA; do
    [ -w "$f" ] || continue
    cur=$(cat "$f" 2>/dev/null); case "$cur" in ''|*[!0-9]*) continue;; esac
    smart_write "$f" "$(( $(clamp "$tgt" "$S_MIN" "$S_MAX") / 10 ))"
    smart_write "$f" "${psv:-372}"
  done
  # ★ v1.5.0 电池温度三模式（默认 steady —— 为“稳充”服务）
  #   steady：一直压着 BATT_FAKE（37.0C）不松手 → 上层与厂商充电策略看到的温度**恒定**，
  #           不会再周期性看到 47~49C 真值而反复 stop charge（旧版 clamp 每 2s 松开 0.4s 就是这个毛病的源头）。
  #           安全兜底：每 SAFE_CHECK_SEC 秒松开 CLAMP_RELEASE 秒读一次真值；真值 >= SAFE_MAX(47C) 时
  #           进入 SAFE_PASS_SEC 秒“放行模式”（伪装值=真实值），把温控交回厂商。
  #   clamp：旧行为（min(真实, BATT_CLAMP)），保留官方充电温控但会周期性暴露真值。
  #   fake ：固定区间伪裝（B_MIN~B_MAX）。
  if [ -w "$FAKE" ]; then
    case "$BATT_MODE" in
      clamp)
        echo -999 > "$FAKE" 2>/dev/null; sleep "${CLAMP_RELEASE:-0.4}"
        rb=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); case "$rb" in ""|*[!0-9]*) rb=$B_MIN;; esac
        [ "$rb" -gt "$BATT_CLAMP" ] && rb=$BATT_CLAMP
        echo "$rb" > "$FAKE" 2>/dev/null
        for z in $BZONES; do echo "$(( rb * 100 ))" > "$z/emul_temp" 2>/dev/null; done
        ;;
      fake)
        b=$(( B_MIN + h * (B_MAX - B_MIN) / 100 ))
        [ -n "$BSMOOTH" ] && b=$(( (b + BSMOOTH) / 2 )); BSMOOTH=$b
        echo "$(clamp "$b" "$B_MIN" "$B_MAX")" > "$FAKE" 2>/dev/null
        ;;
      *)
        # v1.5.0 默认 STEADY_RELEASE=0：**永不松开**，一直压着 BATT_FAKE，
        # 厂商充电策略全程看不到真实高温 → 不会 jeita-hot / stop charge → 快充能稳住。
        BATT_N=$(( BATT_N + 1 ))
        bval=${BATT_FAKE:-370}
        [ $(( (BATT_N / 8) % 2 )) -eq 1 ] && bval=$(( bval + 2 ))   # 0.2C 缓慢游走，别像条直线
        if [ "${STEADY_RELEASE:-0}" = "1" ]; then
          if [ "$PASS_LEFT" -gt 0 ]; then
            PASS_LEFT=$(( PASS_LEFT - 1 ))
            bval=${RBHOLD:-$bval}
          else
            if [ -z "$RBHOLD" ] || [ $(( BATT_N % SAFE_EVERY )) -eq 0 ]; then
              echo -999 > "$FAKE" 2>/dev/null
              sleep "${CLAMP_RELEASE:-0.15}"
              _r=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
              case "$_r" in ''|*[!0-9]*) _r=${BATT_FAKE:-370};; esac
              RBHOLD=$_r
              if [ "$_r" -ge "${SAFE_MAX:-9999}" ] 2>/dev/null; then
                PASS_LEFT=$SAFE_PASS_EVERY
                log "电池真温 ${_r} → 放行 ${SAFE_PASS_SEC}s（仅 STEADY_RELEASE=1 时）"
              fi
            fi
          fi
        fi
        echo "$bval" > "$FAKE" 2>/dev/null
        for z in $BZONES; do echo "$(( bval * 100 ))" > "$z/emul_temp" 2>/dev/null; done
        ;;
    esac
  fi
}

mask_apply(){
      # ★ 4.9.6：删除写 mode=disabled 的逻辑（铁律：绝不写 mode/trip）。
      #   实测写了会让小米 mi_thermal_interface 把 cpufreq 钉成 min==max，表现为 CPU 锁最低频。
      _mt=/data/local/tmp/temp_chg_mask_tgt
      _mprev=$(cat "$_mt" 2>/dev/null); case "$_mprev" in ''|*[!0-9-]*) _mprev=-99999 ;; esac
      _mts=$(cat "$_mt.ts" 2>/dev/null); case "$_mts" in ''|*[!0-9]*) _mts=0 ;; esac
      _mnow=$(date +%s 2>/dev/null); case "$_mnow" in ''|*[!0-9]*) _mnow=0 ;; esac
      h=$(heat_pct)
      tgt=$(( S_MIN + h * (S_MAX - S_MIN) / 100 ))
      if [ "$_mprev" != "-99999" ] && [ "$_mnow" -gt 0 ] && [ $(( _mnow - _mts )) -lt 60 ]; then
        _d=$(( tgt - _mprev )); [ "$_d" -lt 0 ] && _d=$(( -_d ))
        if [ "$_d" -lt 300 ]; then
          rm -f /data/local/tmp/temp_chg_maskbusy 2>/dev/null
          return 0
        fi
      fi
      [ -n "$SMOOTH" ] && tgt=$(( (tgt + SMOOTH) / 2 )); SMOOTH=$tgt
      i=0
      for z in $ZONES; do
        off=$(( (i % 7 - 3) * JITTER / 3 )); off=$(( off + (i % 5) * 37 ))
        echo "$(clamp "$(( tgt + off ))" "$S_MIN" "$S_MAX")" > "$z/emul_temp" 2>/dev/null
        i=$((i+1))
      done
      pt=$(( PA_MIN + h * (PA_MAX - PA_MIN) / 100 ))
      for z in $PAZONES; do echo "$pt" > "$z/emul_temp" 2>/dev/null; done
      j=0
      for m in $MSGTEMPS; do
        f="$MSG/$m"; [ -w "$f" ] || { j=$((j+1)); continue; }
        if [ "$m" = "charger_temp" ]; then
          cur=$(cat "$f" 2>/dev/null)
          case "$cur" in -1|"") j=$((j+1)); continue;; esac
        fi
        off=$(( (j % 5 - 2) * 90 ))
        echo "$(clamp "$(( tgt + off ))" "$S_MIN" "$S_MAX")" > "$f" 2>/dev/null
        j=$((j+1))
      done
      psv=$(clamp "${rb:-${b:-370}}" "$B_MIN" "$B_MAX")
      for f in $PSTEMPS; do [ -w "$f" ] && echo "$psv" > "$f" 2>/dev/null; done
      for f in $EXTRA; do
        [ -w "$f" ] || continue
        cur=$(cat "$f" 2>/dev/null); case "$cur" in ''|*[!0-9]*) continue;; esac
        if [ "$cur" -gt 2000 ]; then echo "$(clamp "$tgt" "$S_MIN" "$S_MAX")" > "$f" 2>/dev/null
        else echo "$psv" > "$f" 2>/dev/null; fi
      done
      if [ -w "$FAKE" ]; then
        case "$BATT_MODE" in
          clamp)
            echo -999 > "$FAKE" 2>/dev/null; sleep "${CLAMP_RELEASE:-0.4}"
            rb=$(cat "$B/temp" 2>/dev/null); case "$rb" in ""|*[!0-9]*) rb=$B_MIN;; esac
            [ "$rb" -gt "$BATT_CLAMP" ] && rb=$BATT_CLAMP
            echo "$rb" > "$FAKE" 2>/dev/null
            for z in $BZONES; do echo "$(( rb * 100 ))" > "$z/emul_temp" 2>/dev/null; done
            ;;
          fake)
            b=$(( B_MIN + h * (B_MAX - B_MIN) / 100 ))
            [ -n "$BSMOOTH" ] && b=$(( (b + BSMOOTH) / 2 )); BSMOOTH=$b
            echo "$(clamp "$b" "$B_MIN" "$B_MAX")" > "$FAKE" 2>/dev/null
            ;;
          *)
            BATT_N=$(( BATT_N + 1 ))
            bval=${BATT_FAKE:-370}
            [ $(( (BATT_N / 8) % 2 )) -eq 1 ] && bval=$(( bval + 2 ))
            if [ "${STEADY_RELEASE:-0}" = "1" ]; then
              if [ "$PASS_LEFT" -gt 0 ]; then PASS_LEFT=$(( PASS_LEFT - 1 )); bval=${RBHOLD:-$bval}
              else
                if [ -z "$RBHOLD" ] || [ $(( BATT_N % SAFE_EVERY )) -eq 0 ]; then
                  echo -999 > "$FAKE" 2>/dev/null; sleep "${CLAMP_RELEASE:-0.15}"
                  _r=$(cat "$B/temp" 2>/dev/null); case "$_r" in ''|*[!0-9]*) _r=${BATT_FAKE:-370};; esac
                  RBHOLD=$_r
                  [ "$_r" -ge "${SAFE_MAX:-9999}" ] 2>/dev/null && { PASS_LEFT=$SAFE_PASS_EVERY; mlog "电池真温 ${_r} → 放行 ${SAFE_PASS_SEC}s"; }
                fi
              fi
            fi
            echo "$bval" > "$FAKE" 2>/dev/null
            for z in $BZONES; do echo "$(( bval * 100 ))" > "$z/emul_temp" 2>/dev/null; done
            ;;
        esac
      fi
  echo "$tgt" > /data/local/tmp/temp_chg_mask_tgt 2>/dev/null
  date +%s > /data/local/tmp/temp_chg_mask_tgt.ts 2>/dev/null
  chmod 666 /data/local/tmp/temp_chg_mask_tgt* 2>/dev/null
  rm -f /data/local/tmp/temp_chg_maskbusy 2>/dev/null
}

knob_probe(){
  _gmin=$GEAR_MIN; _gmax=$GEAR_MAX
  case "$_gmin" in ''|*[!0-9]*) _gmin=1 ;; esac
  case "$_gmax" in ''|*[!0-9]*) _gmax=30 ;; esac
  [ "$_gmax" -le "$_gmin" ] && _gmax=$((_gmin+10))
  log "闭环自检：验证本机档位能否控功率（放开档 $_gmin ↔ 收紧档 $_gmax，各 12 秒）"
  mlog "功率闭环自检开始（档位有效性）"
  write_lv "$_gmin"; sleep 12
  set -- $(read_power); _a=$2
  write_lv "$_gmax"; sleep 12
  set -- $(read_power); _b=$2
  write_lv "$_gmin"
  echo "eff_a=$_a eff_b=$_b gmin=$_gmin gmax=$_gmax ts=$(date +%s)" > /data/local/tmp/temp_chg_knob.txt
  chmod 666 /data/local/tmp/temp_chg_knob.txt 2>/dev/null
  if awk -v a="$_a" -v b="$_b" 'BEGIN{ exit !(a>=8 && a>0 && (a-b) < a*0.10) }'; then
    log "档位无效：放开 ${_a}W / 收紧 ${_b}W（差不到 10%）→ 本机档位控不了功率"
    mlog "功率闭环自检结论：本机档位对功率无效（${_a}W→${_b}W）"
    echo "本机「档位」对功率无效（放开档 ${_a}W、收紧档 ${_b}W，差不到 10%）→ 目标功率控制在本机不可用，已自动关闭功率闭环并保持最放开档；亮屏快充与温度伪装不受影响。" > /data/local/tmp/temp_chg_loop.txt
    chmod 666 /data/local/tmp/temp_chg_loop.txt 2>/dev/null
    POWER_LOOP=0
    grep -v '^POWER_LOOP=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
    echo "POWER_LOOP=0" >> "$SETF"; chmod 666 "$SETF" 2>/dev/null
  else
    log "档位有效：放开 ${_a}W / 收紧 ${_b}W → 保留功率闭环"
    mlog "功率闭环自检结论：档位有效（${_a}W→${_b}W）"
    rm -f /data/local/tmp/temp_chg_loop.txt 2>/dev/null
  fi
  gear=$_gmin
}

# ===== 应用耗电排行（v4.9.4：/proc jiffies 10ms 精度，拔电后增量累计）=====
uidcpu_ticks(){
  # ★ 5.9.0：优先用 /proc/uid_cputime/show_uid_stat（内核统计，含所有线程，游戏不会漏）
  if [ -r /proc/uid_cputime/show_uid_stat ]; then
    awk '{ u=$1; sub(":","",u); print u, int(($2+$3)/10000) }' /proc/uid_cputime/show_uid_stat 2>/dev/null
    return
  fi
  # 兜底：扫 /proc（只含主线程，精度差）
  _l=/data/local/tmp/temp_chg_proclist.txt
  _k=/data/local/tmp/temp_chg_procstat.txt
  _m=/data/local/tmp/temp_chg_uidm.txt
  for f in /proc/[0-9]*/stat; do [ -r "$f" ] && echo "$f"; done > "$_l"
  xargs awk '{n=split(FILENAME,a,"/"); print a[n-1], $14+$15}' < "$_l" 2>/dev/null > "$_k"
  stat -c '%u %n' $(sed 's#/stat$##' "$_l") > "$_m" 2>/dev/null
  awk 'NR==FNR{u[$2]=$1;next}{if(("/proc/"$1) in u) acc[u["/proc/"$1]]+=$2}END{for(x in acc) printf "%s %d\n", x, acc[x]}' "$_m" "$_k" 2>/dev/null
  rm -f "$_l" "$_k" "$_m" 2>/dev/null
}

appuse_snap(){
  # 设备采集只做"取数"，归因/累加/渲染全在 sampling.sh 的 uid_rank_emit（有单测）
  # ★ 统计口径变了（改内核 uid_cputime）→ 旧基线作废，避免一帧算出 5 万秒
  _fmt=/data/local/tmp/temp_chg_uidcpu_fmt
  if [ "$(cat "$_fmt" 2>/dev/null)" != "2" ]; then
    rm -f /data/local/tmp/temp_chg_uidcpu_prev /data/local/tmp/temp_chg_uidcpu_acc 2>/dev/null
    echo 2 > "$_fmt" 2>/dev/null; chmod 666 "$_fmt" 2>/dev/null
  fi
  _acc=/data/local/tmp/temp_chg_uidcpu_acc
  _prev=/data/local/tmp/temp_chg_uidcpu_prev
  _cur=/data/local/tmp/temp_chg_uidcpu_cur
  uidcpu_ticks > "$_cur" 2>/dev/null
  # 7.2.0：会话排行用会话自己的起止电量（避免跟全局容量混在一起）
  if [ -s /data/local/tmp/mkc_sess_state ]; then
    read -r _x1 _cap0 _capn _x2 _x3 _x4 _x5 < /data/local/tmp/mkc_sess_state 2>/dev/null
  fi
  case "$_cap0" in ''|*[!0-9]*) _cap0=$(real_soc) ;; esac
  case "$_capn" in ''|*[!0-9]*) _capn=$(real_soc) ;; esac
  # 当天累计（跨天自动换文件）
  _dayf=/data/local/tmp/mkc_day_date
  _dtoday=$(date +%Y-%m-%d 2>/dev/null)
  _dold=$(cat "$_dayf" 2>/dev/null)
  if [ "$_dold" != "$_dtoday" ]; then
    rm -f /data/local/tmp/mkc_day_acc /data/local/tmp/mkc_day_cap0 2>/dev/null
    echo "$_dtoday" > "$_dayf" 2>/dev/null; chmod 666 "$_dayf" 2>/dev/null
    echo "$_capn" > /data/local/tmp/mkc_day_cap0 2>/dev/null
  fi
  _dacc=/data/local/tmp/mkc_day_acc
  [ -f /data/local/tmp/mkc_day_cap0 ] || echo "$_capn" > /data/local/tmp/mkc_day_cap0 2>/dev/null
  _dcap0=$(cat /data/local/tmp/mkc_day_cap0 2>/dev/null)
  case "$_dcap0" in ''|*[!0-9]*) _dcap0=$_capn ;; esac
  # 会话排行（秒）与当天累计（Wh 由后面的 app_energy_emit 统一渲染，避免两个格式互相覆盖）
  uid_rank_emit "$_prev" "$_cur" "$_acc" "$_cap0" "$_capn" \
    /data/local/tmp/temp_chg_appuse.txt /data/system/packages.list \
    "$_dacc"
  chmod 666 "$_dacc" "/data/local/tmp/mkc_rec_appuse_${_dtoday}.txt" 2>/dev/null
  rm -f "$_cur" 2>/dev/null
  chmod 666 /data/local/tmp/temp_chg_appuse.txt "$_acc" "$_prev" 2>/dev/null
  mlog "应用耗电排行已更新（拔电后累计，10ms 精度）"
}

kill_old(){
  _mine=$(proc_start $$)
  if command -v pgrep >/dev/null 2>&1; then
    _pids=$(pgrep -f "$MODDIR/service.sh" 2>/dev/null)
  else
    _pids=""
    for d in /proc/[0-9]*; do _pids="$_pids ${d#/proc/}"; done
  fi
  for _p in $_pids; do
    [ "$_p" = "$$" ] && continue
    [ -d "/proc/$_p" ] || continue
    _ok=0
    tr '\0' '\n' < "/proc/$_p/cmdline" 2>/dev/null | grep -qx "$MODDIR/service.sh" && _ok=1
    [ "$_ok" = "1" ] || continue
    _ps=$(proc_start "$_p"); case "$_ps" in ''|*[!0-9]*) _ps=0 ;; esac
    [ "$_ps" -lt "${_mine:-0}" ] && { kill "$_p" 2>/dev/null && log "已停止旧守护 pid=$_p"; }
  done
}
kill_old
# 看门狗：守护被杀/异常退出后 60 秒内自动拉起（避免模块"静默失效"）
start_watchdog(){
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "$MODDIR/watchdog.sh" >/dev/null 2>&1 && return 0
  else
    for d in /proc/[0-9]*; do
      [ -r "$d/cmdline" ] || continue
      tr '\0' '\n' < "$d/cmdline" 2>/dev/null | grep -qx "$MODDIR/watchdog.sh" && return 0
    done
  fi
  if command -v setsid >/dev/null 2>&1; then setsid sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 &
  else nohup sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 & fi
}

start_watchdog

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5
nz=$(echo $ZONES|wc -w); np=$(echo $PAZONES|wc -w); nb=$(echo $BZONES|wc -w); ns=$(echo $SKIPPED|wc -w)
SAFE_EVERY=$(( ${SAFE_CHECK_SEC:-60} / POLL )); [ "$SAFE_EVERY" -lt 1 ] && SAFE_EVERY=1
SAFE_PASS_EVERY=$(( ${SAFE_PASS_SEC:-180} / POLL )); [ "$SAFE_PASS_EVERY" -lt 1 ] && SAFE_PASS_EVERY=1
_ver=$(grep "^version=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -f "$MODDIR/probe.sh" ] && { sh "$MODDIR/probe.sh" >/dev/null 2>&1 & }
_BOOT_TS=$(date +%s)
mlog "start ${_ver:-v3.0.2} $(getprop ro.product.brand) $(getprop ro.product.model) $(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name)/Android$(getprop ro.build.version.release) 策略=$STRATEGY 热区=$nz + pa=$np + 电池=$nb (不可写 $ns)"
echo "zones=$nz pa=$np batt=$nb skipped=$ns strategy=$STRATEGY rm=$CHAN_RM lv=$CHAN_LV cur=$CHAN_CUR usb=$CHAN_USB" > "$DIAG"
log "=== ${_ver:-v3.0.2} 启动 pid=$$ 策略=$STRATEGY 官方档=$STOCK_GEAR 放开电流=${OPEN_CUR_MA}mA ==="

SMOOTH=""; BSMOOTH=""; BATT_N=0; RBHOLD=""; PASS_LEFT=0
gear=$GEAR_MIN; chgn=0; fmode=""; mstate=""; bad=0; pause_until=0
heat_acc=0; cool_left=0; round=0; now=$(date +%s)
passthru=0; real_temp=""
SS=0; SSW=0; SMX=0; SC0=0; SN=0; L_SEC=0; L_WH=0; L_S=0; L_E=0

while true; do
  now=$(date +%s)
  # —— 自检锁：App 正在自检时暂停一切写入（进程没了自动放行）——
  held=0
  if [ -f "$LCK" ]; then
    _lp=$(num "$(cat "$LCK" 2>/dev/null)")
    if [ -n "$_lp" ] && [ "$_lp" != "0" ] && [ -d "/proc/$_lp" ]; then held=1; else rm -f "$LCK" 2>/dev/null; fi
  fi
  if [ -f "$MODDIR/disable" ]; then
    ctrl_stock
    for z in $ZONES $PAZONES; do echo 0 > "$z/emul_temp" 2>/dev/null; done
    [ -w "$FAKE" ] && echo -999 > "$FAKE" 2>/dev/null
    mlog "模块被禁用：伪装已撤、充电策略已交回官方"
    rm -f "$PIDF"; exit 0
  fi
  # ★ 4.8.5：管理器里卸载/停用了模块 → 守护立刻退出，不再"卸载了还在加载"
  if [ -f "$MODDIR/remove" ] || [ -f "$MODDIR/disable" ]; then
    case "$STRATEGY" in xm_gear) write_rm 0; write_lv "$STOCK_GEAR" ;; *) set_cur_node stock ;; esac
    for z in $ZONES $PAZONES $BZONES; do echo 0 > "$z/emul_temp" 2>/dev/null; done
    [ -w "$FAKE" ] && echo -999 > "$FAKE" 2>/dev/null
    mlog "检测到 remove/disable → 守护退出，伪装已撤、充电交回官方"
    rm -f "$PIDF" 2>/dev/null
    exit 0
  fi
  if [ -z "${_CHANNELS_READY:-}" ]; then
    _CHANNELS_READY=1
    for _f in "$CMDF" "$SETF" "/data/local/tmp/temp_chg_socfake" "/data/local/tmp/temp_chg_trial" "/data/local/tmp/temp_chg_trial_ext" "/data/local/tmp/mkc_app_sample.csv"; do
      [ -f "$_f" ] || : > "$_f" 2>/dev/null
      chmod 666 "$_f" 2>/dev/null
    done
  fi
  _tnow0=$(date +%s 2>/dev/null); case "$_tnow0" in ''|*[!0-9]*) _tnow0=0 ;; esac
  if [ -n "${LAST_TICK:-}" ] && [ "$_tnow0" -gt "$LAST_TICK" ]; then DT=$(( _tnow0 - LAST_TICK )); else DT=$POLL; fi
  [ "$DT" -lt 1 ] && DT=1; [ "$DT" -gt 60 ] && DT=60
  round=$(( round + 1 ))
  # —— 免 root 控制通道：App 直接写文件即可；只认下面这些白名单命令，不做任何 eval ——
  if [ -s "$CMDF" ]; then
    while IFS= read -r _l; do
      case "$_l" in
        probe=1)   sh "$MODDIR/probe.sh" >/dev/null 2>&1 & mlog "手动触发节点普查" ;;
        check=1|selfcheck=1)
                   ( sh "$MODDIR/check.sh" >/dev/null 2>&1 ) &
                   mlog "精简自检已执行（App 内显示）" ;;
        fix=1|repair=1)
                   ( sh "$MODDIR/autofix.sh" > /data/local/tmp/temp_chg_fix.log 2>&1
                     sh "$MODDIR/action.sh" repair >> /data/local/tmp/temp_chg_fix.log 2>&1
                     chmod 666 /data/local/tmp/temp_chg_fix.log 2>/dev/null ) &
                   mlog "一键修复已执行（结果写 temp_chg_fix.log）" ;;
        export=1|exportlog=1)
                   ( sh "$MODDIR/export.sh" >/dev/null 2>&1 ) &
                   mlog "导出诊断日志到 /sdcard/（中文文件名）" ;;
        diag=1|selfcheck=1)
                   ( sh "$MODDIR/selfcheck.sh" > /data/local/tmp/temp_chg_selfcheck.log 2>&1
                     sh "$MODDIR/probe.sh" >/dev/null 2>&1
                     chmod 666 /data/local/tmp/temp_chg_selfcheck.log 2>/dev/null ) &
                   mlog "自检+普查已启动（日志 temp_chg_selfcheck.log / temp_chg_probe.log）" ;;
        scan_gear=1|scan=1) scan_gear ;;
        appuse=1|battrank=1) ( appuse_snap ) & ;;
        hogs=1|hog=1) ( hog_scan ) & ;;
        killhogs=1) ( hog_kill ) & ;;
        fast=off)  echo off > "$FASTW" 2>/dev/null; chmod 666 "$FASTW" 2>/dev/null
                   touch "$MODDIR/fast_off" 2>/dev/null
                   grep -v '^FAST=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                   echo "FAST=0" >> "$SETF" 2>/dev/null; chmod 666 "$SETF" 2>/dev/null; FAST=0
                   ctrl_stock; mlog "免root命令: fast=off（已写 FAST=0，不会被 App 旧设置顶回去）" ;;
        fast=on)   echo on > "$FASTW" 2>/dev/null; chmod 666 "$FASTW" 2>/dev/null
                   rm -f "$MODDIR/fast_off" 2>/dev/null
                   grep -v '^FAST=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                   echo "FAST=1" >> "$SETF" 2>/dev/null; chmod 666 "$SETF" 2>/dev/null; FAST=1
                   mlog "免root命令: fast=on（已写 FAST=1）" ;;
        mask=off)  echo off > "$MASKW" 2>/dev/null; chmod 666 "$MASKW" 2>/dev/null
                   touch "$MODDIR/mask_off" 2>/dev/null
                   grep -v '^MASK=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                   echo "MASK=0" >> "$SETF" 2>/dev/null; chmod 666 "$SETF" 2>/dev/null; MASK=0
                   mlog "免root命令: mask=off（已写 MASK=0）" ;;
        fix_als=1) sh "$MODDIR/alsfix.sh" >/dev/null 2>&1 & mlog "收到光感自愈请求" ;;
        cpu_mask=0|cpu_mask=1)
                   _cm=${_l#*=}
                   grep -v '^CPU_MASK=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                   echo "CPU_MASK=$_cm" >> "$SETF" 2>/dev/null; chmod 666 "$SETF" 2>/dev/null
                   CPU_MASK=$_cm
                   mlog "免root命令: CPU伪装=$_cm（cpu/gpu 热区${_cm}）" ;;
        mask=on)   echo on > "$MASKW" 2>/dev/null; chmod 666 "$MASKW" 2>/dev/null
                   rm -f "$MODDIR/mask_off" 2>/dev/null; passthru=0; mlog "免root命令: mask=on（已解除看门狗锁定）" ;;
        force=1|restore=1)
                   _ft=/data/local/tmp/mkc_force_ts
                   _fl=$(cat "$_ft" 2>/dev/null); case "$_fl" in ''|*[!0-9]*) _fl=0 ;; esac
                   [ $(( $(date +%s) - _fl )) -lt 30 ] && continue
                   echo $(date +%s) > "$_ft" 2>/dev/null; chmod 666 "$_ft" 2>/dev/null
                   rm -f "$MODDIR/mask_off" "$MODDIR/fast_off" 2>/dev/null; passthru=0
                   # ★ 同时关掉看门狗：否则真实温度还高于阈值，下一轮立刻又撤伪装（用户看到"按了没用"）
                   grep -v '^GUARD_EN=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                   echo "GUARD_EN=0" >> "$SETF"; chmod 666 "$SETF" 2>/dev/null
                   ctrl_open; mlog "强制恢复：伪装 + 快充已重新接管，看门狗已关闭" ;;
        all=on)    rm -f "$MODDIR/mask_off" "$MODDIR/fast_off" "$MODDIR/disable" 2>/dev/null; mlog "免root命令: all=on" ;;
        *) ;;
      esac
    done < "$CMDF"
    : > "$CMDF" 2>/dev/null
    chmod 666 "$CMDF" 2>/dev/null
  fi

  if [ "$held" = "1" ]; then write_status selfcheck; sleep "$POLL"; continue; fi
  # —— 运行时参数热改：App 写 SETF 里的 key=值，每轮生效（白名单 + 纯数字校验）——
  if [ -f "$SETF" ]; then
    _pl_prev=${POWER_LOOP:-0}
    for _k in POLL STEP_EVERY TARGET_W TOL_HI TOL_LO GEAR_MIN GEAR_MAX POWER_LOOP POWER_LOG_SEC FAKE_TEMP CPU_MASK AUTO_HOG HOG_EVERY; do
      _v=$(grep -m1 "^$_k=" "$SETF" 2>/dev/null | cut -d= -f2)
      case "$_v" in ''|*[!0-9]*) ;; *) eval "$_k=$_v" ;; esac
    done
    # 自定义功率：FAKE_TEMP>0 用指定假温度限功率；=0 必须还原默认假温度（否则会一直卡在限流值）
    case "${FAKE_TEMP:-0}" in
      ''|*[!0-9]*) BATT_FAKE=$BATT_FAKE_DEF ;;
      *) if [ "$FAKE_TEMP" -gt 0 ] 2>/dev/null; then BATT_FAKE=$FAKE_TEMP; else BATT_FAKE=$BATT_FAKE_DEF; fi ;;
    esac
    # 用户重新打开闭环（0→1）时，重新做一次档位有效性自检
    [ "$_pl_prev" = "0" ] && [ "${POWER_LOOP:-0}" = "1" ] && KNOB_DONE=0
  fi


  # —— 真实温度看门狗（App 可设阈值）：到阈值就"切回真实温度 + 充电交回官方" ——
  _en=0; _hi=$REAL_HI; _lo=$REAL_LO
  if [ -f "$GCFG" ]; then
    _en=$(grep -m1 "^en=" "$GCFG" 2>/dev/null | cut -d= -f2)
    _hi=$(grep -m1 "^hi=" "$GCFG" 2>/dev/null | cut -d= -f2)
    _lo=$(grep -m1 "^lo=" "$GCFG" 2>/dev/null | cut -d= -f2)
  fi
  if [ -f "$SETF" ]; then
    _g=$(grep -m1 "^GUARD_EN=" "$SETF" 2>/dev/null | cut -d= -f2); case "$_g" in 0|1) _en=$_g ;; esac
    _g=$(grep -m1 "^REAL_HI=" "$SETF" 2>/dev/null | cut -d= -f2); case "$_g" in ''|*[!0-9]*) ;; *) _hi=$_g ;; esac
    _g=$(grep -m1 "^REAL_LO=" "$SETF" 2>/dev/null | cut -d= -f2); case "$_g" in ''|*[!0-9]*) ;; *) _lo=$_g ;; esac
  fi
  case "$_en" in 0|1) ;; *) _en=0 ;; esac
  case "$_hi" in ''|*[!0-9]*) _hi=${REAL_HI:-0};; esac
  case "$_lo" in ''|*[!0-9]*) _lo=${REAL_LO:-0};; esac
  _ck=$(( ${REAL_CHK:-30} / POLL )); [ "$_ck" -lt 1 ] && _ck=1
  if [ $(( round % _ck )) -eq 0 ] || [ "$passthru" = "1" ]; then
    if [ -w "$FAKE" ]; then
      echo -999 > "$FAKE" 2>/dev/null; sleep 0.15
      real_temp=$(num "$(cat $B/temp 2>/dev/null)")
      [ "$passthru" = "1" ] || echo "${BATT_FAKE:-370}" > "$FAKE" 2>/dev/null
    else
      real_temp=$(num "$(cat $B/temp 2>/dev/null)")
    fi
  fi
  if [ "$_en" = "1" ] && [ "$_hi" -gt 0 ]; then
    if [ -n "$real_temp" ]; then
      if [ "$real_temp" -ge "$_hi" ] && [ "$passthru" != "1" ]; then
        passthru=1
        mlog "真实温度 ${real_temp} ≥ ${_hi} → 切回真实温度、充电交回官方"
        log "真实温度 ${real_temp} ≥ ${_hi} → 交回官方充电策略（降到 ${_lo} 再恢复）"
      elif [ "$passthru" = "1" ] && [ "$_lo" -gt 0 ] && [ "$real_temp" -le "$_lo" ]; then
        passthru=0
        mlog "真实温度 ${real_temp} ≤ ${_lo} → 恢复伪装与快充"
        log "真实温度 ${real_temp} ≤ ${_lo} → 恢复亮屏快充"
      fi
    fi
  else
    passthru=0
  fi


  # ================= 期望状态对齐（App 写 want 文件，守护下一轮执行）=================
  if [ -f "$MASKW" ]; then
    _mw=$(head -c 8 "$MASKW" 2>/dev/null | tr -d ' \r\n')
    case "$_mw" in
      off) [ -f "$MODDIR/mask_off" ] || { touch "$MODDIR/mask_off" 2>/dev/null; mlog "温度伪装=关（App 期望状态）"; } ;;
      on)  [ -f "$MODDIR/mask_off" ] && { rm -f "$MODDIR/mask_off" 2>/dev/null; mlog "温度伪装=开（App 期望状态）"; } ;;
    esac
  fi
  if [ -f "$FASTW" ]; then
    _fw=$(head -c 8 "$FASTW" 2>/dev/null | tr -d ' \r\n')
    case "$_fw" in
      off) [ -f "$MODDIR/fast_off" ] || { touch "$MODDIR/fast_off" 2>/dev/null; mlog "亮屏快充=关（App 期望状态）"; } ;;
      on)  [ -f "$MODDIR/fast_off" ] && { rm -f "$MODDIR/fast_off" 2>/dev/null; mlog "亮屏快充=开（App 期望状态）"; } ;;
    esac
  fi

  # ================= 电量伪装（默认关；只改显示，不动统计）=================
  _socf=/data/local/tmp/temp_chg_socfake
  _fs=/sys/devices/platform/strategy-fg/fake_soc
  _want=off
  if [ -f "$_socf" ]; then
    _v=$(head -c 8 "$_socf" 2>/dev/null | tr -d ' \r\n')
    [ "$_v" = "on" ] && _want=on
  fi
  if [ -w "$_fs" ]; then
    if [ "$_want" = "on" ]; then
      if [ ! -f /data/local/tmp/temp_chg_soc_orig ]; then
        _cur=$(cat "$_fs" 2>/dev/null)
        case "$_cur" in ''|*[!0-9-]*) _cur=-1 ;; esac
        [ "$_cur" = "${SOC_FAKE_TARGET:-10}" ] && _cur=-1
        echo "$_cur" > /data/local/tmp/temp_chg_soc_orig 2>/dev/null
        chmod 666 /data/local/tmp/temp_chg_soc_orig 2>/dev/null
      fi
      _cur=$(cat "$_fs" 2>/dev/null)
      if [ "$_cur" != "${SOC_FAKE_TARGET:-10}" ]; then
        # 开启瞬间：记录 真实容量 - charge_counter 比例，作为偏移
        _c0=$(num "$(cat "$B/capacity" 2>/dev/null)")
        _x0=$(num "$(cat "$B/charge_counter" 2>/dev/null)"); _f0=$(num "$(cat "$B/charge_full" 2>/dev/null)")
        if [ "$_c0" -gt 0 ] && [ "$_x0" -gt 0 ] && [ "$_f0" -gt 0 ]; then
          echo $(( _c0 - _x0 * 100 / _f0 )) > /data/local/tmp/temp_chg_soc_off 2>/dev/null
          chmod 666 /data/local/tmp/temp_chg_soc_off 2>/dev/null
        fi
        echo "${SOC_FAKE_TARGET:-10}" > "$_fs" 2>/dev/null
      fi
    else
      rm -f /data/local/tmp/temp_chg_soc_off 2>/dev/null
      _old=$(cat /data/local/tmp/temp_chg_soc_orig 2>/dev/null)
      case "$_old" in ''|*[!0-9-]*) _old=-1 ;; esac
      [ "$_old" = "${SOC_FAKE_TARGET:-10}" ] && _old=-1
      _cur=$(cat "$_fs" 2>/dev/null)
      if [ -f /data/local/tmp/temp_chg_soc_orig ]; then
        [ "$_cur" != "$_old" ] && echo "$_old" > "$_fs" 2>/dev/null
      else
        [ "$_cur" = "${SOC_FAKE_TARGET:-10}" ] && echo -1 > "$_fs" 2>/dev/null
      fi
    fi
  fi

  # ================= ① 温度伪装（v1.7.1 一比一移植）=================
  if [ -f "$MODDIR/mask_off" ] || [ -f "$MODDIR/.lic_locked" ] || [ "$MASK_ON" != "1" ]; then
    if [ "$mstate" != "off" ]; then
      for z in $ZONES $PAZONES; do echo -999 > "$z/emul_temp" 2>/dev/null; done
      [ -w "$FAKE" ] && echo -999 > "$FAKE" 2>/dev/null
      mlog "温度伪装已关闭 → 恢复真实温度"; mstate="off"
    fi
  else
    mstate="on"
    if [ $(( round % 4 )) -eq 0 ]; then      # 每 8 秒写一次伪装（1.7.1 原为 2 秒，写 60+ 节点太拖采样）
      _mb=/data/local/tmp/temp_chg_maskbusy
      if [ -f "$_mb" ]; then
        _mag=$(($(date +%s 2>/dev/null || echo 0) - $(cat "$_mb" 2>/dev/null || echo 0)))
        [ "$_mag" -gt 45 ] && rm -f "$_mb" 2>/dev/null
      fi
      if [ ! -f "$_mb" ]; then
        date +%s > "$_mb" 2>/dev/null
        ( mask_once; rm -f "$_mb" 2>/dev/null ) >/dev/null 2>&1 &
      fi
    fi
  fi

  # ================= ② 充电管控 + 看门狗 =================
  if [ -f "$MODDIR/fast_off" ] || [ -f "$MODDIR/.lic_locked" ] || [ "$FAST_ON" != "1" ] || [ "$passthru" = "1" ]; then
    if [ "$fmode" != "off" ]; then ctrl_stock; log "快充已关闭 → 已交回官方"; fmode="off"; fi
  else
    st=$(cat "$B/status" 2>/dev/null)
    cap=$(real_soc)
    [ "${HEAT_ON:-0}" = "1" ] && [ "$cool_left" -gt 0 ] && cool_left=$(( cool_left - 1 ))
    case "$st" in
      Charging|Full)
        bad=0
        if [ "$now" -lt "$pause_until" ]; then
          [ "$fmode" != "pause" ] && { log "暂停期内充电已恢复(status=$st)，等暂停结束再接管"; fmode="pause"; }
        else
          rm_state=$(cat "$CHAN_RM" 2>/dev/null); rm_state=$(num "$rm_state")
          [ "$STRATEGY" = "xm_gear" ] && write_rm 1
          set -- $(read_power); p=$1; bw=$2; chgn=$((chgn+1))
          # 闭环开启前先验证档位是否真能控功率（一次性，避免"收到底还控不住"）
          if [ "${POWER_LOOP:-0}" = "1" ] && [ "$STRATEGY" = "xm_gear" ] && [ "${KNOB_DONE:-0}" != "1" ]; then
            knob_probe
            KNOB_DONE=1
            set -- $(read_power); p=$1; bw=$2
          fi
          if [ "${HEAT_ON:-0}" = "1" ] && [ "$cool_left" -le 0 ]; then
            heat_acc=$(( heat_acc + POLL ))
            [ "$heat_acc" -ge "$HEAT_LIMIT" ] && { heat_acc=0; cool_left=$(( HEAT_COOL / POLL )); [ "$cool_left" -lt 1 ] && cool_left=1; log "满功率累计 ${HEAT_LIMIT}s → 降档冷却 ${HEAT_COOL}s"; }
          fi
          if [ "${POWER_LOOP:-0}" = "1" ] && [ "$STRATEGY" = "xm_gear" ] && [ $(( chgn % STEP_EVERY )) -eq 0 ]; then
            hi=$(( TARGET_W + TOL_HI )); lo=$(( TARGET_W - TOL_LO ))
            pv=$bw                       # ★ 用电池侧功率（App 大字那个）比目标，才和"目标功率"一致
            if awk -v p="$pv" -v hi="$hi" 'BEGIN{exit !(p>hi)}'; then
              if [ "$gear" -lt "$GEAR_MAX" ]; then
                # ★ 无效检测：连收 3 次功率都没变化 → 本机这个档位控不了功率，立刻停手别再顶到最大档
                if [ -n "$LOOP_LAST" ] && awk -v a="$LOOP_LAST" -v b="$pv" 'BEGIN{exit !((a-b) < a*0.05)}'; then
                  LOOP_DEAD=$(( LOOP_DEAD + 1 ))
                else
                  LOOP_DEAD=0
                fi
                LOOP_LAST=$pv
                if [ "$LOOP_DEAD" -ge 3 ]; then
                  log "电池侧 ${pv}W 收紧 3 次无变化 → 本机档位对功率无效，停止自动收放，回到最放开档 ${GEAR_MIN}"
                  mlog "功率闭环自停：本机档位控不了功率（收紧 3 次无变化）"
                  echo "本机「档位」对功率无效（连续收紧 3 次、功率没变化）→ 目标功率控制在本机不可用，已自动停止收放并回到最放开档。要用目标功率请换支持的机型。" > /data/local/tmp/temp_chg_loop.txt
                  chmod 666 /data/local/tmp/temp_chg_loop.txt 2>/dev/null
                  POWER_LOOP=0
                  grep -v '^POWER_LOOP=' "$SETF" 2>/dev/null > "$SETF.t"; mv -f "$SETF.t" "$SETF" 2>/dev/null
                  echo "POWER_LOOP=0" >> "$SETF"; chmod 666 "$SETF" 2>/dev/null
                  gear=$GEAR_MIN
                else
                  gear=$((gear+1)); log "电池侧 ${pv}W / 输入 ${p}W 偏高 → 收紧档位=$gear（无效计数 ${LOOP_DEAD}）"
                fi
              fi
            elif awk -v p="$pv" -v lo="$lo" 'BEGIN{exit !(p<lo)}'; then
              [ "$gear" -gt "$GEAR_MIN" ] && { gear=$((gear-1)); loop_dead=0; LOOP_DEAD=0; log "电池侧 ${pv}W 偏低 → 放松档位=$gear"; }
            fi
          fi
          if [ "$STRATEGY" = "xm_gear" ]; then
            ug=$gear
            [ "${POWER_LOOP:-0}" = "1" ] || ug=$GEAR_MIN
            [ "$cool_left" -gt 0 ] && ug=$HEAT_GEAR
            write_lv "$ug"
          else
            ctrl_open
            ug="-"
          fi
          [ "$fmode" != "fast" ] && { log "快充生效：策略=$STRATEGY 档位=$ug 功率=${p}W"; fmode="fast"; }
        fi
        ;;
      *)
        if [ "$(plugged)" = "1" ] && [ "$cap" -lt 95 ]; then
          bad=$(( bad + 1 ))
          if [ $(( bad * POLL )) -ge "$HEALTH_SEC" ]; then
            log "看门狗：插着充电器 ${HEALTH_SEC}s 仍无充电(status=$st 电量=$cap%) → 交回官方并暂停 ${PAUSE_SEC}s"
            ctrl_stock; pause_until=$(( now + PAUSE_SEC )); bad=0; fmode="pause"
          fi
        else
          bad=0
          [ "$fmode" != "idle" ] && { ctrl_stock; log "未充电 → 恢复官方"; fmode="idle"; }
        fi
        ;;
    esac
  fi

  # 稳定跑满 5 分钟才把开机计数清零（防止"开机后几十秒才崩"的重启循环被漏掉）
  if [ "${_BCOK:-0}" != "1" ]; then
    _nnow=$(date +%s 2>/dev/null); case "$_nnow" in ''|*[!0-9]*) _nnow=0 ;; esac
    if [ $(( _nnow - ${_BSTART:-0} )) -ge 120 ]; then
      _BCOK=1; printf '0 %s\n' "$_nnow" > "$BC" 2>/dev/null; chmod 666 "$BC" 2>/dev/null
    fi
  fi
  # —— 应用耗电排行：拔线后 60 秒刷新一次（充电中 300 秒），保证页面数据不过期 ——
  _apn=$(date +%s 2>/dev/null); case "$_apn" in ''|*[!0-9]*) _apn=0 ;; esac
  _apgap=300
  case "$_st0" in Charging|Full) ;; *) _apgap=60 ;; esac
  if [ $(( _apn - ${AUSE_TS:-0} )) -ge "$_apgap" ]; then AUSE_TS=$_apn; ( appuse_snap ) & fi
  # ★ 7.1.2：状态每轮都写（拔线也要 ≤2 秒新鲜）；写之前记时，超过 1 秒落日志便于定位
  _ws0=$(date +%s%N 2>/dev/null); case "$_ws0" in ''|*[!0-9]*) _ws0=0 ;; esac
  write_status
  _ws1=$(date +%s%N 2>/dev/null); case "$_ws1" in ''|*[!0-9]*) _ws1=0 ;; esac
  if [ "$_ws0" -gt 0 ] && [ "$_ws1" -gt "$_ws0" ]; then
    _wms=$(( (_ws1 - _ws0) / 1000000 ))
    [ "$_wms" -ge 1000 ] && mlog "write_status 耗时 ${_wms}ms"
  fi
  # —— 功率曲线采样：每 POWER_LOG_SEC 秒记一行，给 App 画曲线（也方便事后对账）——
  # ★ 拔线时用 2 秒兜底记录（充电 5 秒），保证 App 时间页 2 秒内看到新数据
  _pls=${POWER_LOG_SEC:-5}
  # 7.1.4：曲线 5 秒一条足够；实时数字由 status 提供
  _pe=$(( _pls / POLL )); [ "$_pe" -lt 1 ] && _pe=1
  if [ $(( round % _pe )) -eq 0 ]; then
    _hdr="ts,power_w,in_w,bat_w,temp,capacity,status"
    [ "$(head -1 "$PWRCSV" 2>/dev/null)" = "$_hdr" ] || echo "$_hdr" > "$PWRCSV" 2>/dev/null
    echo "$(date +%s),$([ -n "$_w" ] && echo "$_w" || echo 0),${_iw:-0},${_bw:-0},$(cat $B/temp 2>/dev/null),$(cat $B/capacity 2>/dev/null),$(cat $B/status 2>/dev/null)" >> "$PWRCSV" 2>/dev/null
    # 7.1.3：日常汇总已由 sampler/summary 负责，不再每 2 秒重写 daily.csv（省 IO）
    _ln=$(wc -l < "$PWRCSV" 2>/dev/null)
    case "$_ln" in ''|*[!0-9]*) _ln=0;; esac
    if [ "$_ln" -gt 7200 ]; then
      tail -3600 "$PWRCSV" > "$PWRCSV.tmp" 2>/dev/null && mv "$PWRCSV.tmp" "$PWRCSV" 2>/dev/null
    fi
    chmod 666 "$PWRCSV" 2>/dev/null
  fi
  # —— CPU 频率采样（App 主页显示；按 policy 真实号映射，小核读不到换节点而不是置 0）——
  if [ $(( round % 2 )) -eq 0 ]; then
    _cf=/data/local/tmp/temp_chg_cpu.txt
    _k0=0; _k4=0; _k8=0; _m0=0; _m4=0; _m8=0
    for _pd in /sys/devices/system/cpu/cpufreq/policy*; do
      [ -d "$_pd" ] || continue
      _n=${_pd##*policy}
      _cur=$(cat "$_pd/scaling_cur_freq" 2>/dev/null)
      case "$_cur" in ''|*[!0-9]*) _cur=$(cat "$_pd/cpuinfo_cur_freq" 2>/dev/null) ;; esac
      case "$_cur" in ''|*[!0-9]*) _cur=0 ;; esac
      _mx=$(cat "$_pd/scaling_max_freq" 2>/dev/null)
      case "$_mx" in ''|*[!0-9]*) _mx=$(cat "$_pd/cpuinfo_max_freq" 2>/dev/null) ;; esac
      case "$_mx" in ''|*[!0-9]*) _mx=0 ;; esac
      case "$_n" in
        0) _k0=$_cur; _m0=$_mx ;;
        4) _k4=$_cur; _m4=$_mx ;;
        8) _k8=$_cur; _m8=$_mx ;;
      esac
    done
    

# ★ 8.6.6：热区类型缓存，避免每拍读 75 个 type 文件（CPU 空转/发热的一大来源）
    _tzl=/data/local/tmp/mkc_tz_cpu.txt
    _tzn=$(wc -l < "$_tzl" 2>/dev/null || echo 0)
    if [ "${_tzn:-0}" -lt 1 ] || [ $(( now % 3600 )) -lt "$POLL" ]; then
      : > "$_tzl.t"
      for _z in /sys/class/thermal/thermal_zone*; do
        _ty=$(cat "$_z/type" 2>/dev/null)
        case "$_ty" in cpu*) echo "$_z/temp" >> "$_tzl.t" ;; esac
      done
      mv -f "$_tzl.t" "$_tzl" 2>/dev/null; chmod 666 "$_tzl" 2>/dev/null
    fi
    _rt=0
    while read -r _zp; do
      [ -n "$_zp" ] || continue
      _t=$(num "$(cat "$_zp" 2>/dev/null)")
      [ "$_t" -gt "$_rt" ] && _rt=$_t
    done < "$_tzl"
    echo "cur0=$_k0 cur4=$_k4 cur8=$_k8 max0=$_m0 max4=$_m4 max8=$_m8 cpu_real=$_rt save=off" > "$_cf.tmp" 2>/dev/null
    mv -f "$_cf.tmp" "$_cf" 2>/dev/null; chmod 666 "$_cf" 2>/dev/null
  fi

  # ================= 拔线后用电记录（调用采样核心 unplug_tick，1 秒级）=================
  _dt=$POLL
  if [ "${_LASTNOW:-0}" -gt 0 ]; then _dt=$(( now - _LASTNOW )); fi
  _LASTNOW=$now
  # ★ 8.3.1：真正的"拔电瞬间"（上拍插着、这拍拔了）→ 会话一定归零重开
  _pf=/data/local/tmp/mkc_plug_prev
  _pnow=$(plugged)
  _pprev=; [ -s "$_pf" ] && _pprev=$(cat "$_pf" 2>/dev/null | tr -d ' \r\n')
  case "$_pnow" in ''|*[!0-9]*) _pnow=0 ;; esac
  if [ "$_pprev" = "1" ] && [ "$_pnow" = "0" ]; then
    rm -f /data/local/tmp/mkc_sess_state "$URS" 2>/dev/null
    # 会话排行清零（避免旧数据继续显示）
    echo "# 采样拔电后 CPU 时间排行（秒）  $(date '+%m-%d %H:%M')" > /data/local/tmp/temp_chg_appuse.txt 2>/dev/null
    chmod 666 /data/local/tmp/temp_chg_appuse.txt 2>/dev/null
    rm -f /data/local/tmp/temp_chg_uidcpu_acc /data/local/tmp/temp_chg_uidcpu_prev 2>/dev/null
    mlog "拔电事件：本次用电归零重开"
  fi
  echo "$_pnow" > "$_pf" 2>/dev/null; chmod 666 "$_pf" 2>/dev/null

  # ★ 8.3.0：插电即结束本次拔电会话（旧版只删了 URS，真正在用的 mkc_sess_state 没删 → 不归零）
  if [ "$_st0" = "Charging" ] || [ "$_st0" = "Full" ] || [ "$(plugged)" = "1" ]; then
    # ★ 8.5.0：一识别到充电，本次用电立刻归零（显示也归零），拔电后从头算
    if [ -s /data/local/tmp/mkc_sess_state ] || [ -s "$URS" ]; then
      mlog "识别到充电 → 本次用电归零"
    fi
    rm -f /data/local/tmp/mkc_sess_state "$URS" 2>/dev/null
    # 会话排行清零（避免旧数据继续显示）
    echo "# 采样拔电后 CPU 时间排行（秒）  $(date '+%m-%d %H:%M')" > /data/local/tmp/temp_chg_appuse.txt 2>/dev/null
    chmod 666 /data/local/tmp/temp_chg_appuse.txt 2>/dev/null
    rm -f /data/local/tmp/temp_chg_uidcpu_acc /data/local/tmp/temp_chg_uidcpu_prev 2>/dev/null
    _capN=$(real_soc)
    {
      echo "开始=$(date '+%m-%d %H:%M')"
      echo "时长分钟=0"; echo "亮屏分钟=0"; echo "息屏分钟=0"; echo "待机分钟=0"
      echo "耗电=0.00Wh"; echo "耗电积分=0.00Wh"; echo "平均功率=0.00W"
      echo "电量=${_capN}%→${_capN}%"; echo "掉电=0%"
    } > "$UOUT.t" && mv -f "$UOUT.t" "$UOUT" 2>/dev/null
    chmod 666 "$UOUT" 2>/dev/null
  fi
  case "$_st0" in
    Charging|Full) : ;;
    *)
      if [ "$(plugged)" = "0" ]; then
        # 兜底①：会话里电量反而涨了 ≥3%（说明中途充过电）→ 结束旧会话，重开
        if [ -s /data/local/tmp/mkc_sess_state ]; then
          read -r _cs _c0x _cnx _w0 _s0 _b0 _l0 < /data/local/tmp/mkc_sess_state 2>/dev/null
          _capx=$(real_soc)
          case "$_c0x" in ''|*[!0-9]*) _c0x=$_capx ;; esac
          if [ "$_capx" -ge $(( _c0x + 3 )) ]; then
            rm -f /data/local/tmp/mkc_sess_state 2>/dev/null
            mlog "拔电会话：电量回升（$_c0x→$_capx）→ 会话归零重开"
          fi
          # 兜底②：会话超过 30 小时 → 强制重开
          _age=$(( $(date +%s) - ${_cs:-0} )); [ "$_age" -gt 108000 ] && { rm -f /data/local/tmp/mkc_sess_state 2>/dev/null; mlog "拔电会话超 30 小时 → 重开"; }
        fi
        _br=$(screen_on)
        _so=$(sampler_session "$now" "$(real_soc)" "${_bw#-}" "$_br")
        _ss=$(echo "$_so"|cut -d' ' -f1); _sc0=$(echo "$_so"|cut -d' ' -f2); _scl=$(echo "$_so"|cut -d' ' -f3)
        _swh=$(echo "$_so"|cut -d' ' -f4); _sscr=$(echo "$_so"|cut -d' ' -f5); _ssb=$(echo "$_so"|cut -d' ' -f6)
        _ssec=$(( _sscr + _ssb ))                       # 时长 = 亮屏 + 待机（守护只在这些时间里记）
        _smin=$(( _ssec / 60 ))
        # ★ 7.4.0：耗电按「电量差 × 每 1% 能量」算（和电量条严格一致）；积分值只做参考
        _cf=$(num "$(cat $B/charge_full 2>/dev/null)"); _vv=$(num "$(cat $B/voltage_now 2>/dev/null)")
        _drop=$(( _sc0 - _scl )); [ "$_drop" -lt 0 ] && _drop=0
        # ★ 8.0.1：耗电以「积分能量」为准（与实时功率同源）；百分比由它反算，保证三项自洽
        _cell_wh=$(awk -v cf="$_cf" -v v="$_vv" -v k="$(cell_factor)" 'BEGIN{ if(cf>0 && v>0) printf "%.2f", k*((cf/1e6)*(v/1e6)); else print "0.00" }')
        # ★ 8.4.0：以「电量差」为准（用户看到的电量条），能量=掉电×每1%能量×电芯数；
        #          积分值另存做对账（积分受单节点电流偏小影响，不能直接当显示值）
        _dropg=$(( _sc0 - _scl )); [ "$_dropg" -lt 0 ] && _dropg=0
        _per1=$(awk -v cf="$_cf" -v v="$_vv" -v k="$(cell_factor)" 'BEGIN{ if(cf>0&&v>0) printf "%.4f", k*(cf/1e6)*(v/1e6)/100; else print 0 }')
        _whg=$(awk -v d="$_dropg" -v p="$_per1" 'BEGIN{ printf "%.2f", d*p }')
        _dropc=$_dropg
        _use=$_whg
        # 平均功率用"积分能量"（平滑），避免电量按整数跳变导致 1% 时算出 20W+
        _savg=$(awk -v w="$_swh" -v sec="$_ssec" 'BEGIN{ if(sec<=0) print "0.00"; else printf "%.2f", w/(sec/3600) }')
        {
          echo "开始=$(date -d @$_ss +'%m-%d %H:%M' 2>/dev/null || echo "$_ss")"
          echo "时长分钟=$_smin"
          echo "亮屏分钟=$(( _sscr / 60 ))"
          echo "息屏分钟=$(( _ssb / 60 ))"
          echo "待机分钟=$(( _ssb / 60 ))"
          echo "耗电=${_use}Wh"
          echo "耗电积分=${_swh}Wh"
          echo "平均功率=${_savg}W"
          echo "电量=${_sc0}%→${_scl}%"
          echo "掉电=${_dropc}%"
        } > "$UOUT.t" && mv -f "$UOUT.t" "$UOUT"
        chmod 666 "$UOUT" 2>/dev/null
        chmod 666 "$OUT" "$URS" "$UOUT" 2>/dev/null
      fi ;;
  esac

  # —— 充电时段统计：开始/结束/时长/充入 Wh/峰值 W（按电池侧功率积分）——
  if [ "$_st0" = "Charging" ] || [ "$_st0" = "Full" ]; then
    [ "$SS" = "0" ] && { SS=$now; SC0=$(real_soc); SSW=0; SMX=0; SN=0; }
    _wb=${_bw#-}
    SN=$(( SN + 1 ))
    SSW=$(awk -v a="$SSW" -v w="$_wb" -v t="$POLL" 'BEGIN{ printf "%.1f", a + w*t }')
    SMX=$(awk -v a="$SMX" -v w="$_wb" 'BEGIN{ printf "%.2f", (w>a)?w:a }')
  elif [ "$SS" != "0" ]; then
    L_SEC=$(( now - SS )); L_S=$SS; L_E=$now
    L_WH=$(awk -v a="$SSW" 'BEGIN{ printf "%.3f", a/3600 }')
    _cap1=$(real_soc)
    if [ ! -s "$SESS" ]; then echo "start,end,sec,wh,cap0,cap1,maxw" >> "$SESS" 2>/dev/null; fi
    echo "$L_S,$L_E,$L_SEC,$L_WH,$SC0,$_cap1,$SMX" >> "$SESS" 2>/dev/null
    _sl=$(wc -l < "$SESS" 2>/dev/null); case "$_sl" in ''|*[!0-9]*) _sl=0;; esac
    [ "$_sl" -gt 500 ] && { tail -250 "$SESS" > "$SESS.t" 2>/dev/null && mv "$SESS.t" "$SESS" 2>/dev/null; }
    chmod 666 "$SESS" 2>/dev/null
    mlog "充电结束：$(date -d @$L_S +%H:%M 2>/dev/null || echo $L_S) → $(date -d @$L_E +%H:%M 2>/dev/null || echo $L_E) 共 ${L_SEC}s 充入 ${L_WH}Wh 峰值 ${SMX}W"
    SS=0; SSW=0; SMX=0; SN=0
  fi

  # —— 充电时抓全节点快照（用来校准"到底哪一路才算 Scene 说的瓦数"）——
  if [ "$_st0" = "Charging" ] || [ "$_st0" = "Full" ]; then
    _ne=$(( 30 / POLL )); [ "$_ne" -lt 1 ] && _ne=1
    if [ $(( round % _ne )) -eq 0 ]; then
      {
        echo "=== $(date "+%m-%d %H:%M:%S") status=$_st0 power_w=$_w in_w=$_iw bat_w=$_bw src=$_src cells=$_cells ==="
        for _d in /sys/class/power_supply/*; do
          _n=$(basename "$_d")
          echo "$_n type=$(cat $_d/type 2>/dev/null) online=$(cat $_d/online 2>/dev/null) present=$(cat $_d/present 2>/dev/null) V=$(cat $_d/voltage_now 2>/dev/null) I=$(cat $_d/current_now 2>/dev/null) P=$(cat $_d/power_now 2>/dev/null) Imax=$(cat $_d/current_max 2>/dev/null) Ilim=$(cat $_d/input_current_limit 2>/dev/null)"
        done
      } >> "$NODES" 2>/dev/null
      _nl=$(wc -l < "$NODES" 2>/dev/null); case "$_nl" in ''|*[!0-9]*) _nl=0;; esac
      if [ "$_nl" -gt 400 ]; then tail -200 "$NODES" > "$NODES.t" 2>/dev/null && mv "$NODES.t" "$NODES" 2>/dev/null; fi
      chmod 666 "$NODES" 2>/dev/null
    fi
  fi
  # —— 授权校验：没授权就强制关闭亮屏快充与温度伪装（开机也会压住，不依赖 App 是否在跑）——
  if [ $(( round % 15 )) -eq 0 ]; then
    if lic_check; then
      if [ -f "$MODDIR/.lic_locked" ]; then
        rm -f "$MODDIR/.lic_locked" 2>/dev/null
        mlog "授权有效：已解除授权锁（用户自己的开关保持不变）"
        log "授权有效：解除授权锁"
      fi
      lic_warned=0
    else
      if [ ! -f "$MODDIR/.lic_locked" ]; then
        touch "$MODDIR/.lic_locked" 2>/dev/null
        ctrl_stock; fmode=""
        mlog "未激活/授权失效：已停用亮屏快充与温度伪装"
        log "未激活：授权锁已上，写 /data/local/tmp/temp_chg_license 后恢复"
      fi
      lic_warned=1
    fi
  fi
  # 后台偶发检测高耗电应用 → 通知（默认半小时最多一次）
  if [ $(( round % ${HOG_EVERY:-300} )) -eq 0 ]; then ( hog_auto ) & fi

  # 通道文件自愈：被清掉就重建 0666（否则 App 在 /data/local/tmp 里新建不了文件，会写不进去）
  if [ $(( round % 150 )) -eq 0 ]; then
    for _f in "$CMDF" "$PWRCSV" "$SETF" "$LICF" "/data/local/tmp/temp_chg_trial" "/data/local/tmp/temp_chg_fix.log" "/data/local/tmp/temp_chg_chan.cfg" "/data/local/tmp/temp_chg_export_path.txt" \
              "/data/local/tmp/temp_chg_socfake" "/data/local/tmp/temp_chg_maskwant" "/data/local/tmp/temp_chg_fastwant" "/data/local/tmp/temp_chg_remove" "/data/local/tmp/temp_chg_trial_ext" "/data/local/tmp/mkc_app_sample.csv"; do
      [ -f "$_f" ] || : > "$_f" 2>/dev/null
      chmod 666 "$_f" 2>/dev/null
    done
  fi
  # ★ 6.2.0：跨天时把当天的应用排行存档（App 点某一天时显示"当天全部使用"）
  _dnow=$(date +%Y-%m-%d 2>/dev/null)
  if [ -n "${REC_DAY:-}" ] && [ "$_dnow" != "$REC_DAY" ]; then
    cp -f /data/local/tmp/temp_chg_appuse.txt "/data/local/tmp/mkc_rec_appuse_${REC_DAY}.txt" 2>/dev/null
    chmod 666 "/data/local/tmp/mkc_rec_appuse_${REC_DAY}.txt" 2>/dev/null
    mlog "跨天：已存档 ${REC_DAY} 的应用排行"
  fi
  REC_DAY=$_dnow

  # ★ 7.0.0：记录（亮屏/待机/功耗/应用能耗）—— 采样器统一算，落盘 7 天
  if [ -n "${_st0:-}" ]; then
    # ★ 每拍（约 2 秒）累计亮屏/待机与能量，落盘仍是 30 秒一条 → 时间精度 2 秒级
    _rbl=$(screen_on)                       # 1=亮屏 0=息屏（息屏时间 = 待机时间）
    _rt=$(date +%s)
    _out=$(sampler_day "$_rt" "$_st0" "${_w:-0}" "$_rbl")
    REC_TOT=$(echo "$_out" | cut -d' ' -f1); REC_SCR=$(echo "$_out" | cut -d' ' -f2)
    REC_SB=$(echo "$_out" | cut -d' ' -f3); REC_DIS=$(echo "$_out" | cut -d' ' -f4); REC_CHG=$(echo "$_out" | cut -d' ' -f5)
  fi
  _recnow=$(date +%s 2>/dev/null); case "$_recnow" in ''|*[!0-9]*) _recnow=0 ;; esac
  if [ -n "${_st0:-}" ] && [ $(( _recnow - ${REC_LAST_T:-0} )) -ge 28 ]; then
    REC_LAST_T=$_recnow
    _today=$(sampler_today)
    summary_update "$_today" "$REC_TOT" "$REC_SCR" "$REC_SB" "$REC_DIS" "$REC_CHG"
    _csv=/data/local/tmp/mkc_rec_${_today}.csv
    [ -s "$_csv" ] || echo "ts,status,cap,cap_real,power_w,temp_c,screen_on,screen_sec,standby_sec,dis_wh,chg_wh,volt_v,curr_a,cpu_temp,backlight,freq_mhz" > "$_csv"
    REC_V=$(awk -v v="$(cat $B/voltage_now 2>/dev/null)" 'BEGIN{printf "%.2f", v/1000000}')
    REC_A=$(awk -v i="$(cat $B/current_now 2>/dev/null)" 'BEGIN{printf "%.2f", i/1000000}')
    REC_CT=$(awk -v t="$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)" 'BEGIN{printf "%.1f", t/1000}')
    REC_F=$(awk -v f="$(cat /sys/devices/system/cpu/cpufreq/policy0/scaling_cur_freq 2>/dev/null)" 'BEGIN{printf "%.0f", f/1000}')
    _wabs=${_w:-0}; _wabs=${_wabs#-}
    _pm=$(power_multi); _w1=$(echo "$_pm"|cut -d'|' -f1); _w2=$(echo "$_pm"|cut -d'|' -f2); _w3=$(echo "$_pm"|cut -d'|' -f3)
    _pick=$(pow_pick "$_w1" "$_w2" "$_w3"); POW_SRC=${_pick##* }
    _socp=$(soc_pick "$(num "$(cat $B/capacity 2>/dev/null)")" "$(num "$(cat $B/charge_counter 2>/dev/null)")" "$(num "$(cat $B/charge_full 2>/dev/null)")" "$(real_soc)")
    SOC_SRC=${_socp##* }
    echo "$_rt,$_st0,${_cap:-0},$(real_soc),$_wabs,$(cat $B/temp 2>/dev/null),$([ "$_rbl" -gt 0 ] && echo 1 || echo 0),$REC_SCR,$REC_SB,$REC_DIS,$REC_CHG,$REC_V,$REC_A,$REC_CT,$_rbl,$REC_F" >> "$_csv" 2>/dev/null
    chmod 666 "$_csv" 2>/dev/null
    # 应用能耗：当天 CPU 占比 × 当天放电 Wh → 排行（按占比输出，App 显示 %）
    if [ -s /data/local/tmp/mkc_day_acc ]; then
      app_energy_emit /data/local/tmp/mkc_day_acc "$REC_DIS" "$(cat /data/local/tmp/mkc_day_cap0 2>/dev/null)" "$(real_soc)" \
        "/data/local/tmp/mkc_rec_appuse_${_today}.txt" /data/system/packages.list "当日应用能耗"
    fi
  fi

  _loop_end=$(date +%s 2>/dev/null); case "$_loop_end" in ''|*[!0-9]*) _loop_end=0 ;; esac
  if [ -n "${_loop_start:-}" ] && [ "$_loop_end" -gt "$_loop_start" ]; then
    _lp=$(( _loop_end - _loop_start ))
    [ "$_lp" -ge 4 ] && mlog "主循环耗时 ${_lp}s（超过 4 秒）"
  fi
  _loop_start=$_loop_end

  # 7.4.1：取消开机自动跑光感自愈（会打断使用），只保留诊断页手动按钮
  # ★ 8.6.2：App 采样服务被杀就把它拉起来（模块侧兜底保活）
  if [ $(( now % 60 )) -lt "$POLL" ]; then
    if ! pidof com.dsh.qschg >/dev/null 2>&1; then
      am start-foreground-service -n com.dsh.qschg/.SampleService >/dev/null 2>&1
      mlog "App 进程不在 → 已尝试拉起采样服务" 
    fi
  fi

  # ★ 8.2.0：每 30 分钟导入一次系统「屏幕使用时间」（兜底/对账）
  _mi_now=$(date +%s 2>/dev/null); case "$_mi_now" in ''|*[!0-9]*) _mi_now=0 ;; esac
  if [ $(( _mi_now - ${MI_TS:-0} )) -ge 1800 ]; then
    MI_TS=$_mi_now
    ( mi_usage_import "$(sampler_today)" >/dev/null 2>&1 ) &
  fi

  # ★ 7.3.0：记录写入看门狗 —— CSV 超过 120 秒没有新增，自动重启守护（防卡死）
  if [ $(( round % 15 )) -eq 0 ]; then
    _wdnow=$(date +%s 2>/dev/null); case "$_wdnow" in ''|*[!0-9]*) _wdnow=0 ;; esac
    _wdf=/data/local/tmp/mkc_rec_$(date +%Y-%m-%d).csv
    _wdl=$(stat -c %Y "$_wdf" 2>/dev/null); case "$_wdl" in ''|*[!0-9]*) _wdl=0 ;; esac
    if [ "$_wdl" -gt 0 ] && [ $(( _wdnow - _wdl )) -gt 120 ]; then
      mlog "记录已 $(( _wdnow - _wdl ))s 未写入 → 重启守护"
      ( setsid sh "$MODDIR/service.sh" </dev/null >/dev/null 2>&1 & )
      sleep 1
      kill -9 $$ 2>/dev/null
    fi
  fi

  # ★ 5.9.0：采样准确率（实际拍数 vs 应有拍数）+ 最大间隔，替代原来的"心跳"
  SAM_N=$(( ${SAM_N:-0} + 1 ))
  if [ -z "${SAM_T0:-}" ]; then SAM_T0=$(date +%s); SAM_N=1; SAM_GAP=0; fi
  _sn=$(date +%s 2>/dev/null); case "$_sn" in ''|*[!0-9]*) _sn=0 ;; esac
  if [ -n "${SAM_LAST:-}" ] && [ "$_sn" -gt "$SAM_LAST" ]; then
    _g=$(( _sn - SAM_LAST )); [ "$_g" -gt "${SAM_GAP:-0}" ] && SAM_GAP=$_g
  fi
  SAM_LAST=$_sn
  _el=$(( ${_sn:-0} - ${SAM_T0:-0} ))
  if [ "$_el" -ge 60 ]; then
    # 覆盖率 = 当天累计时长 / 当天墙钟时长
    _dstart=/data/local/tmp/mkc_day_start
    _dnow=$(date +%Y-%m-%d 2>/dev/null)
    _dday=$(cut -d' ' -f1 "$_dstart" 2>/dev/null)
    if [ "$_dday" != "$_dnow" ] || [ ! -s "$_dstart" ]; then echo "$_dnow $_sn" > "$_dstart" 2>/dev/null; chmod 666 "$_dstart" 2>/dev/null; fi
    _dst=$(cut -d' ' -f2 "$_dstart" 2>/dev/null); case "$_dst" in ''|*[!0-9]*) _dst=$_sn ;; esac
    _wall=$(( _sn - _dst )); [ "$_wall" -lt 60 ] && _wall=60
    _cov=$(cut -d' ' -f2 /data/local/tmp/mkc_day_state 2>/dev/null); case "$_cov" in ''|*[!0-9]*) _cov=0 ;; esac
    _acc=$(( _cov * 100 / _wall )); [ "$_acc" -gt 100 ] && _acc=100
    printf '运行中 · 采样 %s%% · 最大间隔 %ss · %ss/拍\n' "$_acc" "${SAM_GAP:-0}" "$POLL" > /data/local/tmp/temp_chg_loop.txt 2>/dev/null
    chmod 666 /data/local/tmp/temp_chg_loop.txt 2>/dev/null
    SAMPLE_ACC=$_acc; SAMPLE_GAP_MAX=${SAM_GAP:-0}
    SAM_N=0; SAM_T0=$_sn; SAM_GAP=0
  fi
  # 每轮都刷新一行给 App（准确率还没算出来时显示"校准中"）
  if [ $(( ${SAM_N:-1} % 5 )) -eq 0 ]; then
    if [ "${SAMPLE_ACC:--1}" -ge 0 ] 2>/dev/null; then
      printf '运行中 · 采样 %s%% · 最大间隔 %ss · %ss/拍\n' "$SAMPLE_ACC" "${SAMPLE_GAP_MAX:-0}" "$POLL" > /data/local/tmp/temp_chg_loop.txt 2>/dev/null
    else
      printf '运行中 · 采样校准中 · %ss/拍\n' "$POLL" > /data/local/tmp/temp_chg_loop.txt 2>/dev/null
    fi
    chmod 666 /data/local/tmp/temp_chg_loop.txt 2>/dev/null
  fi

  # ★ 5.8.1：固定 2 秒节拍（低功耗、无时无刻都在采样）；dt 用真实经过时间，统计不再缩水
  _tnow=$(date +%s 2>/dev/null); case "$_tnow" in ''|*[!0-9]*) _tnow=0 ;; esac
  if [ -n "${LAST_TICK:-}" ] && [ "$_tnow" -gt "$LAST_TICK" ]; then DT=$(( _tnow - LAST_TICK )); else DT=$POLL; fi
  [ "$DT" -lt 1 ] && DT=1
  [ "$DT" -gt 60 ] && DT=60
  LAST_TICK=$_tnow
  sleep "$POLL"
done
