#!/system/bin/sh
# 安装时执行（KernelSU / Magisk 刷入本模块时）：停用并卸载旧的分离式模块，
# 顺手还原它们写下的节点，避免"合并"只是表面合并、实际还有旧守护在写。
SKIPUNZIP=0
for m in chg_thermal_42c; do
  [ -d "/data/adb/modules/$m" ] || continue
  touch "/data/adb/modules/$m/disable" 2>/dev/null
  touch "/data/adb/modules/$m/remove" 2>/dev/null
  ui_print "  · 已停用旧模块 $m（重启后自动卸载，无需手动处理）"
done
# 还原旧模块写下的充电节点
echo 0 > /sys/class/xm_power/charger/charger_thermal/wired_thermal_remove 2>/dev/null
echo 12 > /sys/class/xm_power/charger/charger_thermal/wired_ctrl_limit 2>/dev/null
# 停掉旧守护（含同路径的旧版温度伪装守护）
for d in /proc/[0-9]*; do
  p=${d#/proc/}
  a1=$(tr '\0' '\n' < "$d/cmdline" 2>/dev/null | grep -x "/data/adb/modules/temp_mask_all/service.sh")
  case "$a1" in
    */temp_mask_all/service.sh|*/chg_thermal_42c/service.sh) kill "$p" 2>/dev/null ;;
  esac
done
rm -f /data/local/tmp/temp_mask_all.pid /data/local/tmp/chg_fast.pid /data/local/tmp/chg_thermal.pid 2>/dev/null
ui_print "  二合一 v2.0.0 安装完成：一份守护 = 温度伪装 + 亮屏快充 + 充电看门狗"
