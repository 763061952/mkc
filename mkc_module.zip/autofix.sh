#!/system/bin/sh
# 一键修复（真动手版）  作者：酷安@happier2
#   A) 别的机型打不开亮屏快充 → 逐节点「试写 + 回读」验证，找出真正写得进去的放开通道，
#      落盘 temp_chg_chan.cfg，重启守护后按它走（原来只看权限位：权限可写但写进去被拒就白搭）
#   B) 充电功率时高时低 → 判断成因并动手：
#        · 模块自己收放档 → 关功率闭环 + 放宽调档间隔
#        · 温度（厂家温控）→ 放宽冷却回差（阈值附近不再来回跳）
#        · 都不是 → 如实说是充电器/协议/线材，软件不动
MODDIR=${0%/*}
[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"
SETF=/data/local/tmp/temp_chg_set.cfg
CHAN=/data/local/tmp/temp_chg_chan.cfg
CSV=/data/local/tmp/temp_chg_power.csv
CHGLOG=${CHGLOG:-/data/local/tmp/chg_fast.log}
MASKLOG=${MASKLOG:-/data/local/tmp/temp_mask_all.log}
PIDF=/data/local/tmp/temp_chg_all.pid
B=/sys/class/power_supply/battery
U=/sys/class/power_supply/usb

num(){ _x=${1#-}; case "$_x" in ''|*[!0-9]*) echo 0 ;; *) echo "$1" ;; esac; }
cfgget(){ grep -m1 "^$1=" "$SETF" 2>/dev/null | cut -d= -f2; }
cfgset(){
  [ -f "$SETF" ] || : > "$SETF"
  grep -v "^$1=" "$SETF" 2>/dev/null > "$SETF.t"
  mv -f "$SETF.t" "$SETF" 2>/dev/null
  echo "$1=$2" >> "$SETF"
  chmod 666 "$SETF" 2>/dev/null
}
FIXED=0
TRY_NEW=0
try_write(){
  _f=$1; _v=$2
  [ -w "$_f" ] || return 1
  _old=$(cat "$_f" 2>/dev/null)
  ( echo "$_v" > "$_f" ) 2>/dev/null || { [ -n "$_old" ] && { echo "$_old" > "$_f"; } 2>/dev/null; return 1; }
  TRY_NEW=$(num "$(cat "$_f" 2>/dev/null)")
  [ -n "$_old" ] && { echo "$_old" > "$_f"; } 2>/dev/null
  [ "$TRY_NEW" -gt 0 ] || return 1
  return 0
}
target_for(){
  _c=$(num "$(cat "$1" 2>/dev/null)")
  if [ "$_c" -gt 100000 ]; then echo 3000000; else echo 3000; fi
}

echo "===== 一键修复 $(date '+%m-%d %H:%M:%S') ====="
echo "机型：$(getprop ro.product.brand) $(getprop ro.product.model) ｜ Android $(getprop ro.build.version.release) ｜ 内核 $(uname -r 2>/dev/null)"
echo
echo "① 亮屏快充能不能打开（逐个节点试写 + 回读，不是只看权限）"
FOUND_CUR=""; FOUND_USB=""; FOUND_GEAR=""
CAND_CUR="$B/constant_charge_current_max $B/hw_charge_current_max $B/charge_current_max \
 $B/current_max $B/constant_charge_current $B/charge_control_limit $B/input_current_limit \
 /sys/class/power_supply/bms/current_max /sys/class/power_supply/main/current_max \
 /sys/class/power_supply/battery_charger/current_max /sys/class/power_supply/charger/current_max \
 /sys/devices/platform/charger/current_max /proc/mtk_battery_cmd/current_cmd \
 /proc/mtk_battery_cmd/en_power_path"
for f in $CAND_CUR; do
  [ -e "$f" ] || continue
  t=$(target_for "$f")
  if try_write "$f" "$t"; then
    FOUND_CUR="$f"; echo "  [OK] 能写的电池侧电流节点：$f（试写 $t → 回读 $TRY_NEW）"; FIXED=1; break
  else
    echo "  [--] $f：写入被内核拒绝（权限可写也没用）"
  fi
done
for f in $U/current_max $U/input_current_limit; do
  [ -e "$f" ] || continue
  t=$(target_for "$f")
  if try_write "$f" "$t"; then
    FOUND_USB="$f"; echo "  [OK] 能写的输入侧电流节点：$f（试写 $t → 回读 $TRY_NEW）"; FIXED=1; break
  else
    echo "  [--] $f：写入被内核拒绝"
  fi
done
for base in /sys/class/xm_power/charger/charger_thermal /sys/class/xm_power/charger \
            /sys/class/power_supply/battery/charger_thermal; do
  [ -w "$base/wired_ctrl_limit" ] || continue
  _old=$(cat "$base/wired_ctrl_limit" 2>/dev/null)
  if try_write "$base/wired_ctrl_limit" 1; then
    FOUND_GEAR="$base"; echo "  [OK] 厂商档位通道：$base（档位可写，回读 $TRY_NEW）"; FIXED=1
  else
    echo "  [--] 厂商档位通道 $base：档位写不进去"
  fi
  [ -n "$_old" ] && { echo "$_old" > "$base/wired_ctrl_limit"; } 2>/dev/null
  break
done
if [ -n "$FOUND_GEAR" ]; then _s=xm_gear
elif [ -n "$FOUND_CUR" ]; then _s=cur_max
elif [ -n "$FOUND_USB" ]; then _s=usb_max
else _s=none; fi
{
  echo "STRATEGY=$_s"
  echo "CH_CUR=$FOUND_CUR"
  echo "CH_USB=$FOUND_USB"
  echo "GEAR_BASE=$FOUND_GEAR"
  echo "ts=$(date +%s)"
} > "$CHAN" 2>/dev/null
chmod 666 "$CHAN" 2>/dev/null
case "$_s" in
  xm_gear) echo "  >> 结论：本机走厂商档位通道，快充可以打开" ;;
  cur_max|usb_max) echo "  >> 结论：本机没有厂商档位通道，已改用能写入的通用电流节点（落盘 $CHAN）" ;;
  none) echo "  >> 结论：本机内核不允许应用层改充电电流 → 亮屏快充打不开；温度伪装仍可用（内核限制，不是模块问题）" ;;
esac
echo
echo "② 充电功率时高时低（近 1 小时采样）"
if [ ! -s "$CSV" ]; then
  echo "  · 还没有采样数据（充电几分钟后再点一次）"
else
  ST=$(awk -F, '
    NR>1 && ($4+0)>=2 && ($5+0)>100 && ($5+0)<700 { p=$4+0; t=($5+0)/10.0; a[n]=p; b[n]=t; n++;
      if (n==1 || p>mx) mx=p; if (n==1 || p<mn) mn=p }
    END{
      if (n<6) { printf "n=%d\n", n; exit }
      for (i=0;i<n;i++){ if (a[i]>=mx*0.8){hs+=b[i];hn++} else if (a[i]<=mx*0.55){ls+=b[i];ln++} }
      thi=(hn?hs/hn:0); tlo=(ln?ls/ln:0)
      w=0; for (i=0;i<n;i++){ if (a[i]>=mx*0.75) w=1; else if (a[i]<=mx*0.5 && w){f++;w=0} }
      printf "n=%d mx=%.1f mn=%.1f thi=%.1f tlo=%.1f f=%d\n", n, mx, mn, thi, tlo, f
    }' "$CSV" 2>/dev/null)
  eval "$(echo "$ST" | tr ' ' '\n' | sed 's/^/V_/')"
  SN=$(num "$V_n"); SMX=${V_mx:-0}; SMN=${V_mn:-0}; STHI=${V_thi:-0}; STLO=${V_tlo:-0}; SF=$(num "$V_f")
  if [ "$SN" -lt 6 ]; then
    echo "  · 充电样本太少（$SN 个），先充 10 分钟再点一次"
  else
    SD=$(awk -v a="$STLO" -v b="$STHI" 'BEGIN{printf "%.1f", a-b}')
    SDF=$(awk -v d="$SD" 'BEGIN{print (d>=0.8)?1:0}')
    if awk -v a="$STLO" 'BEGIN{exit !(a+0==0)}'; then
      echo "  · 峰值 ${SMX}W ｜ 谷值 ${SMN}W ｜ 掉档 ${SF} 次 ｜（最近没有低功率样本，温度对比跳过）"
    else
      echo "  · 峰值 ${SMX}W ｜ 谷值 ${SMN}W ｜ 掉档 ${SF} 次 ｜ 高功率时 ${STHI}℃、掉下来时 ${STLO}℃（差 ${SD}℃）"
    fi
    if [ "$SF" -ge 3 ] && [ "$SDF" = "0" ]; then
      OURS=$(tail -200 "$CHGLOG" 2>/dev/null | grep -c "档位")
      if [ "${OURS:-0}" -gt 0 ]; then
        _se=$(num "$(cfgget STEP_EVERY)"); _se2=$_se; [ "$_se2" -lt 6 ] && _se2=6
        _pl=$(num "$(cfgget POWER_LOOP)")
        if [ "$_se" != "$_se2" ] || [ "$_pl" != "0" ]; then
          cfgset STEP_EVERY "$_se2"; cfgset POWER_LOOP 0
          echo "  >> 是模块自己在收放档造成的 → 已关闭「功率闭环」，调档间隔 ${_se} → ${_se2}，改为一直用最放开档"
          FIXED=1
        else
          echo "  >> 是模块自己在收放档造成的；功率闭环已经是关的（调档间隔 ${_se2}），无需再改"
        fi
      else
        echo "  >> 不是温度、也不是软件收放档 → 多为充电器/协议重协商、线材或触点；建议换线换头再试（软件不动）"
      fi
    elif [ "$SDF" = "1" ]; then
      _hi=$(num "$(cfgget REAL_HI)"); _lo=$(num "$(cfgget REAL_LO)")
      [ "$_hi" -le 0 ] && _hi=420
      [ "$_lo" -le 0 ] && _lo=$((_hi-40))
      _gap=$((_hi-_lo))
      if [ "$_gap" -lt 50 ]; then
        cfgset REAL_LO $((_hi-50))
        echo "  >> 是温度造成的（厂家温控）→ 已把冷却回差放宽到 5℃（原 $((_gap/10))℃），避免在阈值附近来回跳"
        FIXED=1
      else
        echo "  >> 是温度造成的（厂家温控）；回差已够宽（$((_gap/10))℃），可把「收紧温度」再调低 2℃ 或加强散热"
      fi
    else
      echo "  · 功率波动不大，暂不需要处理"
    fi
  fi
fi
echo
echo "③ 让改动生效（重启守护）"
K=0
for d in /proc/[0-9]*; do
  _p=${d#/proc/}
  _a=$( { [ -r "$d/cmdline" ] && head -c 4096 "$d/cmdline" | tr '\0' '\n'; } 2>/dev/null | grep -x "$MODDIR/service.sh" 2>/dev/null)
  [ -n "$_a" ] && { kill "$_p" 2>/dev/null; K=$((K+1)); }
done
rm -f "$PIDF"
# ★ 等旧守护真正退干净（最多 10 秒）再起新的，避免新旧互杀
W=0
while [ "$W" -lt 10 ]; do
  _alive=0
  for d in /proc/[0-9]*; do
    _p=${d#/proc/}
    _a=$( { [ -r "$d/cmdline" ] && head -c 4096 "$d/cmdline" | tr '\0' '\n'; } 2>/dev/null | grep -x "$MODDIR/service.sh" 2>/dev/null)
    [ -n "$_a" ] && _alive=1
  done
  [ "$_alive" = "0" ] && break
  sleep 1; W=$((W+1))
done
[ "$_alive" = "1" ] && echo "  · 旧守护仍在退出中（${W}s），强制重启"
if command -v setsid >/dev/null 2>&1; then setsid sh "$MODDIR/service.sh" >/dev/null 2>&1 &
else nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 & fi
sleep 4
NP=$(cat "$PIDF" 2>/dev/null)
if [ -n "$NP" ] && [ -d "/proc/$NP" ]; then
  echo "  · 旧守护已停 ${K} 个，新守护已起 (pid=$NP)，通道=${_s}"
else
  echo "  · 守护重启失败，请看 $MASKLOG"
fi
echo
echo "===== 修复结束（改动 ${FIXED} 处）====="
