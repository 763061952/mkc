#!/system/bin/sh
# ===== 外屏光感（自动亮度）自愈 v2 =====
# 场景：软重启后，展开屏三个光感正常，但合盖到外屏后外屏光感不参与自动亮度。
# 说明：传感器硬件本身有值（工厂测试 Second Screen BackDAC 有读数），坏的是
#       「外屏 ↔ 光感」的监听绑定。所以要做四步，逐步加强：
#   1) 重启传感器 HAL（vendor.sensors-hal-multihal / citsensorservice）
#   2) 自动亮度开关重挂一次（关→开），强制框架重新注册光感监听
#   3) 亮度回写一次，触发一次亮度重算
#   4) 仍不行：亮/灭屏一次（重建 显示↔光感 绑定）
# 结果和诊断写 /data/local/tmp/temp_chg_alsfix.txt（App 能直接看，也能发给作者）
LOG=/data/local/tmp/temp_mask_all.log
OUT=/data/local/tmp/temp_chg_alsfix.txt
log(){ echo "$(date '+%m-%d %H:%M:%S') [alsfix] $*" >> "$LOG"; }
state(){ getprop "init.svc.$1" 2>/dev/null; }
say(){ echo "$*" >> "$OUT"; }

: > "$OUT" 2>/dev/null
say "时间=$(date '+%Y-%m-%d %H:%M:%S')"
say "HAL_before=$(state vendor.sensors-hal-multihal) CIT_before=$(state citsensorservice)"
say "自动亮度=$(settings get system screen_brightness_mode 2>/dev/null) 亮度=$(settings get system screen_brightness 2>/dev/null)"

log "开始修复光感 v2"
# 1) HAL
setprop ctl.restart vendor.sensors-hal-multihal 2>/dev/null
sleep 2
setprop ctl.restart citsensorservice 2>/dev/null
sleep 2
say "HAL_after=$(state vendor.sensors-hal-multihal) CIT_after=$(state citsensorservice)"

# 2) 自动亮度重挂
_bm=$(settings get system screen_brightness_mode 2>/dev/null)
_bv=$(settings get system screen_brightness 2>/dev/null)
if [ "$_bm" = "1" ]; then
  say "重挂自动亮度：关 → 开"
  settings put system screen_brightness_mode 0 2>/dev/null
  sleep 1
  settings put system screen_brightness "$_bv" 2>/dev/null
  sleep 1
  settings put system screen_brightness_mode 1 2>/dev/null
  sleep 1
else
  say "自动亮度本来是关的，跳过重挂（不擅自打开）"
fi

# 3) 亮度回写，触发重算
settings put system screen_brightness "$_bv" 2>/dev/null
sleep 1

# 4) 不再闪屏/锁屏（会打断使用），只做服务与自动亮度重挂

# 诊断：把光感相关连接打出来（客户发回来就能判断是绑定还是硬件）
say "---- sensorservice 光感连接 ----"
dumpsys sensorservice 2>/dev/null | grep -iE "light|als|ambient" | head -20 >> "$OUT" 2>/dev/null
say "---- 结束 ----"
chmod 666 "$OUT" 2>/dev/null
log "光感修复 v2 结束（报告 $OUT）"
