#!/system/bin/sh
# 精简自检：只给"能不能用"的结论，中文短句，供 App 内直接显示。作者：酷安@happier2
M=${0%/*}
O=/data/local/tmp/temp_chg_check.txt
B=/sys/class/power_supply/battery
U=/sys/class/power_supply/usb
S=/data/local/tmp/temp_chg_status.txt
G=/data/local/tmp/temp_chg_gearscan.txt
F=/sys/devices/platform/strategy-fg/fake_temp
v(){ grep "^$1=" "$S" 2>/dev/null | cut -d= -f2; }
{
echo "$(getprop ro.product.brand) $(getprop ro.product.model)（$(getprop ro.product.marketname)）"
echo "$(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name) · Android $(getprop ro.build.version.release) · SoC $(getprop ro.soc.model) · 模块 $(grep '^version=' "$M/module.prop" 2>/dev/null | cut -d= -f2)"
echo "—————————————"
# 1 root
[ "$(id -u 2>/dev/null)" = "0" ] && echo "[✓] root 可用" || echo "[✗] 没有 root（自检不完整）"
# 2 守护
P=$(cat /data/local/tmp/temp_chg_all.pid 2>/dev/null)
TS=$(date +%s); ST=$(v ts); AGE=""
[ -n "$ST" ] && AGE="$((TS - ST))s 前更新"
if [ -n "$P" ] && [ -d "/proc/$P" ]; then echo "[✓] 守护运行中（pid $P，状态 $AGE）"; else echo "[✗] 守护没运行：重启，或在管理器点一次「执行」"; fi
# 3 热区伪装
n=0; e=0
for z in /sys/class/thermal/thermal_zone*; do
  [ -w "$z/emul_temp" ] || continue
  n=$((n+1)); a=$(cat "$z/emul_temp" 2>/dev/null); b=$(cat "$z/temp" 2>/dev/null)
  if [ -n "$a" ] && [ "$a" != "0" ] && [ "$a" = "$b" ]; then e=$((e+1))
  elif [ -n "$b" ] && [ "$b" -ge 33000 ] 2>/dev/null && [ "$b" -le 41000 ] 2>/dev/null; then e=$((e+1)); fi
done
[ "$n" -gt 0 ] && echo "[✓] 温度伪装：$n 个热区可写，抽查 $e 个显示为伪装值" || echo "[✗] 温度伪装：没有可写的热区"
# 4 电池温度
if [ -w "$F" ]; then
  fv=$(cat "$F" 2>/dev/null); bv=$(cat "$B/temp" 2>/dev/null)
  if [ "$fv" = "-999" ]; then echo "[i] 电池温度：真实模式（$bv）"
  else
    d=$(( ${fv:-0} - ${bv:-0} )); d=${d#-}
    if [ "$d" -le 5 ]; then echo "[✓] 电池温度伪装生效（写 $fv ≈ 读 $bv）"
    else echo "[!] 电池温度写了 $fv，实际读到 $bv（放电时驱动常忽略，充电再看）"; fi
  fi
else echo "[!] 本机没有 fake_temp 通道（只靠热区伪装）"; fi
# 5 厂商温度通道
mw=0; for m in /sys/class/thermal/thermal_message/*; do [ -w "$m" ] && mw=$((mw+1)); done
echo "[i] 厂商 thermal_message：$mw 个可写"
# 6 放开通道
rm_w=0; lv_w=0
for base in /sys/class/xm_power/charger/charger_thermal /sys/class/xm_power/charger; do
  [ -w "$base/wired_thermal_remove" ] && rm_w=1
  [ -w "$base/wired_ctrl_limit" ] && lv_w=1
done
if [ "$rm_w" = "1" ] || [ "$lv_w" = "1" ]; then
  echo "[✓] 放开通道：档位（remove=$([ "$rm_w" = 1 ] && echo 可写 || echo 无)，当前档=$(cat /sys/class/xm_power/charger/charger_thermal/wired_ctrl_limit 2>/dev/null)）"
else echo "[!] 没有小米档位通道，将尝试通用电流节点"; fi
gen=""
for f in $B/constant_charge_current_max $U/current_max $B/input_current_limit $B/charge_control_limit; do
  [ -e "$f" ] || continue
  o=$(cat "$f" 2>/dev/null)
  if [ ! -w "$f" ]; then gen="$gen $(basename "$f"):只读"
  elif { echo "$o" > "$f"; } 2>/dev/null; then gen="$gen $(basename "$f"):可写"
  else gen="$gen $(basename "$f"):写入被拒"; fi
done
[ -n "$gen" ] && echo "[i] 通用电流节点：$gen"
# 7 档位识别结果
if [ -s "$G" ]; then
  mn=$(grep '^min=' "$G" | cut -d= -f2); mx=$(grep '^max=' "$G" | cut -d= -f2); er=$(grep '^error=' "$G" | cut -d= -f2)
  [ -n "$er" ] && echo "[!] 档位识别：$er" || echo "[i] 档位识别：本机接受 $mn ~ $mx"
fi
echo "—————————————"
# 8 功率与充电
st=$(v status)
echo "充电状态：${st:-未知} ｜ 电芯模式：$(v dual)（$(v cells)）"
if [ "$st" = "Charging" ] || [ "$st" = "Full" ]; then
  echo "功率：电池侧 $(v bat_w) W ｜ 输入(内核) $(v in_w) W ｜ 估算总输入 $(v in_est) W"
  ss=$(v sess_sec); sw=$(v sess_wh); sm=$(v sess_maxw)
  [ -n "$ss" ] && [ "$ss" != "0" ] && echo "本次充电：$((ss / 60)) 分 $((ss % 60)) 秒 ｜ 已充入 ${sw} Wh ｜ 峰值 ${sm} W"
else
  ls=$(v last_sec); lw=$(v last_wh)
  [ -n "$ls" ] && [ "$ls" != "0" ] && echo "未在充电 ｜ 上次充电 $((ls / 60)) 分 ｜ 充入 ${lw} Wh" || echo "未在充电"
fi
echo "开关：温度伪装 $(v mask) ｜ 亮屏快充 $(v fast) ｜ 看门狗 $(v guard_en) ｜ 档位 $(v gear)/$(v stock_gear)"
echo "—————————————"
ok=$(grep -c '^\[✓\]' "$O" 2>/dev/null || echo 0)
echo "结论：$([ "$n" -gt 0 ] && echo 温度伪装可用 || echo 温度伪装不可用) ｜ $([ "$rm_w$lv_w" != "00" ] && echo 快充放开可用 || echo 快充放开不可用)"
} > "$O" 2>&1
chmod 666 "$O" 2>/dev/null
