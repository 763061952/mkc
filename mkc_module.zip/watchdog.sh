#!/system/bin/sh
# 守护看门狗（v3.2.3）
# 只做一件事：守护不在就拉起。绝不杀任何进程。
# 判断方式：读 PID 文件 + kill -0（一次系统调用），再用 cmdline 精确确认（防 PID 复用）。
# 历史坑：旧版遍历 /proc/* 用 tr+grep 找守护 → 既重又慢，还会把模块自己的后台子 shell
#         （cmdline 同样是 service.sh）误判成"第 2 个守护"，进而把真父守护杀掉。
MODDIR=${0%/*}
PIDF=/data/local/tmp/temp_chg_all.pid
LOG=/data/local/tmp/temp_mask_all_watchdog.log
WLOCK=/data/local/tmp/temp_chg_watchdog.pid
MINE=$$
# ★ 单实例：已经在跑就直接退出（否则每重启一次就多一个看门狗）
if [ -f "$WLOCK" ]; then
  _wp=$(cat "$WLOCK" 2>/dev/null)
  case "${_wp:-x}" in ''|*[!0-9]*) _wp=0 ;; esac
  if [ "$_wp" != "$MINE" ] && [ "$_wp" -gt 0 ] 2>/dev/null && kill -0 "$_wp" 2>/dev/null; then
    exit 0
  fi
fi
echo "$MINE" > "$WLOCK" 2>/dev/null; chmod 666 "$WLOCK" 2>/dev/null
while true; do
  sleep 10
  P=$(cat "$PIDF" 2>/dev/null)
  alive=0
  if [ -n "$P" ] && [ "$P" != "$MINE" ] && kill -0 "$P" 2>/dev/null; then
    if [ -r "/proc/$P/cmdline" ] && tr '\0' '\n' < "/proc/$P/cmdline" 2>/dev/null | grep -qx "$MODDIR/service.sh"; then
      alive=1
    fi
  fi
  if [ "$alive" -eq 0 ]; then
    echo "$(date '+%m-%d %H:%M:%S') 看门狗：守护不在（PID=${P:-无}）→ 拉起" >> "$LOG"
    nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
  fi
done
