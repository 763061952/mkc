#!/system/bin/sh
# 二合一 v2.0.0：把旧的分离式模块（亮屏快充 / 旧温度伪装）停掉，保证只有本模块一份守护
MODDIR=${0%/*}
for m in chg_thermal_42c; do
  [ -d "/data/adb/modules/$m" ] || continue
  touch "/data/adb/modules/$m/disable" 2>/dev/null
  [ -f "/data/adb/modules/$m/remove" ] || touch "/data/adb/modules/$m/remove" 2>/dev/null
done
exit 0
