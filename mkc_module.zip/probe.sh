#!/system/bin/sh
# 快充节点普查（root）——把本机所有跟充电/温控相关的文件、可写性、写读回结果写成日志，
# 用来判断"为什么某机型不生效"。作者：酷安@happier2
# 全程不做破坏性写入：只写"原值"验证写通道是否真的能落下（读回=原值即算通过）。
LOG=/data/local/tmp/temp_chg_probe.log
B=/sys/class/power_supply/battery
U=/sys/class/power_supply/usb
wtest(){   # $1=文件：写原值验证可写性 → 打印结论（不动真实配置）
  [ -e "$1" ] || { echo "      $1 = 不存在"; return; }
  o=$(cat "$1" 2>/dev/null | head -c 60 | tr '\n' ' ')
  [ -w "$1" ] || { echo "      $1 = 只读(mode) ($o)"; return; }
  if ! echo "$o" > "$1" 2>/dev/null; then
    echo "      $1 = ★写入被拒（mode 说可写，SELinux/驱动拒绝）原值[$o]"
    return
  fi
  r=$(cat "$1" 2>/dev/null | head -c 60 | tr '\n' ' ')
  if [ "$r" = "$o" ]; then echo "      $1 = 可写✓ 原值[$o]"
  else echo "      $1 = 可写但读回不一致 原值[$o] 读回[$r]"; fi
}
{
echo "########## 快充节点普查 $(date '+%Y-%m-%d %H:%M:%S') ##########"
echo "## 模块版本"; grep -E '^(version|versionCode)=' "$(dirname $0)/module.prop" 2>/dev/null | sed 's/^/   /'
echo "## 机型 / 系统"
for k in ro.product.brand ro.product.model ro.product.marketname ro.product.device ro.build.version.release ro.build.version.sdk ro.build.display.id ro.mi.os.version.name ro.miui.ui.version.name ro.soc.model ro.board.platform ro.product.cpu.abi; do
  v=$(getprop $k); [ -n "$v" ] && echo "   $k=$v"
done
echo "   kernel=$(uname -r 2>/dev/null)"
echo "## power_supply 全部节点 / 全部可用字段"
for d in /sys/class/power_supply/*/; do
  n=$(basename "$d")
  echo "  [$n] type=$(cat $d/type 2>/dev/null) online=$(cat $d/online 2>/dev/null) present=$(cat $d/present 2>/dev/null) status=$(cat $d/status 2>/dev/null)"
  for f in voltage_now current_now power_now voltage_max voltage_ocv current_max input_current_limit constant_charge_current constant_charge_current_max charge_control_limit charge_control_limit_max charge_term_current cycle_count health charge_full charge_full_design charge_counter capacity temp time_to_full_now time_to_empty_now technology model_name; do
    [ -f "$d/$f" ] || continue
    w="只读"; [ -w "$d/$f" ] && w="可写"
    echo "      $f($w)=$(cat $d/$f 2>/dev/null | head -c 40 | tr '\n' ' ')"
  done
done
echo "## 厂商私有快充/温控目录"
for p in /sys/class/xm_power /sys/class/oplus_chg /sys/class/charger /sys/class/qcom-battery /sys/class/power_supply/bms /sys/devices/platform/charger /sys/devices/platform/mtk_charger /sys/devices/platform/battery /sys/devices/platform/smart_charge /sys/devices/platform/bcl /sys/devices/platform/connector_antiburn /sys/devices/platform/strategy-fg /sys/devices/virtual/thermal/thermal_message; do
  [ -e "$p" ] || { echo "  $p 不存在"; continue; }
  echo "  $p:"
  find "$p" -maxdepth 3 -type f 2>/dev/null | head -30 | while IFS= read -r f; do
    w="只读"; [ -w "$f" ] && w="可写"
    echo "      [$w] $f = $(head -c 40 "$f" 2>/dev/null | tr '\n' ' ')"
  done
done
echo "## 已知"放开快充"候选节点：写原值验证写通道"
for f in /sys/class/xm_power/charger/charger_thermal/wired_thermal_remove \
         /sys/class/xm_power/charger/charger_thermal/wired_ctrl_limit \
         $B/constant_charge_current_max $B/hw_charge_current_max $B/charge_control_limit \
         $B/input_current_limit $B/current_max $U/current_max $U/input_current_limit \
         /sys/class/power_supply/bms/current_max /sys/class/power_supply/main/current_max \
         /sys/class/power_supply/charger/current_max /proc/mtk_battery_cmd/current_cmd \
         /proc/mtk_battery_cmd/en_power_path \
         $B/step_charging_enable $B/restricted_charging $B/charging_enabled $B/input_suspend; do
  wtest "$f"
done
echo "## 温度通道"
for z in /sys/class/thermal/thermal_zone*; do
  t=$(cat $z/type 2>/dev/null); e=$(cat $z/emul_temp 2>/dev/null); w="只读"; [ -w "$z/emul_temp" ] && w="可写"
  echo "  $(basename $z) type=$t emul_temp=$w($e) temp=$(cat $z/temp 2>/dev/null) policy=$(cat $z/policy 2>/dev/null) mode=$([ -w $z/mode ] && echo 可写 || echo 只读)"
done
for m in /sys/class/thermal/thermal_message/*; do
  [ -e "$m" ] || continue
  echo "  thermal_message/$(basename $m)=$(cat $m 2>/dev/null) $([ -w "$m" ] && echo 可写 || echo 只读)"
done
echo "## 当前运行态"
grep -E '^(strategy|power_w|in_w|bat_w|status|gear|stock_gear|dual|cells|mask|fast)=' /data/local/tmp/temp_chg_status.txt 2>/dev/null | sed 's/^/   /'
echo "########## 普查结束 ##########"
} > "$LOG.tmp" 2>&1
chmod 666 "$LOG.tmp" 2>/dev/null
mv -f "$LOG.tmp" "$LOG" 2>/dev/null
chmod 666 "$LOG" 2>/dev/null
echo "已写入 $LOG ($(wc -l < "$LOG" 2>/dev/null) 行)"
