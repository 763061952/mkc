#!/system/bin/sh
# ===== 独立看门狗：守护采样进程，确认它一直在写记录 =====
# 每 20 秒检查：① service.sh 进程在不在 ② 状态/记录文件是否 90 秒内有更新
# 任一不满足 → 杀掉残留并重启采样；全部记录写 /data/local/tmp/temp_chg_watchdog.log
MODDIR=$(cd "$(dirname "$0")" && pwd)
PIDF=/data/local/tmp/mkc_wd.pid
LOG=/data/local/tmp/temp_chg_watchdog.log
ST=/data/local/tmp/temp_chg_status.txt

# 单实例
if [ -s "$PIDF" ]; then
  _old=$(cat "$PIDF" 2>/dev/null)
  case "$_old" in ''|*[!0-9]*) : ;; *) kill -0 "$_old" 2>/dev/null && exit 0 ;; esac
fi
echo $$ > "$PIDF"; chmod 666 "$PIDF" 2>/dev/null

logw(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; [ -f "$LOG" ] && chmod 666 "$LOG" 2>/dev/null; }
restarts=0

while :; do
  sleep 20
  _now=$(date +%s)
  _pid=$(cat /data/local/tmp/mkc_svc.pid 2>/dev/null)
  case "$_pid" in ''|*[!0-9]*) _pid=$(pgrep -f "temp_mask""_all/service.sh" | head -1) ;; esac
  [ -n "$_pid" ] && ! kill -0 "$_pid" 2>/dev/null && _pid=""
  _mtime=0
  [ -f "$ST" ] && _mtime=$(stat -c %Y "$ST" 2>/dev/null || echo 0)
  case "$_mtime" in ''|*[!0-9]*) _mtime=0 ;; esac
  _age=$(( _now - _mtime ))

  if [ -z "$_pid" ] || [ "$_age" -gt 90 ]; then
    logw "采样进程不存在 → 重启"
    [ -n "$_pid" ] && kill -9 "$_pid" 2>/dev/null
    [ -z "$_pid" ] && logw "采样进程不存在 → 重启" || logw "状态 ${_age}s 未更新（pid=$_pid）→ 杀掉重启"
  else
    continue
  fi

  restarts=$((restarts+1))
  M=/data/adb/modules/temp_mask_all
  [ -f "$M/disable" ] && { logw "模块被禁用，看门狗退出"; break; }
  [ -f "$M/remove" ] && { logw "模块待卸载，看门狗退出"; break; }
  setsid sh "$M/service.sh" </dev/null >/dev/null 2>&1 &
  logw "已重启采样（第 $restarts 次）"
done
