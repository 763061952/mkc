#!/system/bin/sh
# ===== 记录一切的脚本（纯函数，可单测）=====
# 采样只是"当时状态"；这里负责把每秒的状态**累加并落盘**，关机/重启/模块重载都不丢。
#
# 持久化状态文件格式（一行）：
#   day total_sec screen_sec dis_wh chg_wh last_ts
# 记录文件（CSV，按天滚动，保留 7 天）：
#   ts,status,cap,cap_real,power_w,temp_c,screen_on,screen_sec_total,dis_wh_total,chg_wh_total
REC_STATE=/data/local/tmp/mkc_rec_state
REC_DIR=/data/local/tmp
REC_KEEP_DAYS=7

rec_today() { date +%Y-%m-%d 2>/dev/null || echo 1970-01-01; }

# rec_tick <ts> <status> <cap> <cap_real> <power_w> <temp_c> <backlight> [state_file] [csv_file]
rec_tick() {
  _ts=$1; _st=$2; _cap=$3; _cr=$4; _pw=$5; _tp=$6; _bl=$7
  _sf=${8:-$REC_STATE}
  _day=$(rec_today)
  _csv=${9:-$REC_DIR/mkc_rec_$_day.csv}
  # 读旧状态
  _d=; _tot=; _scr=; _dis=; _chg=; _lt=
  if [ -s "$_sf" ]; then read -r _d _tot _scr _dis _chg _lt < "$_sf" 2>/dev/null; fi
  case "$_ts" in ''|*[!0-9]*) _ts=0 ;; esac
  case "$_tot" in ''|*[!0-9.]*) _tot=0 ;; esac
  case "$_scr" in ''|*[!0-9.]*) _scr=0 ;; esac
  case "$_dis" in ''|*[!0-9.]*) _dis=0 ;; esac
  case "$_chg" in ''|*[!0-9.]*) _chg=0 ;; esac
  case "$_lt" in ''|*[!0-9]*) _lt=0 ;; esac
  # 换天：总时长/亮屏/Wh 每天重置（历史留在 CSV 里）
  if [ "$_d" != "$_day" ]; then _tot=0; _scr=0; _dis=0; _chg=0; _lt=0; fi
  # 真实间隔（重启/换天时按 0 处理，避免一次补进几小时）
  if [ "$_lt" -gt 0 ] && [ "$_ts" -gt "$_lt" ]; then
    _dt=$(( _ts - _lt ))
  else
    _dt=0
  fi
  [ "$_dt" -gt 120 ] && _dt=0
  _pw=${_pw#-}
  _tot=$(awk -v a="$_tot" -v t="$_dt" 'BEGIN{printf "%.0f", a + t}')
  case "$_bl" in ''|*[!0-9]*) _bl=0 ;; esac
  if [ "$_bl" -gt 0 ]; then
    _scr=$(awk -v a="$_scr" -v t="$_dt" 'BEGIN{printf "%.0f", a + t}')
  fi
  case "$_st" in
    Charging|Full) _chg=$(awk -v a="$_chg" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}') ;;
    *)             _dis=$(awk -v a="$_dis" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}') ;;
  esac
  printf '%s %s %s %s %s %s\n' "$_day" "$_tot" "$_scr" "$_dis" "$_chg" "$_ts" > "$_sf.tmp" 2>/dev/null \
    && mv -f "$_sf.tmp" "$_sf" 2>/dev/null
  chmod 666 "$_sf" 2>/dev/null
  # 落一行 CSV（头一次写表头）
  if [ ! -s "$_csv" ]; then
    echo "ts,status,cap,cap_real,power_w,temp_c,screen_on,screen_sec,dis_wh,chg_wh,volt_v,curr_a,cpu_temp,backlight,freq_mhz" > "$_csv" 2>/dev/null
  fi
  if [ "$_bl" -gt 0 ]; then _son=1; else _son=0; fi
  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
    "$_ts" "$_st" "$_cap" "$_cr" "$_pw" "$_tp" "$_son" "$_scr" "$_dis" "$_chg" \
    "${REC_V:-0}" "${REC_A:-0}" "${REC_CT:-0}" "${_bl:-0}" "${REC_F:-0}" >> "$_csv" 2>/dev/null
  chmod 666 "$_csv" 2>/dev/null
  # 每天一行汇总（保存 7 天，App「每日」页直接读）
  _sum=$REC_DIR/mkc_rec_summary.csv
  [ -s "$_sum" ] || echo "date,total_sec,screen_sec,dis_wh,chg_wh" > "$_sum" 2>/dev/null
  _line="$_day,$_tot,$_scr,$_dis,$_chg"
  if grep -q "^$_day," "$_sum" 2>/dev/null; then
    sed -i "s|^$_day,.*|$_line|" "$_sum" 2>/dev/null
  else
    echo "$_line" >> "$_sum" 2>/dev/null
  fi
  # 汇总也只留 7 天
  _n=$(wc -l < "$_sum" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
  if [ "$_n" -gt 8 ]; then head -1 "$_sum" > "$_sum.t"; tail -7 "$_sum" >> "$_sum.t"; mv -f "$_sum.t" "$_sum"; fi
  chmod 666 "$_sum" 2>/dev/null

  # 只留最近 N 天
  _old=$(find "$REC_DIR" -maxdepth 1 -name "mkc_rec_*.csv" -mtime +$REC_KEEP_DAYS 2>/dev/null)
  [ -n "$_old" ] && echo "$_old" | xargs rm -f 2>/dev/null
}

# rec_summary <state_file>  → 输出 "总秒 亮屏秒 放电Wh 充电Wh"（给 App/状态文件用）
rec_summary() {
  _sf=${1:-$REC_STATE}
  if [ -s "$_sf" ]; then read -r _d _tot _scr _dis _chg _lt < "$_sf" 2>/dev/null; fi
  case "$_tot" in ''|*[!0-9.]*) _tot=0 ;; esac
  case "$_scr" in ''|*[!0-9.]*) _scr=0 ;; esac
  case "$_dis" in ''|*[!0-9.]*) _dis=0 ;; esac
  case "$_chg" in ''|*[!0-9.]*) _chg=0 ;; esac
  echo "$_tot $_scr $_dis $_chg"
}
