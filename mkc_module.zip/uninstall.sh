#!/system/bin/sh
# 米快充 模块卸载：把官方状态完整还原，零残留
# 顺序：停守护 → 还原温度节点 → 还原充电节点 → 清标记/文件
M=/data/adb/modules/temp_mask_all
PIDF=/data/local/tmp/temp_chg_all.pid
N=/sys/class/xm_power/charger/charger_thermal
SNAP=/data/local/tmp/chg_stock_gear
ORIG=/data/local/tmp/temp_chg_mask_orig

log(){ echo "  $*"; }

# 1) 停守护、看门狗、CPU 采样子进程
PAT="temp_mask""_all"
for p in $(pgrep -f "$PAT/service.sh") $(pgrep -f "$PAT/watchdog.sh"); do
  kill -9 "$p" 2>/dev/null && log "已停止进程 $p"
done
rm -f "$PIDF" /data/local/tmp/temp_chg_watchdog.pid 2>/dev/null

# 2) 温度节点：优先按快照逐字还原，其余热区 emul_temp 写 -999（关闭模拟）
_n=0
if [ -s "$ORIG" ]; then
  while IFS='|' read -r _p _v; do
    [ -n "$_p" ] || continue
    case "$_p" in *trip_point_*) continue ;; esac      # 绝不写 trip
    [ -w "$_p" ] || continue
    printf '%s\n' "$_v" > "$_p" 2>/dev/null && _n=$((_n+1))
  done < "$ORIG"
  rm -f "$ORIG"
fi
for z in /sys/class/thermal/thermal_zone*; do
  [ -w "$z/emul_temp" ] && echo -999 > "$z/emul_temp" 2>/dev/null
done
[ -w /sys/devices/platform/strategy-fg/fake_temp ] && echo -999 > /sys/devices/platform/strategy-fg/fake_temp 2>/dev/null
log "温度伪装已撤（按快照还原 $_n 个节点，其余热区关闭模拟）"

# 3) 充电节点：交回官方
_s=$(cat "$SNAP" 2>/dev/null | grep -o 'gear=[0-9]*' | cut -d= -f2)
case "$_s" in ''|*[!0-9]*|0) _s=12 ;; esac
[ -e "$N/wired_thermal_remove" ] && echo 0 > "$N/wired_thermal_remove" 2>/dev/null
[ -e "$N/wired_ctrl_limit" ] && echo "$_s" > "$N/wired_ctrl_limit" 2>/dev/null
_c=$(cat "$SNAP" 2>/dev/null | grep -o 'cur=[0-9]*' | cut -d= -f2)
case "$_c" in ''|*[!0-9]*|0) ;; *) echo "$_c" > /sys/class/power_supply/battery/constant_charge_current_max 2>/dev/null ;; esac
_u=$(cat "$SNAP" 2>/dev/null | grep -o 'usb=[0-9]*' | cut -d= -f2)
case "$_u" in ''|*[!0-9]*|0) ;; *) echo "$_u" > /sys/class/power_supply/usb/current_max 2>/dev/null ;; esac
log "充电已交回官方（remove=0，档位=$_s）"

# 3.5) 还原电量伪装（核心：不还原会一直显示 10%）
_fs=/sys/devices/platform/strategy-fg/fake_soc
if [ -w "$_fs" ]; then
  _o=$(cat /data/local/tmp/temp_chg_soc_orig 2>/dev/null)
  case "$_o" in ''|*[!0-9-]*) _o=-1 ;; esac
  echo "$_o" > "$_fs" 2>/dev/null
  echo "  电量伪装已还原 fake_soc=$_o（该功能已删除，仅做一次兜底还原）"
fi

# 4) 清标记与临时文件（App 侧状态也一起清，避免"卸载了还显示已开"）
rm -f "$M/mask_off" "$M/fast_off" "$M/disable" "$M/remove" 2>/dev/null
rm -f /data/local/tmp/temp_chg_mask_orig /data/local/tmp/temp_chg_mask_tgt \
      /data/local/tmp/temp_chg_mask_tgt.ts /data/local/tmp/temp_chg_maskbusy \
      /data/local/tmp/temp_chg_unplug_state.txt /data/local/tmp/temp_chg_unplug.txt \
      /data/local/tmp/temp_chg_uidcpu_prev /data/local/tmp/temp_chg_uidcpu_acc \
      /data/local/tmp/temp_chg_bootcnt /data/local/tmp/temp_chg_cpu.txt \
      /data/local/tmp/temp_chg_status.txt /data/local/tmp/temp_chg_maskwant \
      /data/local/tmp/temp_chg_fastwant /data/local/tmp/temp_chg_socfake /data/local/tmp/temp_chg_soc_orig 2>/dev/null
rm -f /data/local/tmp/temp_mask_all.log /data/local/tmp/chg_fast.log 2>/dev/null
log "标记与临时文件已清理"
echo "米快充 模块已完全卸载：温度伪装撤销、充电交回官方、进程与临时文件清零"
