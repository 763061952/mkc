#!/system/bin/sh
# ===== 云控修复老版本 App 的试用倒计时（2.8.31 及更早）=====
# 老版本每次启动都会把试用起点改成「现在-1天」，导致永远剩 24 小时。
# 这里由模块把三处起点统一钉在「现在」（>= 老代码的 LEGACY 阈值），
# 老版本一看起点是新的就不再改写，倒计时就能正常往下走。
PIN=/data/local/tmp/mkc_trial_pin_done
trial_pin(){
  [ -f "$PIN" ] && return 0
  _v=$(dumpsys package com.dsh.qschg 2>/dev/null | grep -m1 versionName | cut -d= -f2 | tr -d ' ')
  # 2.8.32 及以上已经自带修复，不用动
  case "$_v" in
    2.8.3[2-9]|2.8.[4-9]*|2.9.*|3.*) echo "app $_v 已修复，跳过" > /data/local/tmp/mkc_trial_fix.log; return 0 ;;
  esac
  _now=$(date +%s)
  for f in /data/data/com.dsh.qschg/files/trial \
           /data/local/tmp/temp_chg_trial \
           /storage/emulated/0/Android/data/com.dsh.qschg/files/trial \
           /sdcard/Android/data/com.dsh.qschg/files/trial; do
    [ -d "$(dirname "$f")" ] || continue
    echo "$_now" > "$f" 2>/dev/null && chmod 666 "$f" 2>/dev/null
  done
  echo "$(date '+%m-%d %H:%M') 已钉住试用起点 $_now（App ${_v:-未知}）" > /data/local/tmp/mkc_trial_fix.log
  touch "$PIN" 2>/dev/null; chmod 666 "$PIN" 2>/dev/null
}
trial_pin
