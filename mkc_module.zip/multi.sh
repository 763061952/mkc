#!/system/bin/sh
# ===== 多源采样 · 交叉验证 · 兜底（纯函数，可单测）=====
# 每个量都有 2~3 个独立来源；先取多数/中位数，取不到再用下一级来源，最后才用缓存。
# 输出一律"值 来源"，来源写进 status/CSV，方便对账与反馈。

# 1) 屏幕状态：wakeup(1=Awake) / bl_power(0=亮) / brightness(>0=亮)
#    scr_vote <wake> <bl_power> <bright> → "on wake" / "off wake" ...
scr_vote(){
  # 优先级：wakeup（系统级最准，AOD 息屏也能判对）→ bl_power → 亮度 → 缓存
  _w=$1; _bp=$2; _br=$3
  case "$_w" in
    1) echo "on wake"; return ;;
    0) echo "off wake"; return ;;
  esac
  case "$_bp" in
    0) echo "on blpower"; return ;;
    1) echo "off blpower"; return ;;
  esac
  case "$_br" in
    ''|*[!0-9]*) echo "on cache" ;;
    *) [ "$_br" -gt 0 ] && echo "on bright" || echo "off bright" ;;
  esac
}

# 2) 功耗：电池电流×电压 / 多电池求和 / power_now
#    pow_pick <W1> <W2> <W3> → "W src"（取中位数，避免单点异常）
pow_pick(){
  _a=$1; _b=$2; _c=$3
  case "$_a" in ''|*[!0-9.-]*) _a="" ;; esac
  case "$_b" in ''|*[!0-9.-]*) _b="" ;; esac
  case "$_c" in ''|*[!0-9.-]*) _c="" ;; esac
  _n=0; _x=""
  [ -n "$_a" ] && _x="$_x $_a"; [ -n "$_a" ] && _n=$((_n+1))
  [ -n "$_b" ] && _x="$_x $_b"; [ -n "$_b" ] && _n=$((_n+1))
  [ -n "$_c" ] && _x="$_x $_c"; [ -n "$_c" ] && _n=$((_n+1))
  [ "$_n" -eq 0 ] && { echo "0 none"; return; }
  echo "$_x" | awk -v n="$_n" '{
    for(i=1;i<=NF;i++) v[i]=$i+0
    if(n==1){ printf "%.2f %s\n", v[1], "one"; exit }
    for(i=1;i<n;i++)for(j=i+1;j<=n;j++)if(v[j]<v[i]){t=v[i];v[i]=v[j];v[j]=t}
    if(n==2) printf "%.2f %s\n", (v[1]+v[2])/2, "avg2"
    else printf "%.2f %s\n", v[2], "median3"
  }'
}

# 3) 电量：容量节点 vs 库仑计(charge_counter/charge_full) → 取一致值；不一致时偏保守（取小的）
#    soc_pick <cap> <ctr> <full> <last> → "soc src"
soc_pick(){
  _cap=$1; _ctr=$2; _full=$3; _last=$4
  _c=""
  case "$_cap" in ''|*[!0-9]*) : ;; *) _c=$_cap ;; esac
  _k=""
  if [ -n "$_ctr" ] && [ -n "$_full" ] && [ "$_full" -gt 0 ] 2>/dev/null; then
    _k=$(( _ctr * 100 / _full ))
  fi
  if [ -n "$_c" ] && [ -n "$_k" ]; then
    _d=$(( _c - _k )); [ "$_d" -lt 0 ] && _d=$(( -_d ))
    if [ "$_d" -le 3 ]; then echo "$_c agree"; else
      # 差太大：取较小值（更保守），并标注出处
      if [ "$_k" -lt "$_c" ]; then echo "$_k coulomb"; else echo "$_c capacity"; fi
    fi
  elif [ -n "$_c" ]; then echo "$_c capacity"
  elif [ -n "$_k" ]; then echo "$_k coulomb"
  else
    case "$_last" in ''|*[!0-9]*) echo "0 cache" ;; *) echo "$_last cache" ;; esac
  fi
}

# 4) 是否插着充电器（多源）：online 节点 / status / 功率符号；任一给出"插着"即插着
#    plug_vote <online_any> <status> <powerW> <last>
plug_vote(){
  _on=$1; _st=$2; _w=$3; _last=$4
  case "$_on" in 1) echo "1 online"; return ;; esac
  case "$_st" in Charging|Full) echo "1 status"; return ;; esac
  case "$_w" in '') : ;; *) _w=${_w#-}; awk -v w="$_w" 'BEGIN{exit !(w>0.3)}' && { echo "0 power"; return; } ;; esac
  case "$_on" in 0) echo "0 online"; return ;; esac
  case "$_last" in 0|1) echo "$_last cache"; return ;; esac
  echo "0 cache"
}

# 5) 拔电会话步进（带来源标注）：sess_step <state> <now> <cap> <powerW> <screen_on 0/1>
#    state: start cap0 capnow wh screen standby lastts scr_src
sess_step(){
  _st=$1; _now=$2; _cap=$3; _pw=$4; _scr=$5; _src=$6
  _s=; _c0=; _cn=; _wh=; _sc=; _sb=; _lt=; _ss=
  [ -n "$_st" ] && read -r _s _c0 _cn _wh _sc _sb _lt _ss <<EOF
$_st
EOF
  case "$_now" in ''|*[!0-9]*) _now=0 ;; esac
  if [ -z "$_s" ]; then _s=$_now; _c0=$_cap; _cn=$_cap; _wh=0; _sc=0; _sb=0; _lt=0; _ss=${_src:-wake}; fi
  case "$_cap" in ''|*[!0-9]*) _cap=$_c0 ;; esac
  case "$_lt" in ''|*[!0-9]*) _lt=0 ;; esac
  _dt=0; [ "$_lt" -gt 0 ] && [ "$_now" -gt "$_lt" ] && _dt=$(( _now - _lt )); [ "$_dt" -gt 120 ] && _dt=0
  _pw=${_pw#-}
  if [ "$_scr" = "1" ]; then _sc=$(( ${_sc:-0} + _dt )); else _sb=$(( ${_sb:-0} + _dt )); fi
  _wh=$(awk -v a="${_wh:-0}" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}')
  [ "$_cap" -lt "$_cn" ] && _cn=$_cap
  echo "$_s $_c0 $_cn $_wh $_sc $_sb $_now ${_src:-$_ss}"
}
