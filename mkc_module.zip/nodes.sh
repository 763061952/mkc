#!/system/bin/sh
# ===== 多机型候选节点库（借鉴 ACC 的思路：候选表 + 链式写入取第一个真正写成功的）=====
# 铁律：探测阶段只读（[ -e ] / [ -w ]），绝不用「写一下试试」；
#       任何写入前先把「路径 原值」存 temp_chg_orig.txt，restore_all() 可逐条还原。
NODES_PROFILE=/data/local/tmp/temp_chg_profile.txt
NODES_ORIG=/data/local/tmp/temp_chg_orig.txt
node_candidates(){   # 输出 "能力|候选路径|放开/启用值"
  cat <<'L'
input_current_limit|/sys/class/power_supply/usb/input_current_limit|0
input_current_limit|/sys/class/power_supply/usb/current_max|0
input_current_limit|/sys/class/power_supply/main/input_current_limit|0
input_current_limit|/sys/class/power_supply/charger/input_current_limit|0
charge_current_limit|/sys/class/power_supply/battery/constant_charge_current_max|0
charge_current_limit|/sys/class/power_supply/battery/constant_charge_current|0
charge_current_limit|/sys/class/power_supply/battery/charge_control_limit|0
charge_current_limit|/sys/class/power_supply/battery/current_max|0
battery_charging_enabled|/sys/class/power_supply/battery/battery_charging_enabled|1
battery_charging_enabled|/sys/class/power_supply/battery/charging_enabled|1
vendor_charge_stop|/sys/class/xm_power/charger/charger_common/stop_handle_charge|0
vendor_thermal_remove|/sys/class/xm_power/charger/charger_thermal/wired_thermal_remove|1
battery_fake_temp|/sys/devices/platform/strategy-fg/fake_temp|-999
screen_fake|/sys/class/power_supply/battery/batt_screen_on|0
screen_fake|/sys/class/power_supply/battery/screen_on|0
screen_fake|/sys/class/power_supply/battery/batt_screen_off|1
screen_fake|/sys/class/power_supply/battery/display_state|0
screen_fake|/sys/class/power_supply/battery/screen_state|0
L
}
probe_nodes(){   # 只读探测 → 写 profile（能力|路径|值）
  : > "$NODES_PROFILE.t" 2>/dev/null
  node_candidates | while IFS='|' read -r cap p v; do
    [ -n "$cap" ] || continue
    [ -e "$p" ] || continue
    [ -w "$p" ] || continue
    echo "$cap|$p|$v" >> "$NODES_PROFILE.t" 2>/dev/null
  done
  mv -f "$NODES_PROFILE.t" "$NODES_PROFILE" 2>/dev/null
  chmod 666 "$NODES_PROFILE" 2>/dev/null
  mlog "能力探测：$(wc -l < "$NODES_PROFILE" 2>/dev/null) 项可写节点"
}
node_get(){ grep -m1 "^$1|" "$NODES_PROFILE" 2>/dev/null | cut -d'|' -f2; }
node_has(){ [ -n "$(node_get "$1")" ] && echo yes || echo no; }
try_write(){   # $1=能力 $2=值：按候选顺序链式写入，读回成功即停
  _ok=0
  for _p in $(grep "^$1|" "$NODES_PROFILE" 2>/dev/null | cut -d'|' -f2); do
    [ -w "$_p" ] || continue
    _o=$(cat "$_p" 2>/dev/null | tr -d ' \r\n')
    grep -q "^$_p " "$NODES_ORIG" 2>/dev/null || { echo "$_p $_o" >> "$NODES_ORIG" 2>/dev/null; chmod 666 "$NODES_ORIG" 2>/dev/null; }
    echo "$2" > "$_p" 2>/dev/null
    _r=$(cat "$_p" 2>/dev/null | tr -d ' \r\n')
    if [ "$_r" = "$2" ]; then mlog "写入成功 $_p=$2"; _ok=1; break; fi
  done
  [ "$_ok" = "1" ] || mlog "能力 $1 无可用节点（已跳过，未写入任何值）"
  [ "$_ok" = "1" ]
}
restore_all(){   # 逐条还原并校验
  [ -s "$NODES_ORIG" ] || return 0
  _bad=0
  while read -r _p _v; do
    [ -n "$_p" ] || continue
    [ -w "$_p" ] || continue
    echo "$_v" > "$_p" 2>/dev/null
    _r=$(cat "$_p" 2>/dev/null | tr -d ' \r\n')
    [ "$_r" = "$_v" ] || { mlog "还原异常 $_p 期望=$_v 实际=$_r"; _bad=$(( _bad + 1 )); }
  done < "$NODES_ORIG"
  [ "$_bad" = "0" ] && mlog "已按原值还原全部节点（校验通过）" || mlog "还原有 $_bad 项异常"
}
profile_text(){ sed 's/|/ → /g' "$NODES_PROFILE" 2>/dev/null; }
