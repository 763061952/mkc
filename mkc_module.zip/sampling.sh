#!/system/bin/sh
# ===== 采样核心（纯函数，可测）：拔线后用电累计 =====
# 设计：只处理"数字进、数字出"，不读设备、不写日志 → 单元测试可以直接喂参数。
# unplug_tick <state-file> <now> <cap> <power_w> <dt_sec> <backlight>
#   state 文件格式：start cap0 wh screen_min max_wh
#   输出：一行新 state，stdout；同时把给 App 看的摘要写 $MKC_UNPLUG_OUT（若设置）
unplug_tick() {
  # ★ v5.8.0 重写：dt 用"真实经过时间"（存在 state 里），Wh 用电池侧功率积分，掉电% 用真实容量差
  _st=$1; _now=$2; _cap=$3; _pw=$4; _dt=$5; _bl=$6
  _start=; _c0=; _wh=; _scr=; _max=; _ts=; _clast=
  if [ -s "$_st" ]; then
    read -r _start _c0 _wh _scr _max _ts _clast < "$_st" 2>/dev/null
  fi
  case "$_start" in ''|*[!0-9]*) _start=$_now ;; esac
  case "$_c0" in ''|*[!0-9]*) _c0=$_cap ;; esac
  case "$_wh" in ''|*[!0-9.]*) _wh=0 ;; esac
  case "$_scr" in ''|*[!0-9.]*) _scr=0 ;; esac
  case "$_max" in ''|*[!0-9.]*) _max=0 ;; esac
  case "$_ts" in ''|*[!0-9]*) _ts=0 ;; esac
  case "$_clast" in ''|*[!0-9]*) _clast=$_cap ;; esac
  # 真实间隔（秒）；首次/异常时退回调用方给的 dt，夹在 1..60
  if [ "$_ts" -gt 0 ] && [ "$_now" -gt "$_ts" ]; then _d=$(( _now - _ts )); else
    case "$_dt" in ''|*[!0-9]*) _d=1 ;; *) _d=$_dt ;; esac
  fi
  [ "$_d" -lt 1 ] && _d=1
  [ "$_d" -gt 60 ] && _d=60
  _pw=${_pw#-}
  _wh=$(awk -v a="$_wh" -v w="$_pw" -v t="$_d" 'BEGIN{printf "%.6f", a + w*t/3600}')
  _max=$(awk -v a="$_max" -v b="$_wh" 'BEGIN{printf "%.6f", (b>a)?b:a}')
  case "$_bl" in ''|*[!0-9]*) _bl=0 ;; esac
  if [ "$_bl" -gt 0 ]; then
    _scr=$(awk -v a="$_scr" -v t="$_d" 'BEGIN{printf "%.6f", a + t/60}')
  fi
  # 掉电只在下降时更新（充放电抖动/校准不算掉电）
  [ "$_cap" -lt "$_clast" ] && _clast=$_cap
  printf '%s %s %s %s %s %s %s\n' "$_start" "$_c0" "$_wh" "$_scr" "$_max" "$_now" "$_clast" > "$_st"
  if [ -n "${MKC_UNPLUG_OUT:-}" ]; then
    unplug_render "$_st" "$_c0" "$_clast" "$_now"
  fi
  cat "$_st"
}
unplug_render() {
  _st=$1; _c0=$2; _cn=$3; _now=$4
  read -r _start _x _wh _scr _max < "$_st" 2>/dev/null
  case "$_start" in ''|*[!0-9]*) _start=$_now ;; esac
  _min=$(awk -v a="$_start" -v b="$_now" 'BEGIN{printf "%d", (b-a)/60}')
  _whp=$(awk -v a="${_wh:-0}" 'BEGIN{printf "%.2f", a}')
  _scri=$(awk -v a="${_scr:-0}" 'BEGIN{printf "%d", a}')
  _drop=$(( _c0 - _cn )); [ "$_drop" -lt 0 ] && _drop=0
  _hrs=$(awk -v a="$_min" 'BEGIN{printf "%.4f", (a>0)? a/60 : 0}')
  _avg=$(awk -v w="${_wh:-0}" -v h="$_hrs" 'BEGIN{ if (h<=0) print "0.00"; else printf "%.2f", w/h }')
  {
    echo "开始=$(date -d @"$_start" +'%m-%d %H:%M' 2>/dev/null || echo "$_start")"
    echo "时长分钟=$_min"
    echo "耗电=${_whp}Wh"
    echo "亮屏分钟=$_scri"
    echo "电量=${_c0}%→${_cn}%"
    echo "掉电=${_drop}%"
    echo "平均功率=${_avg}W"
  } > "${MKC_UNPLUG_OUT}.tmp" 2>/dev/null && mv -f "${MKC_UNPLUG_OUT}.tmp" "$MKC_UNPLUG_OUT" 2>/dev/null
  chmod 666 "$MKC_UNPLUG_OUT" 2>/dev/null
}

# ===== 应用用电归因（纯函数，可测）=====
# uid_rank_emit <prev> <cur> <acc> <cap0> <capn> <out> <pkgs>
#   prev/cur: "uid ticks"；acc: 累计增量（ticks）；pkgs: /data/system/packages.list
#   输出：聚合后的排行文本（表头 + "pkg 秒"），由调用方决定写哪个文件
uid_rank_emit() {
  _prev=$1; _cur=$2; _acc=$3; _c0=$4; _cn=$5; _out=$6; _pk=$7
  _acc2=${8:-}; _out2=${9:-}      # 可选：再累加到"当天"累计并再渲染一份
  [ -s "$_acc" ] || : > "$_acc"
  if [ -s "$_prev" ]; then          # 首帧（没有基线）只立基线，不累加
    # d>360000 ticks（=1 小时 CPU，60 秒采样不可能）说明基线丢了/uid 新出现，丢弃防"开机以来"重新混入
    awk 'NR==FNR{p[$1]=$2;next}{u=$1;d=$2-(u in p?p[u]:0);if(d<0)d=0;if(d>360000)d=0;if(d>0)print u,d}' \
      "$_prev" "$_cur" >> "$_acc" 2>/dev/null
    [ -n "$_acc2" ] && awk 'NR==FNR{p[$1]=$2;next}{u=$1;d=$2-(u in p?p[u]:0);if(d<0)d=0;if(d>360000)d=0;if(d>0)print u,d}' \
      "$_prev" "$_cur" >> "$_acc2" 2>/dev/null
  fi
  cp -f "$_cur" "$_prev" 2>/dev/null
  case "$_c0" in ''|*[!0-9]*) _c0=$_cn ;; esac
  {
    echo "# 采样拔电后 CPU 时间排行（秒）  $(date '+%m-%d %H:%M')"
    echo "# 电量 ${_c0}%→${_cn}%"
    # 自己排序（设备上的 sort -n 对小数不可靠）：O(n^2) 选择排序，uid 数量两百级别够用
    awk '{a[$1]+=$2}END{n=0;for(x in a){s[n]=a[x]/100;u[n]=x;n++}
          for(i=0;i<n;i++)for(j=i+1;j<n;j++)if(s[j]>s[i]){t=s[i];s[i]=s[j];s[j]=t;tu=u[i];u[i]=u[j];u[j]=tu}
          for(i=0;i<n&&i<25;i++) printf "%s %.2f\n", u[i], s[i]}' "$_acc" 2>/dev/null \
      | while read -r _uid _sec; do
          _pkg=$(awk -v u="$_uid" '$2==u {print $1; exit}' "$_pk" 2>/dev/null)
          [ -n "$_pkg" ] || _pkg="uid$_uid"
          echo "$_pkg $_sec"
        done
  } > "$_out.tmp" 2>/dev/null
  mv -f "$_out.tmp" "$_out" 2>/dev/null
  if [ -n "$_out2" ] && [ -n "$_acc2" ]; then
    {
      echo "# 采样当天 CPU 时间排行（秒）  $(date '+%m-%d %H:%M')"
      echo "# 电量 ${_c0}%→${_cn}%"
      awk '{a[$1]+=$2}END{n=0;for(x in a){s[n]=a[x]/100;u[n]=x;n++}
            for(i=0;i<n;i++)for(j=i+1;j<n;j++)if(s[j]>s[i]){t=s[i];s[i]=s[j];s[j]=t;tu=u[i];u[i]=u[j];u[j]=tu}
            for(i=0;i<n&&i<25;i++) printf "%s %.2f\n", u[i], s[i]}' "$_acc2" 2>/dev/null \
        | while read -r _uid _sec; do
            _pkg=$(awk -v u="$_uid" '$2==u {print $1; exit}' "$_pk" 2>/dev/null)
            [ -n "$_pkg" ] || _pkg="uid$_uid"
            echo "$_pkg $_sec"
          done
    } > "$_out2.tmp" 2>/dev/null
    mv -f "$_out2.tmp" "$_out2" 2>/dev/null
    chmod 666 "$_out2" 2>/dev/null
  fi
}
