# 亮屏快充 + 全面温度伪装（二合一）v3.0.0  多机型自适应配置   作者：酷安@happier2
# 多数项【不用改】：充电通道、官方档位/电流、功率单位都由程序自动探测。
# 改完重启生效；也可用模块按钮 mask on|off / fast on|off 临时切换。
# ================= 开关 =================
MASK_ON=1                 # 1=温度伪装  0=只做快充（等同 mask_off）
FAST_ON=1                 # 1=亮屏快充  0=只做伪装（等同 fast_off）
# ================= 温度伪装 =================
POLL=2                    # 每轮间隔（秒）：厂商约 6s 就把 thermal_message 标回真值
S_MIN=34000               # 普通热区伪装区间（0.001C = 34.0C）
S_MAX=40000               # 上限 40.0C，刻意压在 joyose 锁帧阈值 44/46℃ 之下
JITTER=400
PA_MIN=25000              # power_allocator（shell-thermal）单独用更低区间
PA_MAX=31000
B_MIN=340                 # 电池伪装区间（0.1C）
B_MAX=390
BATT_MODE=steady          # 1.7.1 原样：稳态压住不松手（稳充）
BATT_FAKE=370             # 1.7.1 原样：37.0C 恒定
STEADY_RELEASE=0          # 固定 0：不偷读真值、不放行
CLAMP_RELEASE=0.15
SAFE_MAX=999999           # 不可达：永不触发放行
SAFE_PASS_SEC=180
SAFE_CHECK_SEC=60
BATT_CLAMP=410
W_CPU=1                   # 负载模型权重：CPU/GPU/充电
W_GPU=1
W_CHG=30
# ★ v0.9（合并 1.5.2）：这些通道也一起写，跟老版一致
EXTRA_NODES="/sys/devices/platform/connector_antiburn/connector_temp_1 /sys/devices/platform/connector_antiburn/connector_temp_2 /sys/devices/platform/bcl/battery_temp /sys/devices/platform/smart_charge/board_temp"
PSTEMPS_NODES=""          # 空 = 运行时自动取 /sys/class/power_supply/*/temp
# ================= 充电放开 =================
OPEN_CUR_MA=6000          # 电流类通道（高通/联发科/通用）写多少 mA 去"放开"；
                          # 驱动会夹到本机真实上限，程序以读回值为准，所以填大不吃亏。
USB_MAX_ON=1              # 1=允许写 usb/current_max（USB 输入限流）来抬电流；0=不碰
GEAR_MIN=3                # 小米/澎湃：最放开档。程序会读回校验，被驱动夹走会自动跟随。
GEAR_MAX=12               # 最保守档（功率闭环用）
STOCK_GEAR=0              # 0=自动（开机读当前档当官方档）；填数字则强制
POWER_LOOP=0              # 0=一直用放开档（要快充）｜1=按 TARGET_W 闭环调档
TARGET_W=70
TOL_HI=2
TOL_LO=30
STEP_EVERY=3
# ================= 充电自愈 =================
HEALTH_SEC=20             # 插着充电器但连续 N 秒不充电 → 交回官方档
PAUSE_SEC=180             # 交回官方后静默 N 秒让驱动重新协商
# ================= 过热自限（默认关）=================
HEAT_ON=0                 # 1=按"满功率累计时长"降档冷却（不读真温、不泄露真值）
HEAT_LIMIT=1500
HEAT_COOL=90
HEAT_GEAR=8
# ============ 真实温度看门狗（App 里也能调；App 写 /data/local/tmp/temp_chg_guard.cfg，2 秒内生效）============
REAL_HI=0                 # 0=关闭。到该真实温度(0.1C)就"切回真实温度 + 充电交回官方"，如 430=43.0℃
REAL_LO=400               # 降到该真实温度(0.1C)才恢复伪装与快充（回差防抖）
REAL_CHK=30               # 多久偷读一次真实温度(秒)：读的那一瞬间厂家可能抓到真值，介意就调大或关闭
