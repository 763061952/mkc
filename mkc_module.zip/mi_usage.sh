#!/system/bin/sh
# ===== 兜底：导入系统「屏幕使用时间」（usagestats 每应用 totalTimeUsed）=====
# 小米/Android 的「屏幕使用时间」就是 usagestats 里的 totalTimeUsed / totalTimeVisible。
# 输出：
#   /data/local/tmp/mkc_mi_app_<日期>.csv   pkg 秒
#   /data/local/tmp/mkc_mi_screen.txt       系统口径当天亮屏秒数（所有应用前台求和，封顶 86400）
MI_DIR=/data/local/tmp
mi_usage_import(){
  _day=${1:-$(date +%Y-%m-%d)}
  _dump=$MI_DIR/mkc_us_dump.txt
  dumpsys usagestats > "$_dump" 2>/dev/null
  [ -s "$_dump" ] || { echo 0; return 1; }
  awk -v day="$(echo $_day | tr '-' '/')" -v out="$MI_DIR/mkc_mi_app_$_day.csv" -v scr="$MI_DIR/mkc_mi_screen.txt" '
    /timeRange="/ {
      # 只认"当天"的分组（timeRange="2026/10/18 10:27–15:47"）
      if (match($0, /timeRange="[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]/)) {
        d=substr($0, RSTART+11, 10)
        active = (d == day)
        if (active) { delete acc; nb++ }
      }
      next
    }
    /totalTimeUsed="/ {
      if (!active) next
      pkg=""; tu=""
      for (i=1;i<=NF;i++) {
        if ($i ~ /^package=/) { pkg=$i; sub(/^package=/,"",pkg) }
        else if ($i ~ /^totalTimeUsed="/) { tu=$i; sub(/^totalTimeUsed="/,"",tu); sub(/"$/,"",tu) }
      }
      if (pkg=="" || tu=="") next
      split(tu,t,":"); v=t[1]*3600+t[2]*60+(t[3]+0)
      if (v<=0) next
      if (v>21600) v=21600
      acc[pkg]+=v
    }
    END{
      tot=0
      for (p in acc) { printf "%s %.0f\n", p, acc[p] >> out; tot+=acc[p] }
      if (tot>86400) tot=86400
      printf "%.0f\n", tot > scr
    }' "$_dump" 2>/dev/null
  chmod 666 "$MI_DIR/mkc_mi_app_$_day.csv" "$MI_DIR/mkc_mi_screen.txt" 2>/dev/null
  cat "$MI_DIR/mkc_mi_screen.txt" 2>/dev/null
  rm -f "$_dump" 2>/dev/null
}
