#!/system/bin/sh
# ===== 采样/记录核心 v7（纯函数，可单测）=====
# 目标：精准记录 亮屏时间 / 待机时间 / 拔电后待机 / 平均功耗 / 应用功耗
# 状态文件（一行，空格分隔）：
#   day total_sec screen_sec standby_sec dis_wh chg_wh last_ts
# 拔线会话文件（一行）：
#   start cap0 last_cap wh screen_sec standby_sec last_ts

S_DIR=${S_DIR:-/data/local/tmp}
S_DAYSTATE=$S_DIR/mkc_day_state
S_SESSSTATE=$S_DIR/mkc_sess_state
S_SUMMARY=$S_DIR/mkc_rec_summary.csv
S_BATT_WH=${S_BATT_WH:-22.6}     # 满电能量估计（Wh），用于把 Wh 换成掉电%

sampler_today(){ date +%Y-%m-%d 2>/dev/null || echo 1970-01-01; }

# —— 当天累计：精确区分亮屏/待机 ——
# sampler_day <ts> <status> <power_w> <backlight> [state]
sampler_day() {
  _ts=$1; _st=$2; _pw=$3; _bl=$4; _sf=${5:-$S_DAYSTATE}
  _pw=${_pw#-}
  _day=$(sampler_today)
  _d=; _tot=; _scr=; _sb=; _dis=; _chg=; _lt=
  [ -s "$_sf" ] && read -r _d _tot _scr _sb _dis _chg _lt < "$_sf" 2>/dev/null
  if [ -z "$_d" ] && [ -s "$_sf.bak" ]; then            # 主状态被删/损坏 → 用备份，绝不归零
    read -r _d _tot _scr _sb _dis _chg _lt < "$_sf.bak" 2>/dev/null
  fi
  case "$_ts" in ''|*[!0-9]*) _ts=0 ;; esac
  case "$_tot" in ''|*[!0-9]*) _tot=0 ;; esac
  case "$_scr" in ''|*[!0-9]*) _scr=0 ;; esac
  case "$_sb"  in ''|*[!0-9]*) _sb=0  ;; esac
  case "$_dis" in ''|*[!0-9.]*) _dis=0 ;; esac
  case "$_chg" in ''|*[!0-9.]*) _chg=0 ;; esac
  case "$_lt"  in ''|*[!0-9]*) _lt=0  ;; esac
  if [ "$_d" != "$_day" ]; then _tot=0; _scr=0; _sb=0; _dis=0; _chg=0; _lt=0; fi
  if [ "$_lt" -gt 0 ] && [ "$_ts" -gt "$_lt" ]; then _dt=$(( _ts - _lt )); else _dt=0; fi
  [ "$_dt" -gt 120 ] && _dt=0            # 重启/断档不补时长
  _pw=${_pw#-}
  case "$_bl" in ''|*[!0-9]*) _bl=0 ;; esac
  _tot=$(( _tot + _dt ))
  if [ "$_bl" -gt 0 ]; then _scr=$(( _scr + _dt )); else _sb=$(( _sb + _dt )); fi
  case "$_st" in
    Charging|Full) _chg=$(awk -v a="$_chg" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}') ;;
    *)             _dis=$(awk -v a="$_dis" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}') ;;
  esac
  printf '%s %s %s %s %s %s %s\n' "$_day" "$_tot" "$_scr" "$_sb" "$_dis" "$_chg" "$_ts" > "$_sf.t" && mv -f "$_sf.t" "$_sf"
  cp -f "$_sf" "$_sf.bak" 2>/dev/null
  chmod 666 "$_sf" "$_sf.bak" 2>/dev/null
  echo "$_tot $_scr $_sb $_dis $_chg"
}

# —— 拔线会话：亮屏/待机分开、耗电积分 ——
# sampler_session <ts> <cap> <power_w> <backlight> [state]
sampler_session() {
  _ts=$1; _cap=$2; _pw=$3; _bl=$4; _sf=${5:-$S_SESSSTATE}
  _s=; _c0=; _cl=; _wh=; _scr=; _sb=; _lt=
  [ -s "$_sf" ] && read -r _s _c0 _cl _wh _scr _sb _lt < "$_sf" 2>/dev/null
  case "$_ts" in ''|*[!0-9]*) _ts=0 ;; esac
  if [ -z "$_s" ] || [ "$_s" = "0" ]; then
    _s=$_ts; _c0=$_cap; _cl=$_cap; _wh=0; _scr=0; _sb=0; _lt=0
  fi
  case "$_cap" in ''|*[!0-9]*) _cap=$_c0 ;; esac
  case "$_wh" in ''|*[!0-9.]*) _wh=0 ;; esac
  case "$_scr" in ''|*[!0-9]*) _scr=0 ;; esac
  case "$_sb" in ''|*[!0-9]*) _sb=0 ;; esac
  case "$_lt" in ''|*[!0-9]*) _lt=0 ;; esac
  if [ "$_lt" -gt 0 ] && [ "$_ts" -gt "$_lt" ]; then _dt=$(( _ts - _lt )); else _dt=0; fi
  [ "$_dt" -gt 120 ] && _dt=0
  _pw=${_pw#-}
  case "$_bl" in ''|*[!0-9]*) _bl=0 ;; esac
  if [ "$_bl" -gt 0 ]; then _scr=$(( _scr + _dt )); else _sb=$(( _sb + _dt )); fi
  _wh=$(awk -v a="$_wh" -v w="$_pw" -v t="$_dt" 'BEGIN{printf "%.4f", a + w*t/3600}')
  [ "$_cap" -lt "$_cl" ] && _cl=$_cap        # 只记下降（校准/回弹不算掉电）
  printf '%s %s %s %s %s %s %s\n' "$_s" "$_c0" "$_cl" "$_wh" "$_scr" "$_sb" "$_ts" > "$_sf.t" && mv -f "$_sf.t" "$_sf"
  chmod 666 "$_sf" 2>/dev/null
  echo "$_s $_c0 $_cl $_wh $_scr $_sb"
}

# —— 应用能耗：CPU 时间占比 × 总 Wh → 每应用 Wh + 掉电占比 ——
# app_energy_emit <cpu_acc> <total_wh> <cap0> <capn> <out> <packages.list> <title>
app_energy_emit() {
  _acc=$1; _wh=$2; _c0=$3; _cn=$4; _out=$5; _pk=$6; _title=${7:-应用能耗}
  _drop=$(( _c0 - _cn )); [ "$_drop" -lt 0 ] && _drop=0
  {
    echo "# $_title  $(date '+%m-%d %H:%M')"
    echo "# 电量 ${_c0}%→${_cn}%"
    echo "# 掉电=$(awk -v w="$_wh" -v b="${S_BATT_WH:-22.6}" 'BEGIN{printf "%d", w*100/b}')%（按能量折算，一天可能超过 100%）"
    awk -v tot="$_wh" '
      {a[$1]+=$2}
      END{
        n=0; ssum=0
        for(x in a){ n++; ssum+=a[x] }
        if (ssum<=0) exit
        for(i=0;i<n;i++){}
        # 选择排序（设备 sort 对小数不可靠）
        k=0
        for(x in a){ v[k]=a[x]; u[k]=x; k++ }
        for(i=0;i<k;i++)for(j=i+1;j<k;j++)if(v[j]>v[i]){t=v[i];v[i]=v[j];v[j]=t;tu=u[i];u[i]=u[j];u[j]=tu}
        for(i=0;i<k && i<25;i++){
          wh = tot * v[i] / ssum
          printf "%s %.4f\n", u[i], wh
        }
      }' "$_acc" 2>/dev/null \
    | while read -r _uid _whv; do
        _pkg=$(awk -v u="$_uid" '$2==u {print $1; exit}' "$_pk" 2>/dev/null)
        [ -n "$_pkg" ] || _pkg="uid$_uid"
        echo "$_pkg $_whv"
      done
  } > "$_out.t" 2>/dev/null && mv -f "$_out.t" "$_out" 2>/dev/null
  chmod 666 "$_out" 2>/dev/null
}

# —— 7 天汇总表 ——
# summary_update <date> <total> <screen> <standby> <dis_wh> <chg_wh> [file]
summary_update() {
  _d=$1; _tot=$2; _scr=$3; _sb=$4; _dis=$5; _chg=$6; _f=${7:-$S_SUMMARY}
  [ -s "$_f" ] || echo "date,total_sec,screen_sec,standby_sec,dis_wh,chg_wh" > "$_f"
  if grep -q "^$_d," "$_f" 2>/dev/null; then
    _old=$(grep -m1 "^$_d," "$_f")
    _ot=$(echo "$_old" | cut -d, -f2); _os=$(echo "$_old" | cut -d, -f3); _ob=$(echo "$_old" | cut -d, -f4)
    _od=$(echo "$_old" | cut -d, -f5); _oc=$(echo "$_old" | cut -d, -f6)
    _tot=$(awk -v a="$_tot" -v b="${_ot:-0}" 'BEGIN{print (b>a)?b:a}')
    _scr=$(awk -v a="$_scr" -v b="${_os:-0}" 'BEGIN{print (b>a)?b:a}')
    _sb=$(awk -v a="$_sb" -v b="${_ob:-0}" 'BEGIN{print (b>a)?b:a}')
    _dis=$(awk -v a="$_dis" -v b="${_od:-0}" 'BEGIN{printf "%.4f", (b>a)?b:a}')
    _chg=$(awk -v a="$_chg" -v b="${_oc:-0}" 'BEGIN{printf "%.4f", (b>a)?b:a}')
    sed -i "s|^$_d,.*|$_d,$_tot,$_scr,$_sb,$_dis,$_chg|" "$_f"
  else
    echo "$_d,$_tot,$_scr,$_sb,$_dis,$_chg" >> "$_f"
  fi
  _n=$(wc -l < "$_f" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
  if [ "$_n" -gt 8 ]; then head -1 "$_f" > "$_f.t"; tail -7 "$_f" >> "$_f.t"; mv -f "$_f.t" "$_f"; fi
  chmod 666 "$_f" 2>/dev/null
}
