#!/system/bin/sh
# 充电/温度伪装 自检 v3.0.0   作者：酷安@happier2
# 逐项检查：模块、伪装是否真的生效、充电放开通道是否可用、本机真实档位/电流上限、
#           功率从哪读、现在到底有没有在进电。全部只做"写一下立刻还原"的探测。
# 输出格式：[OK]/[WARN]/[FAIL]/[INFO] 标题 | 详情 | 建议 —— 配套 App 按前缀上色。
LCK=/data/local/tmp/temp_chg_selfcheck.lock
MOD=/data/adb/modules/temp_mask_all
B=/sys/class/power_supply/battery
USB=/sys/class/power_supply/usb
TZ=/sys/class/thermal
FAKE=/sys/devices/platform/strategy-fg/fake_temp
STATUS=/data/local/tmp/temp_chg_status.txt
SNAP=/data/local/tmp/chg_stock_gear
MASKLOG=/data/local/tmp/temp_mask_all.log
CHGLOG=/data/local/tmp/chg_fast.log
nOK=0; nFAIL=0; nWARN=0
ok(){ nOK=$((nOK+1)); echo "[OK]   $1 | $2"; }
warn(){ nWARN=$((nWARN+1)); echo "[WARN] $1 | $2 | $3"; }
fail(){ nFAIL=$((nFAIL+1)); echo "[FAIL] $1 | $2 | $3"; }
info(){ echo "[INFO] $1 | $2"; }
num(){ case "$1" in ''|*[!0-9]*) echo 0 ;; *) echo "$1" ;; esac; }
to_a(){ awk -v c="$1" 'BEGIN{ if(c<0)c=-c; if(c>=20000) printf "%.2f", c/1000000; else printf "%.2f", c/1000 }'; }
to_v(){ awk -v v="$1" 'BEGIN{ if(v<0)v=-v; if(v>=100000) printf "%.2f", v/1000000; else if(v>=1000) printf "%.2f", v/1000; else printf "%.2f", v }'; }
echo $$ > "$LCK" 2>/dev/null          # 让守护暂停写入，探测结果才准
trap 'rm -f "$LCK"' EXIT INT TERM HUP

# ---------- 1 root ----------
if [ "$(id -u 2>/dev/null)" = "0" ]; then ok "root 权限" "已获得 root，可以读写系统节点"
else fail "root 权限" "当前不是 root (uid=$(id -u 2>/dev/null))" "在 KernelSU/Magisk 管理器里给本应用打开超级用户开关"; fi

# ---------- 2 设备信息 ----------
_mk=$(getprop ro.product.marketname)
info "机型" "$(getprop ro.product.brand) $(getprop ro.product.model)${_mk:+（$_mk）} ｜ SoC $(getprop ro.soc.model)$(getprop ro.board.platform)"
info "系统" "$(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name) ｜ Android $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk)) ｜ $(getprop ro.build.display.id) ｜ 内核 $(uname -r 2>/dev/null)"

# ---------- 3 模块与守护 ----------
if [ -f "$MOD/module.prop" ]; then
  ver=$(grep '^version=' "$MOD/module.prop" 2>/dev/null | cut -d= -f2)
  pid=$(cat /data/local/tmp/temp_chg_all.pid 2>/dev/null)
  if [ -n "$pid" ] && [ -d "/proc/$pid" ]; then ok "模块守护" "已安装 $ver，守护运行中 (pid=$pid)"
  else fail "模块守护" "已安装 $ver，但守护没在运行" "重启手机；或在管理器里跑一次 on 按钮"; fi
else
  warn "模块" "没装二合一模块（本自检仍可用）" "刷入 亮屏快充+全面温度伪装 二合一 zip 才有伪装/快充"
fi
if [ -f "$STATUS" ]; then
  ts=$(grep '^ts=' "$STATUS" 2>/dev/null | cut -d= -f2); ts=$(num "$ts"); d=$(( $(date +%s) - ts ))
  if [ "$d" -lt 30 ]; then ok "守护心跳" "状态文件 ${d}s 前刚更新"
  else warn "守护心跳" "状态文件已 ${d}s 未更新" "守护可能卡死：管理器里跑 off 再 on"; fi
else
  info "守护心跳" "没有状态文件（守护没跑或版本较旧）"
fi

# ---------- 4 热区伪装是否真的生效 ----------
tz=0; wz=0; eff=0; samp=""
for z in $TZ/thermal_zone*; do
  tz=$((tz+1))
  [ -w "$z/emul_temp" ] || continue
  wz=$((wz+1))
  e=$(cat "$z/emul_temp" 2>/dev/null); t=$(cat "$z/temp" 2>/dev/null)
  if [ -n "$e" ] && [ "$e" != "0" ] && [ "$e" = "$t" ]; then eff=$((eff+1)); fi
  [ -z "$samp" ] && samp="$(cat $z/type 2>/dev/null): temp=$t emul=$e"
done
if [ "$wz" -gt 0 ]; then ok "热区伪装通道" "$tz 个热区，可写 emul_temp 的 $wz 个"
else fail "热区伪装通道" "没有任何可写热区（$tz 个）" "本机内核/SELinux 限制，温度伪装无法生效"; fi
if [ "$eff" -gt 0 ]; then ok "热区伪装生效" "抽查读到的是伪装值（$samp）"
elif [ "$wz" -gt 0 ]; then warn "热区伪装生效" "没读到伪装值（$samp）" "守护没跑？或本机 emul_temp 只可写不生效：跑 off→on 再看"; fi

# ---------- 5 电池温度通道 ----------
if [ -w "$FAKE" ]; then
  fv=$(cat "$FAKE" 2>/dev/null); bv=$(num "$(cat $B/temp 2>/dev/null)")
  if [ "$fv" = "-999" ]; then
    ok "电池温度伪装" "当前是「真实温度」模式（fake_temp=-999），battery/temp=$bv(0.1C)"
  else
    d=$(( bv - $(num "$fv") )); [ "$d" -lt 0 ] && d=$(( -d ))
    if [ "$d" -le 5 ]; then ok "电池温度伪装生效" "写 fake=$fv，battery/temp=$bv，一致"
    else warn "电池温度伪装没生效" "写了 fake=$fv，battery/temp 却还是 $bv" "放电时驱动可能不采用该通道；插上充电器再跑一次自检确认。若充电时仍不一致，把这条发给作者"; fi
  fi
else warn "电池温度伪装" "本机没有 $FAKE" "非小米/联发科常见：只靠热区伪装，电池温度会露真值"; fi

# ---------- 6 厂商 thermal_message ----------
mw=0; mt=0
for m in board_sensor_temp board_sensor_second_temp board_sensor_other_temp display_therm_temp ambient_sensor_temp charger_temp; do
  mt=$((mt+1)); [ -w "$TZ/thermal_message/$m" ] && mw=$((mw+1))
done
if [ "$mw" -gt 0 ]; then ok "厂商 thermal_message" "$mw/$mt 可写（安全中心/joyose 看的就是这里）"
else warn "厂商 thermal_message" "0/$mt 可写" "可能不是小米/MTK 或路径不同；不影响热区伪装"; fi

# ---------- 7 充电放开通道 + 本机真实档位/电流上限 ----------
CHAN_RM=""; CHAN_LV=""
for base in /sys/class/xm_power/charger/charger_thermal /sys/class/xm_power/charger /sys/class/power_supply/battery/charger_thermal; do
  if [ -w "$base/wired_thermal_remove" ] || [ -w "$base/wired_ctrl_limit" ]; then
    CHAN_RM="$base/wired_thermal_remove"; CHAN_LV="$base/wired_ctrl_limit"; break
  fi
done
CHAN_CUR=""
for f in $B/constant_charge_current_max $B/hw_charge_current_max $B/charge_current_max $B/current_max; do [ -w "$f" ] && { CHAN_CUR=$f; break; }; done
CHAN_USB=""
for f in $USB/current_max $USB/input_current_limit $B/input_current_limit; do [ -w "$f" ] && { CHAN_USB=$f; break; }; done

if [ -n "$CHAN_RM" ]; then
  orig=$(cat "$CHAN_RM" 2>/dev/null)
  echo 1 > "$CHAN_RM" 2>/dev/null; r1=$(cat "$CHAN_RM" 2>/dev/null)
  echo "$(num "$orig")" > "$CHAN_RM" 2>/dev/null
  if [ "$r1" = "1" ]; then ok "放开开关(remove)" "$CHAN_RM 可写可读回（原值 $(num "$orig")）"
  else warn "放开开关(remove)" "$CHAN_RM 写了不生效(读回=$r1)" "本机可能被 SELinux 挡或语义不同"; fi
fi
if [ -n "$CHAN_LV" ]; then
  stock=$(cat "$CHAN_LV" 2>/dev/null); stockn=$(num "$stock")
  ok "档位通道(小米/澎湃)" "$CHAN_LV 可写，官方档=$stockn"
  best=""
  for g in 1 2 3 4 5 6 8; do
    echo "$g" > "$CHAN_LV" 2>/dev/null
    rb=$(cat "$CHAN_LV" 2>/dev/null); rbn=$(num "$rb")
    echo "$stockn" > "$CHAN_LV" 2>/dev/null
    [ "$rbn" = "$g" ] && { [ -z "$best" ] && best=$g; info "档位试探" "写 $g → 驱动接受 $rbn"; }
  done
  if [ -n "$best" ]; then ok "放开档可用" "本机最小可用档位=$best（config.sh 的 GEAR_MIN 建议=$best）"
  else warn "放开档不可用" "试写 1~8 都没有被接受，驱动一直给 $stockn" "本机档位语义可能不同（HyperOS 版本差异）：把 GEAR_MIN 设成 $stockn 或只用 remove"; fi
fi
for f in $CHAN_CUR $CHAN_USB; do
  [ -n "$f" ] || continue
  stock=$(num "$(cat "$f" 2>/dev/null)")
  if [ "$stock" -ge 100000 ]; then want=6000000; else want=6000; fi
  echo "$want" > "$f" 2>/dev/null
  got=$(num "$(cat "$f" 2>/dev/null)")
  echo "$stock" > "$f" 2>/dev/null
  su=uA; [ "$stock" -lt 100000 ] && su=mA
  gu=uA; [ "$got" -lt 100000 ] && gu=mA
  ma_s=$(( stock >= 100000 ? stock / 1000 : stock )); ma_g=$(( got >= 100000 ? got / 1000 : got ))
  if [ "$ma_g" -gt "$ma_s" ]; then ok "电流上限通道" "$(basename $f)：官方 ${ma_s}mA → 放开后 ${ma_g}mA（可提高 $(( ma_g - ma_s ))mA）"
  else info "电流上限通道" "$(basename $f)：官方 ${ma_s}mA，写放开后仍 ${ma_g}mA（本机已到顶，或该通道不控制充电电流）"; fi
done
if [ -z "$CHAN_RM" ] && [ -z "$CHAN_CUR" ] && [ -z "$CHAN_USB" ]; then
  fail "充电放开通道" "三种通道都没探测到可写的" "本机只能用温度伪装；快充需另找节点（把 /sys 里的节点名发给作者适配）"
fi

# ---------- 7b 电芯（双电芯/多电芯机型）----------
celln=0; cellinfo=""
for d in /sys/class/power_supply/*; do
  [ -r "$d/type" ] || continue
  t=$(cat "$d/type" 2>/dev/null)
  case "$t" in *Battery*) ;; *) continue ;; esac
  celln=$((celln+1))
  cellinfo="$cellinfo$(basename $d)=$(cat $d/current_now 2>/dev/null)uA/$(cat $d/voltage_now 2>/dev/null)uV "
done
if [ "$celln" -ge 2 ]; then
  ok "电芯(多电芯机型)" "检测到 $celln 个电池节点，功率按各芯 P=V×I 求和：$cellinfo"
elif [ "$celln" = "1" ]; then
  info "电芯" "1 个电池节点：$cellinfo"
else
  warn "电芯" "没找到 type=Battery 的节点" "本机不标准，功率只能靠 USB 侧估算"
fi

# ---------- 8 功率从哪读 ----------
found=0
if [ -r "$B/power_now" ]; then pw=$(num "$(cat $B/power_now)"); info "功率源 battery/power_now" "$pw µW ≈ $(awk -v p=$pw 'BEGIN{printf "%.2f", p/1000000}')W"; found=1; fi
for d in $B /sys/class/power_supply/bms $USB; do
  [ -r "$d/current_now" ] || continue
  ci=$(cat "$d/current_now" 2>/dev/null); cv=$(cat "$d/voltage_now" 2>/dev/null)
  ca=$(to_a "$ci"); cvv=$(to_v "$cv")
  ww=$(awk -v i="$ca" -v v="$cvv" 'BEGIN{printf "%.2f", i*v}')
  info "功率源 $(basename $d)" "current=$ci voltage=$cv → ${ca}A × ${cvv}V = ${ww}W"; found=1
done
[ "$found" = "1" ] && ok "功率读取" "至少一个功率源可读，App 显示的瓦数就来自这里" \
                   || fail "功率读取" "没有任何可读的电流/电压节点" "本机不暴露功率信息，App 只能显示电量/温度"

# ---------- 8c 输入侧节点明细（用来对上 Scene 的瓦数）----------
NODES=/data/local/tmp/temp_chg_nodes.txt
if [ -f "$NODES" ] && [ -s "$NODES" ]; then
  info "充电节点快照" "以下每次充电会记录到 $NODES（最多 200 行）"
  tail -8 "$NODES" | while IFS= read -r _line; do echo "[INFO] 快照 | $_line"; done
else
  info "充电节点快照" "还没有（插上充电器充电 30 秒后就有了）"
fi

# ---------- 9 现在到底有没有在进电 ----------
st=$(cat "$B/status" 2>/dev/null); cap=$(num "$(cat "$B/capacity" 2>/dev/null)")
ci=$(cat "$B/current_now" 2>/dev/null); ca=$(to_a "$ci")
plug=0
for f in $USB/online $USB/present /sys/class/power_supply/main/present /sys/class/power_supply/charger/online /sys/class/power_supply/pc_port/online; do
  [ -r "$f" ] || continue
  [ "$(cat "$f" 2>/dev/null)" = "1" ] && { plug=1; break; }
done
if [ "$st" = "Charging" ] || [ "$st" = "Full" ]; then
  ok "实时充电" "status=$st 电量=${cap}% 电流=${ca}A 温度=$(cat $B/temp 2>/dev/null)(0.1C)"
  if [ "$cap" -lt 90 ] && awk -v a="$ca" 'BEGIN{exit !(a<0.3)}'; then
    warn "进电电流偏低" "状态在充电但电流只有 ${ca}A" "可能被压住：跑 rescue → 拔插数据线；也可能是线材/协议问题"
  fi
elif [ "$plug" = "1" ]; then
  fail "实时充电" "插着充电器却没在充电(status=$st 电量=${cap}%)" "跑 rescue → 拔插数据线 → 换线换头；仍不行就是硬件/温度保护"
else
  info "实时充电" "当前没插充电器(status=$st 电量=${cap}%)"
fi

# ---------- 10 日志尾巴 ----------
[ -f "$CHGLOG" ] && info "最近快充日志" "$(tail -1 "$CHGLOG" 2>/dev/null)"
[ -f "$MASKLOG" ] && info "最近伪装日志" "$(tail -1 "$MASKLOG" 2>/dev/null)"

# ---------- 11 结论 ----------
echo "[INFO] 结论 | 通过 $nOK 项 ｜ 警告 $nWARN 项 ｜ 失败 $nFAIL 项"
if [ "$nFAIL" -gt 0 ]; then echo "[INFO] 建议 | 先按上面 FAIL 项后面的建议处理；处理后重跑一次自检"
elif [ "$nWARN" -gt 0 ]; then echo "[INFO] 建议 | 核心功能正常，WARN 项按需处理（大多是多机型差异，不影响使用）"
else echo "[INFO] 建议 | 全部正常：温度伪装与亮屏快充都在生效"; fi
