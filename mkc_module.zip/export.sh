#!/system/bin/sh
# 导出诊断日志：root 直接写 /sdcard/ 根目录，中文文件名方便找。作者：酷安@happier2
M=${0%/*}
TS=$(date +%Y%m%d_%H%M%S)
NAME="充电诊断日志_${TS}.txt"
OUT="/sdcard/${NAME}"
{
  echo "======= DSH 充电诊断包 ======="
  echo "导出时间：$(date '+%Y-%m-%d %H:%M:%S')"
  echo "机型：$(getprop ro.product.brand) $(getprop ro.product.model)（$(getprop ro.product.marketname)）$(getprop ro.product.device)"
  echo "系统：$(getprop ro.mi.os.version.name)$(getprop ro.miui.ui.version.name) ｜ Android $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk)) ｜ $(getprop ro.build.display.id)"
  echo "内核：$(uname -r 2>/dev/null) ｜ SoC $(getprop ro.soc.model)$(getprop ro.board.platform) ｜ ABI $(getprop ro.product.cpu.abi)"
  echo "模块：$(grep '^version=' "$M/module.prop" 2>/dev/null | cut -d= -f2) ｜ 守护 pid $(cat /data/local/tmp/temp_chg_all.pid 2>/dev/null)"
  echo
  echo "########## 一、自检 ##########"
  [ -f "$M/selfcheck.sh" ] && sh "$M/selfcheck.sh" 2>&1 || echo "（没有 selfcheck.sh）"
  echo
  echo "########## 二、节点普查 ##########"
  [ -f "$M/probe.sh" ] && sh "$M/probe.sh" 2>&1 || echo "（没有 probe.sh）"
  echo
  echo "########## 三、当前状态 ##########"
  cat /data/local/tmp/temp_chg_status.txt 2>/dev/null
  echo
  echo "########## 四、档位识别结果 ##########"
  cat /data/local/tmp/temp_chg_gearscan.txt 2>/dev/null
  echo
  echo "########## 五、当前配置（App 可改）##########"
  cat /data/local/tmp/temp_chg_set.cfg 2>/dev/null
  cat /data/local/tmp/temp_chg_guard.cfg 2>/dev/null
  echo
  echo "########## 六、功率曲线（末 150 行）##########"
  tail -150 /data/local/tmp/temp_chg_power.csv 2>/dev/null
  echo
  echo "########## 七、充电记录（末 60 条）##########"
  tail -60 /data/local/tmp/temp_chg_sessions.csv 2>/dev/null
  echo
  echo "########## 八、快充日志（末 100 行）##########"
  tail -100 /data/local/tmp/chg_fast.log 2>/dev/null
  echo
  echo "########## 九、温度伪装日志（末 40 行）##########"
  tail -40 /data/local/tmp/temp_mask_all.log 2>/dev/null
  echo
  echo "########## 结束 ##########"
} > "$OUT" 2>&1
chmod 666 "$OUT" 2>/dev/null
cp -f "$OUT" "/sdcard/Download/$NAME" 2>/dev/null
SIZE=$(wc -c < "$OUT" 2>/dev/null)
echo "已导出：$OUT （${SIZE} 字节）" > /data/local/tmp/temp_chg_export_path.txt
[ -f "/sdcard/Download/$NAME" ] && echo "副本：/sdcard/Download/$NAME" >> /data/local/tmp/temp_chg_export_path.txt
# ★ 触发媒体扫描：root 直接写的文件不进媒体库，文件管理器（走媒体库）会看不到
DP="/sdcard/Download/$NAME"
if [ -f "$DP" ]; then
  am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://$DP" >/dev/null 2>&1
  content call --uri content://media/external/file --method scan_file --arg "$DP" >/dev/null 2>&1
fi
chmod 666 /data/local/tmp/temp_chg_export_path.txt 2>/dev/null
echo "已导出：$OUT （${SIZE} 字节）"
